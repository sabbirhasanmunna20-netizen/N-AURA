export type ProductCategory = 
  | 'Audio' 
  | 'Timepieces' 
  | 'Home & Living' 
  | 'Apparel' 
  | 'Stationery';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number; // In Taka (৳)
  originalPrice?: number;
  stock: number;
  description: string;
  specs: Record<string, string>;
  images: string[];
  featured: boolean;
  rating: number;
  reviewCount: number;
  tag?: string;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: string;
}

export type PaymentMethod = 'cod' | 'mfs_bkash' | 'mfs_nagad' | 'card_stripe';

export type PaymentStatus = 'pending' | 'verified' | 'paid' | 'failed';

export type OrderStatus = 'placed' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  userId?: string;
  customerName: string;
  email: string; // Gmail
  phone: string; // Phone number
  shippingAddress: string;
  city: string;
  postalCode: string;
  notes?: string;
  items: CartItem[];
  subtotal: number;
  shippingFee: number;
  discount: number;
  total: number;
  // Security deposit requirements
  securityDepositAmount: number; // Always 100 Taka
  securityDepositPaid: boolean;
  securityDepositTxId?: string; // bKash Transaction ID
  remainingDueOnDelivery: number; // (Total - Security deposit) for COD, 0 for full online
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  transactionId?: string;
  orderStatus: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  type: 'product_create' | 'product_update' | 'product_delete' | 'order_status' | 'system_reset' | 'stock_adjustment' | 'troubleshoot' | 'payment_verify';
  message: string;
  author: string;
}

export interface SystemHealth {
  storageUsageKB: number;
  productCount: number;
  orderCount: number;
  lowStockCount: number;
  lastSync: string;
  status: 'optimal' | 'warning' | 'degraded';
}

export interface DiscountCoupon {
  code: string;
  percentage: number;
  description: string;
  minSpend: number;
}

export interface SavedAddress {
  id: string;
  label: string;
  recipientName: string;
  phone: string;
  streetAddress: string;
  city: string;
  postalCode: string;
  isDefault: boolean;
}

export interface SavedPaymentMethod {
  id: string;
  type: PaymentMethod;
  label: string;
  details: string;
  isDefault: boolean;
}

export interface UserProfile {
  id: string;
  email: string; // Must be valid Gmail address
  phone: string; // Customer phone number
  name: string;
  passwordHash?: string;
  isPhoneVerified: boolean;
  isEmailVerified: boolean;
  addresses: SavedAddress[];
  paymentMethods: SavedPaymentMethod[];
  wishlist?: string[]; // Product IDs saved to customer's Saved Items
  createdAt: string;
}

export interface ProductReview {
  id: string;
  productId: string;
  userId?: string;
  authorName: string;
  authorEmail?: string;
  authorPhone?: string;
  rating: number; // 1 to 5
  title: string;
  comment: string;
  isVerifiedPurchase: boolean;
  createdAt: string;
}

export interface BusinessLicense {
  licenseNumber: string;
  entityName: string;
  proprietor: string;
  issuingAuthority: string;
  businessType: string;
  tinNumber: string;
  binNumber: string;
  registeredAddress: string;
  issueDate: string;
  validUntil: string;
  verificationUrl: string;
  whatsappSupport: string;
  bkashNumber: string;
}

export interface VerificationCode {
  identifier: string; // Phone or Gmail
  code: string;
  expiresAt: number;
  purpose: 'login' | 'register' | 'checkout';
}
