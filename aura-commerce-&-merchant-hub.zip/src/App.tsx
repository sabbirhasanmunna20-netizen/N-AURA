import React, { useState, useEffect } from 'react';
import { Product, Order, CartItem, ProductCategory, UserProfile } from './types';
import { StorageService } from './services/storage';
import { Header } from './components/Header';
import { StoreHero } from './components/StoreHero';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderConfirmationModal } from './components/OrderConfirmationModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { AuthModal } from './components/auth/AuthModal';
import { UserProfileModal } from './components/profile/UserProfileModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminSecurityModal } from './components/admin/AdminSecurityModal';
import { BusinessLicenseModal } from './components/BusinessLicenseModal';
import { WhatsAppSupportButton } from './components/WhatsAppSupportButton';
import { NAuraLogo } from './components/NAuraLogo';
import { WHATSAPP_SUPPORT_NUMBER, BKASH_PAYMENT_NUMBER, BUSINESS_LICENSE_INFO } from './services/storage';
import { useToast } from './components/toast';
import { 
  Search, 
  SlidersHorizontal, 
  Check, 
  ShieldCheck, 
  Truck, 
  RotateCcw,
  X,
  Star,
  FileText,
  MessageCircle
} from 'lucide-react';

const CATEGORIES: ('all' | ProductCategory)[] = [
  'all',
  'Audio',
  'Timepieces',
  'Home & Living',
  'Apparel',
  'Stationery',
];

export default function App() {
  const { toast } = useToast();

  // Store Data state
  const [products, setProducts] = useState<Product[]>(() => StorageService.getProducts());
  const [orders, setOrders] = useState<Order[]>(() => StorageService.getOrders());

  // Customer Authentication state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => StorageService.getCurrentUser());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [profileInitialTab, setProfileInitialTab] = useState<'orders' | 'wishlist' | 'addresses' | 'payments' | 'account'>('orders');

  // Wishlist handler for authenticated users
  const handleToggleWishlist = (product: Product) => {
    if (!currentUser) {
      toast.info('Sign in Required', 'Please sign in to save items to your wishlist', {
        action: {
          label: 'Sign In',
          onClick: () => setIsAuthModalOpen(true),
        },
      });
      setIsAuthModalOpen(true);
      return;
    }
    const wasWishlisted = isProductWishlisted(product.id);
    StorageService.toggleWishlist(product.id, currentUser.id);
    const refreshed = StorageService.getCurrentUser();
    if (refreshed) {
      setCurrentUser(refreshed);
    }
    toast.wishlist(product, !wasWishlisted, {
      onOpenWishlist: () => {
        setProfileInitialTab('wishlist');
        setIsProfileModalOpen(true);
      },
    });
  };

  const isProductWishlisted = (productId: string): boolean => {
    if (!currentUser) return false;
    return (currentUser.wishlist || []).includes(productId);
  };

  // Navigation & View Mode
  const [currentView, setCurrentView] = useState<'store' | 'admin'>('store');
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() =>
    StorageService.isAdminAuthenticated()
  );
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [isLicenseModalOpen, setIsLicenseModalOpen] = useState(false);

  // Cart state with permanent persistence
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('aura_cart_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Modals & Panels
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isOrderTrackingOpen, setIsOrderTrackingOpen] = useState(false);
  const [trackingOrderId, setTrackingOrderId] = useState<string>('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  // Checkout discount state
  const [discountPct, setDiscountPct] = useState(0);
  const [couponCode, setCouponCode] = useState('');

  // Advanced Search & Multi-Facet Filtering state
  const [selectedCategory, setSelectedCategory] = useState<'all' | ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest'>('featured');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(25000);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [minRating, setMinRating] = useState<number>(0);

  // Save cart changes to localStorage for permanent state tracking
  useEffect(() => {
    try {
      localStorage.setItem('aura_cart_v1', JSON.stringify(cart));
    } catch {
      // Ignore
    }
  }, [cart]);

  // Sync state when storage updates from any component or tab
  useEffect(() => {
    const handleStoreUpdate = () => {
      setProducts(StorageService.getProducts());
      setOrders(StorageService.getOrders());
      setCurrentUser(StorageService.getCurrentUser());
    };

    window.addEventListener('aura_store_updated', handleStoreUpdate);
    return () => window.removeEventListener('aura_store_updated', handleStoreUpdate);
  }, []);

  // Cart Handlers
  const handleAddToCart = (product: Product, quantity = 1, openCart = false) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(product.stock, item.quantity + quantity) }
            : item
        );
      }
      return [...prev, { product, quantity: Math.min(product.stock, quantity) }];
    });

    // Display non-intrusive notification toast
    toast.cart(product, quantity, {
      onOpenCart: () => setIsCartOpen(true),
    });

    if (openCart) {
      setIsCartOpen(true);
    }
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    const item = cart.find((i) => i.product.id === productId);
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    if (item) {
      toast.info('Removed from Cart', `${item.product.name} removed from your bag.`);
    }
  };

  const handleProceedToCheckout = (discount: number, code: string) => {
    setDiscountPct(discount);
    setCouponCode(code);
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderSuccess = (order: Order) => {
    setCart([]);
    setIsCheckoutOpen(false);
    setConfirmedOrder(order);

    // Display non-intrusive notification toast for completed order
    toast.order(order, {
      onTrackOrder: () => handleOpenTrackSpecificOrder(order.id),
    });
  };

  const handleOpenTrackSpecificOrder = (orderId: string) => {
    setConfirmedOrder(null);
    setTrackingOrderId(orderId);
    setIsOrderTrackingOpen(true);
  };

  const handleReorder = (items: CartItem[]) => {
    setCart((prev) => {
      let updated = [...prev];
      items.forEach((item) => {
        const existing = updated.find((i) => i.product.id === item.product.id);
        if (existing) {
          existing.quantity = Math.min(item.product.stock, existing.quantity + item.quantity);
        } else {
          updated.push({ product: item.product, quantity: item.quantity });
        }
      });
      return updated;
    });
    toast.success('Items Added to Bag', `${items.length} items from previous order added to cart`, {
      action: {
        label: 'View Bag',
        onClick: () => setIsCartOpen(true),
      },
    });
  };

  // Admin Navigation Gate
  const handleNavigate = (view: 'store' | 'admin') => {
    if (view === 'admin') {
      if (!StorageService.isAdminAuthenticated()) {
        setIsSecurityModalOpen(true);
      } else {
        setCurrentView('admin');
      }
    } else {
      setCurrentView('store');
    }
  };

  const handleAdminAuthenticated = () => {
    setIsAdminAuthenticated(true);
    setIsSecurityModalOpen(false);
    setCurrentView('admin');
    toast.success('Admin Mode', 'Authenticated with administrative privileges');
  };

  const handleLockAdminSession = () => {
    StorageService.setAdminAuthenticated(false);
    setIsAdminAuthenticated(false);
    setCurrentView('store');
    toast.info('Session Locked', 'Returned to customer storefront');
  };

  const handleLogoutUser = () => {
    StorageService.logout();
    setCurrentUser(null);
    toast.info('Signed Out', 'You have been safely signed out.');
  };

  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Multi-Facet Filter & Sort Logic
  const filteredProducts = products
    .filter((p) => {
      const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
      const query = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !query ||
        p.name.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        (p.tag && p.tag.toLowerCase().includes(query)) ||
        Object.values(p.specs || {}).some((v) => v.toLowerCase().includes(query));

      const matchesPrice = p.price >= minPrice && p.price <= maxPrice;
      const matchesStock = !inStockOnly || p.stock > 0;
      const matchesRating = minRating === 0 || p.rating >= minRating;

      return matchesCat && matchesSearch && matchesPrice && matchesStock && matchesRating;
    })
    .sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });

  const hasActiveFilters =
    selectedCategory !== 'all' ||
    searchQuery.trim() !== '' ||
    minPrice > 0 ||
    maxPrice < 25000 ||
    inStockOnly ||
    minRating > 0;

  const resetAllFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setMinPrice(0);
    setMaxPrice(25000);
    setInStockOnly(false);
    setMinRating(0);
    setSortBy('featured');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FBFBF9] text-stone-900 selection:bg-stone-200">
      {/* Universal Top Bar */}
      <Header
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenTrackOrder={() => {
          setTrackingOrderId('');
          setIsOrderTrackingOpen(true);
        }}
        onOpenSearch={() => {
          const el = document.getElementById('catalog-search-input');
          if (el) {
            el.focus();
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }}
        cartCount={totalCartCount}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenProfile={() => {
          setProfileInitialTab('orders');
          setIsProfileModalOpen(true);
        }}
        onOpenLicense={() => setIsLicenseModalOpen(true)}
        wishlistCount={currentUser?.wishlist?.length || 0}
        onOpenWishlist={() => {
          if (currentUser) {
            setProfileInitialTab('wishlist');
            setIsProfileModalOpen(true);
          } else {
            setIsAuthModalOpen(true);
          }
        }}
      />

      {/* Admin View Render */}
      {currentView === 'admin' ? (
        <AdminDashboard
          products={products}
          orders={orders}
          onRefreshAll={() => {
            setProducts(StorageService.getProducts());
            setOrders(StorageService.getOrders());
          }}
          onReturnToStore={() => setCurrentView('store')}
          onLockSession={handleLockAdminSession}
        />
      ) : (
        /* Storefront View */
        <main className="flex-1">
          {/* Section 1: Hero Showcase */}
          <StoreHero
            onExploreClick={() => {
              const el = document.getElementById('catalog-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            onOpenLicense={() => setIsLicenseModalOpen(true)}
          />

          {/* Section 2: Catalog & Advanced Filter Module */}
          <section id="catalog-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
            {/* Catalog Header */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 pb-6 border-b border-stone-200">
              <div>
                <span className="text-xs uppercase tracking-widest text-stone-500 font-medium block mb-1">
                  Catalog Directory
                </span>
                <h2 className="text-3xl sm:text-4xl font-serif font-medium text-stone-950">
                  Curated Living & Instruments
                </h2>
              </div>

              {/* Sorting and Filter Drawer Toggle */}
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setShowFilterDrawer((prev) => !prev)}
                  className={`px-3 py-2 text-xs font-medium rounded-md border transition-colors flex items-center gap-1.5 cursor-pointer ${
                    showFilterDrawer || (minPrice > 0 || maxPrice < 1000 || inStockOnly || minRating > 0)
                      ? 'bg-stone-900 text-white border-stone-900'
                      : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Filters</span>
                  {(minPrice > 0 || maxPrice < 1000 || inStockOnly || minRating > 0) && (
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  )}
                </button>

                <div className="flex items-center gap-2 text-xs text-stone-600 bg-white border border-stone-200 rounded-md px-3 py-2">
                  <span className="text-stone-500">Sort by:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-transparent text-stone-900 font-medium focus:outline-none cursor-pointer"
                  >
                    <option value="featured">Curated & Featured</option>
                    <option value="price-asc">Price: Low to High</option>
                    <option value="price-desc">Price: High to Low</option>
                    <option value="rating">Highest Rated</option>
                    <option value="newest">Newest Arrivals</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Category Segmented Tabs (Buttons per Zero-Pill Interactive rule) */}
            <div className="flex flex-col lg:flex-row gap-4 justify-between items-start lg:items-center mb-6">
              <div className="flex flex-wrap items-center gap-1.5 p-1 bg-stone-100 rounded-lg border border-stone-200/60">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer capitalize whitespace-nowrap ${
                      selectedCategory === cat
                        ? 'bg-stone-900 text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-950'
                    }`}
                  >
                    {cat === 'all' ? 'All Objects' : cat}
                  </button>
                ))}
              </div>

              {/* Prominent Search Bar Input */}
              <div className="relative w-full lg:w-80">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="catalog-search-input"
                  type="text"
                  placeholder="Search by keyword, material, or SKU..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 bg-white border border-stone-200 rounded-md text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-stone-900 shadow-xs"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 text-xs p-1"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            {/* Collapsible Advanced Filter Suite */}
            {showFilterDrawer && (
              <div className="mb-8 p-5 bg-white border border-stone-200 rounded-lg shadow-xs space-y-4 text-xs animate-in slide-in-from-top-2 duration-200">
                <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                  <span className="font-serif font-semibold text-sm text-stone-950">
                    Refine Specifications & Parameters
                  </span>
                  <button
                    onClick={() => setShowFilterDrawer(false)}
                    className="text-stone-400 hover:text-stone-700 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  {/* Price Range Slider / Inputs */}
                  <div>
                    <label className="block text-stone-700 font-medium mb-1.5">
                      Price Range: <span className="font-mono tabular-nums text-stone-950 font-semibold">৳{minPrice.toLocaleString()} — ৳{maxPrice.toLocaleString()}</span>
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min="0"
                        max="25000"
                        step="250"
                        value={maxPrice}
                        onChange={(e) => setMaxPrice(Number(e.target.value))}
                        className="w-full accent-stone-900 cursor-pointer"
                      />
                    </div>
                    <div className="flex justify-between text-[11px] text-stone-400 mt-1 font-mono">
                      <span>৳0</span>
                      <span>৳12,500</span>
                      <span>৳25,000+</span>
                    </div>
                  </div>

                  {/* Stock Availability */}
                  <div>
                    <label className="block text-stone-700 font-medium mb-1.5">Availability Status</label>
                    <label className="flex items-center gap-2 p-2 bg-stone-50 rounded border border-stone-200 cursor-pointer hover:bg-stone-100">
                      <input
                        type="checkbox"
                        checked={inStockOnly}
                        onChange={(e) => setInStockOnly(e.target.checked)}
                        className="rounded border-stone-300 text-stone-900 cursor-pointer"
                      />
                      <span className="text-stone-800 font-medium">In Stock Only (Exclude Sold Out)</span>
                    </label>
                  </div>

                  {/* Rating Filter */}
                  <div>
                    <label className="block text-stone-700 font-medium mb-1.5">Minimum Customer Rating</label>
                    <select
                      value={minRating}
                      onChange={(e) => setMinRating(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-800 font-medium cursor-pointer"
                    >
                      <option value="0">All Customer Ratings</option>
                      <option value="4.5">4.5 Stars & Higher</option>
                      <option value="4.8">4.8 Stars & Higher (Exceptional)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Active Filters Bar and Result Count Indicator */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-6 text-xs text-stone-500">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-medium text-stone-700">
                  Showing {filteredProducts.length} of {products.length} curations
                </span>

                {hasActiveFilters && (
                  <>
                    <span aria-hidden="true">·</span>
                    {searchQuery && (
                      <span className="bg-stone-100 text-stone-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1 border border-stone-200">
                        Query: "{searchQuery}"
                        <button onClick={() => setSearchQuery('')} className="hover:text-stone-950">✕</button>
                      </span>
                    )}
                    {selectedCategory !== 'all' && (
                      <span className="bg-stone-100 text-stone-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1 border border-stone-200">
                        Category: {selectedCategory}
                        <button onClick={() => setSelectedCategory('all')} className="hover:text-stone-950">✕</button>
                      </span>
                    )}
                    {maxPrice < 1000 && (
                      <span className="bg-stone-100 text-stone-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1 border border-stone-200">
                        Max: ${maxPrice}
                        <button onClick={() => setMaxPrice(1000)} className="hover:text-stone-950">✕</button>
                      </span>
                    )}
                    {inStockOnly && (
                      <span className="bg-stone-100 text-stone-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1 border border-stone-200">
                        In Stock Only
                        <button onClick={() => setInStockOnly(false)} className="hover:text-stone-950">✕</button>
                      </span>
                    )}
                    {minRating > 0 && (
                      <span className="bg-stone-100 text-stone-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1 border border-stone-200">
                        ★ {minRating}+
                        <button onClick={() => setMinRating(0)} className="hover:text-stone-950">✕</button>
                      </span>
                    )}

                    <button
                      onClick={resetAllFilters}
                      className="text-stone-600 hover:text-stone-950 underline ml-2 cursor-pointer font-medium"
                    >
                      Clear All Filters
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Products Grid: 3-column desktop baseline */}
            {filteredProducts.length === 0 ? (
              <div className="p-16 text-center bg-white rounded-lg border border-stone-200 my-8 space-y-3">
                <p className="font-serif text-xl text-stone-900">No matching curations found</p>
                <p className="text-xs text-stone-500 max-w-sm mx-auto leading-relaxed">
                  No inventory matched your search query or filter parameters. Try loosening price bounds or clearing the keyword search.
                </p>
                <button
                  onClick={resetAllFilters}
                  className="px-4 py-2 bg-stone-900 text-white text-xs uppercase tracking-wider font-semibold rounded cursor-pointer hover:bg-stone-800 transition-colors"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={(p) => handleAddToCart(p, 1)}
                    onSelectProduct={(p) => setSelectedProduct(p)}
                    isWishlisted={isProductWishlisted(product.id)}
                    onToggleWishlist={handleToggleWishlist}
                  />
                ))}
              </div>
            )}
          </section>

          {/* Section 3: Craftsmanship & Atelier Principles */}
          <section id="craftsmanship-section" className="border-t border-stone-200 bg-white py-16 sm:py-24">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="max-w-2xl mb-12">
                <span className="text-xs uppercase tracking-widest text-stone-500 font-medium block mb-2">
                  Merchant Philosophy
                </span>
                <h2 className="text-3xl sm:text-4xl font-serif font-medium text-stone-950 mb-4 [text-wrap:balance]">
                  Built for physical presence and generational use.
                </h2>
                <p className="text-stone-600 text-base leading-relaxed">
                  We discard transient plastic and excessive packaging in pursuit of honest materials: solid anodized aluminum, hand-turned brass, French linen, and sapphire crystal.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6 border-t border-stone-100 text-xs">
                <div className="space-y-2">
                  <span className="font-mono text-stone-400">01.</span>
                  <h3 className="text-sm font-semibold text-stone-900">Direct Doorstep Verification</h3>
                  <p className="text-stone-600 leading-relaxed">
                    Our Cash on Delivery (COD) service guarantees you only pay once your package arrives in pristine condition at your residence.
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="font-mono text-stone-400">02.</span>
                  <h3 className="text-sm font-semibold text-stone-900">Immediate Digital Settlement</h3>
                  <p className="text-stone-600 leading-relaxed">
                    Local Mobile Financial Services (bKash & Nagad) alongside 256-bit card gateways ensure instantaneous transaction confirmation and receipt issuance.
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="font-mono text-stone-400">03.</span>
                  <h3 className="text-sm font-semibold text-stone-900">Internal Operational Control</h3>
                  <p className="text-stone-600 leading-relaxed">
                    Our centralized merchant control panel tracks inventory levels in real-time and performs automated data integrity checks without third-party server dependencies.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </main>
      )}

      {/* Clean Editorial Footer */}
      <footer className="border-t border-stone-200 bg-[#FBFBF9] py-12 text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-8 border-b border-stone-200">
            <div>
              <NAuraLogo size="md" variant="dark" subtitle="DHAKA · EST. 2024" />
              <p className="text-stone-500 text-xs mt-2">Objects of quiet distinction, designed to endure.</p>
            </div>

            <div className="flex flex-wrap items-center gap-6 text-stone-600">
              {currentUser ? (
                <button
                  onClick={() => setIsProfileModalOpen(true)}
                  className="hover:text-stone-950 transition-colors cursor-pointer"
                >
                  My Account & Orders
                </button>
              ) : (
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="hover:text-stone-950 transition-colors cursor-pointer"
                >
                  Customer Sign In
                </button>
              )}
              <button
                onClick={() => setIsLicenseModalOpen(true)}
                className="hover:text-stone-950 text-emerald-800 font-medium transition-colors cursor-pointer flex items-center gap-1"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Trade License Certificate</span>
              </button>
              <a 
                href={`https://wa.me/8801516557161?text=Hello%20Aura%20Support!`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-emerald-700 text-stone-700 font-medium transition-colors flex items-center gap-1"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                <span>WhatsApp: {WHATSAPP_SUPPORT_NUMBER}</span>
              </a>
              <button
                onClick={() => {
                  setTrackingOrderId('');
                  setIsOrderTrackingOpen(true);
                }}
                className="hover:text-stone-950 transition-colors cursor-pointer"
              >
                Track Your Consignment
              </button>
              <button
                onClick={() => handleNavigate('admin')}
                className="hover:text-stone-950 transition-colors cursor-pointer font-medium"
              >
                Merchant Control Hub
              </button>
              <a href="#catalog-section" className="hover:text-stone-950 transition-colors">
                Catalog Archive
              </a>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-stone-400 text-[11px]">
            <p>© {new Date().getFullYear()} N AURA Living Goods & Instruments. Permanent state persistence enabled.</p>
            <div className="flex items-center gap-4">
              <span>Cash on Delivery</span>
              <span aria-hidden="true">·</span>
              <span>bKash / Nagad MFS</span>
              <span aria-hidden="true">·</span>
              <span>Visa / Mastercard</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Modals & Slide-overs */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        currentUser={currentUser}
        isWishlisted={selectedProduct ? isProductWishlisted(selectedProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onProceedToCheckout={handleProceedToCheckout}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        discountPct={discountPct}
        couponCode={couponCode}
        onOrderSuccess={handleOrderSuccess}
        currentUser={currentUser}
      />

      <OrderConfirmationModal
        order={confirmedOrder}
        onClose={() => setConfirmedOrder(null)}
        onTrackOrder={handleOpenTrackSpecificOrder}
      />

      <OrderTrackingModal
        isOpen={isOrderTrackingOpen}
        onClose={() => setIsOrderTrackingOpen(false)}
        initialOrderId={trackingOrderId}
      />

      <AdminSecurityModal
        isOpen={isSecurityModalOpen}
        onAuthenticated={handleAdminAuthenticated}
        onCancel={() => setIsSecurityModalOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={(user) => {
          setCurrentUser(user);
          setIsProfileModalOpen(true);
          toast.success('Signed In', `Welcome back, ${user.name}`);
        }}
      />

      {currentUser && (
        <UserProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          user={currentUser}
          onUserUpdated={(updated) => setCurrentUser(updated)}
          onLogout={handleLogoutUser}
          onTrackOrder={handleOpenTrackSpecificOrder}
          onInspectOrder={(order) => setConfirmedOrder(order)}
          onReorder={handleReorder}
          initialTab={profileInitialTab}
          onAddToCart={(product) => handleAddToCart(product, 1)}
          onInspectProduct={(product) => setSelectedProduct(product)}
        />
      )}

      {/* Official Government Business License Modal */}
      <BusinessLicenseModal
        isOpen={isLicenseModalOpen}
        onClose={() => setIsLicenseModalOpen(false)}
      />

      {/* Floating 24/7 WhatsApp Support Widget */}
      <WhatsAppSupportButton
        onOpenLicense={() => setIsLicenseModalOpen(true)}
      />
    </div>
  );
}
