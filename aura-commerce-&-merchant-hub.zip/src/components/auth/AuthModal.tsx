import React, { useState } from 'react';
import { StorageService, WHATSAPP_SUPPORT_NUMBER } from '../../services/storage';
import { UserProfile } from '../../types';
import { NAuraLogo } from '../NAuraLogo';
import { 
  X, 
  Lock, 
  Mail, 
  User, 
  Phone, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  ShieldCheck, 
  KeyRound,
  RefreshCw
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
  initialMode?: 'login' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialMode = 'login',
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot_password'>(initialMode);
  const [loginMethod, setLoginMethod] = useState<'password' | 'otp'>('password');

  // Fields
  const [identifier, setIdentifier] = useState(''); // Phone or Gmail for login
  const [name, setName] = useState('');
  const [gmail, setGmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [otpCode, setOtpCode] = useState('');

  // OTP state
  const [otpSent, setOtpSent] = useState(false);
  const [simulatedCode, setSimulatedCode] = useState('');
  const [otpMessage, setOtpMessage] = useState('');

  // Status
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSendOtp = (targetIdentifier: string) => {
    setError('');
    const id = targetIdentifier.trim();
    if (!id) {
      setError('Please provide your Phone number or Gmail address to receive the verification code.');
      return;
    }

    const res = StorageService.sendVerificationCode(id, mode === 'login' ? 'login' : 'register');
    setOtpSent(true);
    setSimulatedCode(res.code);
    setOtpMessage(`Verification code sent to ${id}. Code: ${res.code}`);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please enter your full name.');
      return;
    }
    if (!gmail.trim() || (!gmail.toLowerCase().endsWith('@gmail.com') && !gmail.includes('@'))) {
      setError('Please enter a valid Gmail address (e.g. yourname@gmail.com).');
      return;
    }
    if (!phone.trim() || phone.replace(/\s+/g, '').length < 11) {
      setError('Please enter an 11-digit mobile phone number (e.g. 01516557161).');
      return;
    }
    if (!password || password.length < 6) {
      setError('Please set a secure password of at least 6 characters.');
      return;
    }
    if (!otpCode.trim()) {
      setError('Please click "Send Code" and enter the 6-digit verification code.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = StorageService.register({
        name: name.trim(),
        gmail: gmail.trim(),
        phone: phone.trim(),
        password,
        verificationCode: otpCode.trim(),
      });

      setIsSubmitting(false);
      if (res.success && res.user) {
        onSuccess(res.user);
        onClose();
      } else {
        setError(res.error || 'Registration failed. A customer profile with this Phone or Gmail may already exist.');
      }
    }, 400);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!identifier.trim()) {
      setError('Please enter your registered Phone number or Gmail address.');
      return;
    }

    if (loginMethod === 'password') {
      if (!password) {
        setError('Please enter your account password.');
        return;
      }
      setIsSubmitting(true);
      setTimeout(() => {
        const res = StorageService.login(identifier, password, false);
        setIsSubmitting(false);
        if (res.success && res.user) {
          onSuccess(res.user);
          onClose();
        } else {
          setError(res.error || 'Authentication failed. Please check your credentials or log in with OTP code.');
        }
      }, 400);
    } else {
      // OTP Login
      if (!otpCode.trim()) {
        setError('Please enter the 6-digit verification code sent to your Phone/Gmail.');
        return;
      }
      setIsSubmitting(true);
      setTimeout(() => {
        const res = StorageService.login(identifier, otpCode.trim(), true);
        setIsSubmitting(false);
        if (res.success && res.user) {
          onSuccess(res.user);
          onClose();
        } else {
          setError(res.error || 'Invalid verification code.');
        }
      }, 400);
    }
  };

  const handleResetPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!identifier.trim() || !otpCode.trim() || !newPassword.trim()) {
      setError('Please fill in your Phone/Gmail, the verification code, and your new password.');
      return;
    }

    const isValid = StorageService.verifyCode(identifier, otpCode);
    if (!isValid) {
      setError('Invalid verification code.');
      return;
    }

    const users = StorageService.getUsers();
    const cleanId = identifier.trim().toLowerCase();
    const user = users.find(
      (u) => u.email.toLowerCase() === cleanId || u.phone.replace(/\s+/g, '') === cleanId.replace(/\s+/g, '')
    );

    if (!user) {
      setError('No customer profile located with this Phone or Gmail.');
      return;
    }

    StorageService.setPassword(user.id, newPassword);
    const loginRes = StorageService.login(identifier, newPassword, false);
    if (loginRes.success && loginRes.user) {
      onSuccess(loginRes.user);
      onClose();
    }
  };

  const handleDemoSignIn = (presetUser: 'sabbir' | 'tanvir') => {
    setError('');
    setIsSubmitting(true);
    setTimeout(() => {
      const email = presetUser === 'sabbir' ? 'sabbirhasanmunna20@gmail.com' : 'tanvir.ahmed@gmail.com';
      const res = StorageService.login(email, 'password123', false);
      setIsSubmitting(false);
      if (res.success && res.user) {
        onSuccess(res.user);
        onClose();
      }
    }, 250);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/70 backdrop-blur-xs">
      <div 
        className="relative w-full max-w-md bg-white border border-stone-200 rounded-lg shadow-2xl p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-stone-900 rounded transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-5 flex flex-col items-center">
          <NAuraLogo size="sm" variant="dark" subtitle="CUSTOMER ACCESS GATEWAY" className="mb-2" />
          <h2 className="text-2xl font-serif font-medium text-stone-950 mt-1">
            {mode === 'login'
              ? 'Customer Access'
              : mode === 'register'
              ? 'Create Unique Customer Profile'
              : 'Set New Password'}
          </h2>
          <p className="text-xs text-stone-600 mt-1 leading-relaxed">
            {mode === 'login'
              ? 'Access orders, track shipments, and manage saved delivery addresses.'
              : 'Every profile is authenticated using verified Phone number and Gmail.'}
          </p>
        </div>

        {/* Mode Switcher Tabs */}
        {mode !== 'forgot_password' && (
          <div className="grid grid-cols-2 gap-1 p-1 bg-stone-100 rounded-lg mb-5 text-xs font-medium">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError('');
                setOtpSent(false);
              }}
              className={`py-2 rounded-md transition-all cursor-pointer ${
                mode === 'login'
                  ? 'bg-white text-stone-950 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-950'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError('');
                setOtpSent(false);
              }}
              className={`py-2 rounded-md transition-all cursor-pointer ${
                mode === 'register'
                  ? 'bg-white text-stone-950 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-950'
              }`}
            >
              Register (Phone + Gmail)
            </button>
          </div>
        )}

        {/* Error Alert */}
        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Simulated OTP Notification Banner */}
        {otpSent && simulatedCode && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-300 rounded text-xs text-emerald-900 space-y-1">
            <div className="flex items-center justify-between font-semibold">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Verification Code Dispatched!</span>
              </span>
              <span className="font-mono bg-emerald-200 px-2 py-0.5 rounded text-stone-950">
                {simulatedCode}
              </span>
            </div>
            <p className="text-[11px] text-emerald-800">
              Code sent to Phone & Gmail. Click below to auto-fill:
            </p>
            <button
              type="button"
              onClick={() => setOtpCode(simulatedCode)}
              className="text-[11px] text-emerald-950 underline font-semibold cursor-pointer"
            >
              Auto-fill Code: {simulatedCode}
            </button>
          </div>
        )}

        {/* ---------------- LOGIN FORM ---------------- */}
        {mode === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-3.5 text-xs">
            {/* Login Method Sub-Toggle */}
            <div className="flex justify-between items-center text-[11px] text-stone-600 pb-1">
              <span>Sign in via:</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setLoginMethod('password')}
                  className={`underline font-medium cursor-pointer ${loginMethod === 'password' ? 'text-stone-950 font-bold' : 'text-stone-500'}`}
                >
                  Password
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => {
                    setLoginMethod('otp');
                    if (identifier.trim()) handleSendOtp(identifier);
                  }}
                  className={`underline font-medium cursor-pointer ${loginMethod === 'otp' ? 'text-stone-950 font-bold' : 'text-stone-500'}`}
                >
                  Verification Code (OTP)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-stone-700 font-medium mb-1">
                Phone Number or Gmail Address <span className="text-rose-600">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  placeholder="e.g. 01516557161 or user@gmail.com"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>
            </div>

            {loginMethod === 'password' ? (
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-stone-700 font-medium">
                    Password <span className="text-rose-600">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot_password');
                      setError('');
                    }}
                    className="text-[11px] text-stone-500 hover:text-stone-900 underline cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    placeholder="Enter account password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-stone-700 font-medium">
                    6-Digit Verification Code <span className="text-rose-600">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => handleSendOtp(identifier)}
                    className="text-[11px] text-stone-700 underline font-medium hover:text-stone-950 cursor-pointer"
                  >
                    {otpSent ? 'Resend Code' : 'Send Code'}
                  </button>
                </div>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    maxLength={6}
                    placeholder="e.g. 582914 (or 123456)"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-300 rounded font-mono text-base tracking-widest text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full mt-2 py-3 bg-stone-950 hover:bg-stone-800 text-white rounded text-xs uppercase tracking-wider font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              {isSubmitting ? (
                <span>Verifying credentials...</span>
              ) : (
                <>
                  <span>Sign In to Account</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>
        )}

        {/* ---------------- REGISTER FORM ---------------- */}
        {mode === 'register' && (
          <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
            <div>
              <label className="block text-stone-700 font-medium mb-1">
                Full Name <span className="text-rose-600">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Sabbir Hasan Munna"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-stone-700 font-medium mb-1">
                Gmail Address <span className="text-rose-600">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  placeholder="yourname@gmail.com"
                  value={gmail}
                  onChange={(e) => setGmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-stone-700 font-medium mb-1">
                Mobile Phone Number <span className="text-rose-600">*</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  required
                  placeholder="01516557161"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-stone-700 font-medium mb-1">
                Create Your Password <span className="text-rose-600">*</span>
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  placeholder="Minimum 6 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white"
                />
              </div>
            </div>

            {/* OTP Verification Step during registration */}
            <div className="p-3 bg-stone-50 rounded border border-stone-200 space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-stone-900">Verification Code (Phone & Gmail):</span>
                <button
                  type="button"
                  onClick={() => handleSendOtp(phone || gmail)}
                  className="px-2.5 py-1 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded font-medium text-[11px] cursor-pointer"
                >
                  {otpSent ? 'Resend OTP' : 'Send OTP Code'}
                </button>
              </div>

              <input
                type="text"
                required
                maxLength={6}
                placeholder="Enter 6-digit code"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-stone-300 rounded font-mono text-center tracking-widest text-stone-900 text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full mt-2 py-3 bg-stone-950 hover:bg-stone-800 text-white rounded text-xs uppercase tracking-wider font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              {isSubmitting ? (
                <span>Registering unique profile...</span>
              ) : (
                <>
                  <span>Create Account & Verify</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>
        )}

        {/* ---------------- FORGOT / RESET PASSWORD FORM ---------------- */}
        {mode === 'forgot_password' && (
          <form onSubmit={handleResetPasswordSubmit} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-stone-700 font-medium mb-1">
                Your Registered Phone or Gmail
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  placeholder="e.g. 01516557161 or user@gmail.com"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="flex-1 px-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900"
                />
                <button
                  type="button"
                  onClick={() => handleSendOtp(identifier)}
                  className="px-3 py-2 bg-stone-200 hover:bg-stone-300 rounded font-medium text-stone-800 cursor-pointer"
                >
                  Send OTP
                </button>
              </div>
            </div>

            <div>
              <label className="block text-stone-700 font-medium mb-1">Verification Code</label>
              <input
                type="text"
                required
                maxLength={6}
                placeholder="6-digit OTP"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded font-mono tracking-widest text-center"
              />
            </div>

            <div>
              <label className="block text-stone-700 font-medium mb-1">Set New Password</label>
              <input
                type="password"
                required
                placeholder="Enter new password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setMode('login')}
                className="flex-1 py-2 border border-stone-300 rounded text-stone-700 hover:bg-stone-100 cursor-pointer"
              >
                Back to Sign In
              </button>
              <button
                type="submit"
                className="flex-1 py-2 bg-stone-950 text-white rounded font-semibold hover:bg-stone-800 cursor-pointer"
              >
                Save & Sign In
              </button>
            </div>
          </form>
        )}

        {/* Demo Fast Access Buttons */}
        {mode === 'login' && (
          <div className="mt-5 pt-4 border-t border-stone-200 space-y-2">
            <span className="text-[11px] text-stone-500 font-medium block text-center">
              Quick Test Authorized Profiles:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleDemoSignIn('sabbir')}
                disabled={isSubmitting}
                className="py-1.5 px-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded text-[11px] font-medium transition-colors cursor-pointer text-center"
              >
                Sabbir (01516557161)
              </button>
              <button
                type="button"
                onClick={() => handleDemoSignIn('tanvir')}
                disabled={isSubmitting}
                className="py-1.5 px-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded text-[11px] font-medium transition-colors cursor-pointer text-center"
              >
                Tanvir (01712345678)
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
