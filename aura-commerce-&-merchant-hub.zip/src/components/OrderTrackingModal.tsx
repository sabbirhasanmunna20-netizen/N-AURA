import React, { useState } from 'react';
import { Order } from '../types';
import { StorageService } from '../services/storage';
import { X, Search, Package, CheckCircle2, Clock, Truck, MapPin } from 'lucide-react';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialOrderId?: string;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  initialOrderId = '',
}) => {
  const [searchQuery, setSearchQuery] = useState(initialOrderId);
  const [foundOrder, setFoundOrder] = useState<Order | null>(() => {
    if (initialOrderId) {
      const orders = StorageService.getOrders();
      return orders.find((o) => o.id.toLowerCase() === initialOrderId.toLowerCase()) || null;
    }
    return null;
  });
  const [searched, setSearched] = useState(Boolean(initialOrderId));

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim().toLowerCase();
    if (!query) return;

    const orders = StorageService.getOrders();
    const match = orders.find(
      (o) => o.id.toLowerCase() === query || o.phone.toLowerCase().includes(query)
    );

    setFoundOrder(match || null);
    setSearched(true);
  };

  const steps = [
    { key: 'placed', label: 'Order Received' },
    { key: 'confirmed', label: 'Merchant Confirmed' },
    { key: 'processing', label: 'Inspected & Packed' },
    { key: 'shipped', label: 'Courier Handover' },
    { key: 'delivered', label: 'Delivered' },
  ];

  const getStepIndex = (status: Order['orderStatus']) => {
    switch (status) {
      case 'placed': return 0;
      case 'confirmed': return 1;
      case 'processing': return 2;
      case 'shipped': return 3;
      case 'delivered': return 4;
      case 'cancelled': return -1;
      default: return 0;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div 
        className="relative w-full max-w-2xl bg-white border border-stone-200 rounded-lg shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-stone-200 flex items-center justify-between bg-stone-50/50">
          <div>
            <span className="text-[11px] uppercase tracking-wider font-semibold text-stone-500">
              Live Courier Tracking
            </span>
            <h2 className="text-xl font-serif font-semibold text-stone-950">
              Consignment Status Monitor
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-900 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-xs">
          {/* Lookup Input */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Enter Order ID (e.g. AUR-7421) or Customer Phone"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900 font-mono text-xs uppercase"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 bg-stone-950 hover:bg-stone-800 text-white rounded font-medium cursor-pointer"
            >
              Lookup
            </button>
          </form>

          {/* Search Result */}
          {searched && !foundOrder && (
            <div className="p-8 text-center bg-stone-50 rounded-lg border border-stone-200 text-stone-500">
              <Package className="w-8 h-8 mx-auto mb-2 text-stone-400" />
              <p className="font-medium text-stone-800 mb-1">No matching order found</p>
              <p className="text-[11px]">
                Verify your order identifier or check with our dispatch team. You can view test order <code className="font-mono bg-stone-200 px-1 py-0.5 rounded text-stone-900">AUR-7421</code>.
              </p>
            </div>
          )}

          {foundOrder && (
            <div className="space-y-6">
              {/* Order Meta Bar */}
              <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 flex flex-wrap justify-between items-center gap-3">
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-stone-400 block">Consignment ID</span>
                  <span className="font-mono tabular-nums font-bold text-base text-stone-950">{foundOrder.id}</span>
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-stone-400 block">Recipient</span>
                  <span className="font-medium text-stone-800">{foundOrder.customerName}</span>
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-stone-400 block">Destination</span>
                  <span className="font-medium text-stone-800">{foundOrder.city}</span>
                </div>
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-stone-400 block">Payment Terms</span>
                  <span className="font-medium text-stone-800 uppercase font-mono">
                    {foundOrder.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Paid Online'}
                  </span>
                </div>
              </div>

              {/* Progress Stepper */}
              <div>
                <h4 className="text-xs uppercase tracking-wider font-semibold text-stone-900 mb-4">
                  Fulfillment Pipeline
                </h4>
                
                {foundOrder.orderStatus === 'cancelled' ? (
                  <div className="p-4 bg-rose-50 text-rose-800 border border-rose-200 rounded font-medium">
                    This order was cancelled by the merchant or customer.
                  </div>
                ) : (
                  <div className="relative border-l-2 border-stone-200 ml-4 pl-6 space-y-6 py-2">
                    {steps.map((step, idx) => {
                      const currentIdx = getStepIndex(foundOrder.orderStatus);
                      const isComplete = currentIdx >= idx;
                      const isCurrent = currentIdx === idx;

                      return (
                        <div key={step.key} className="relative">
                          {/* Step Marker */}
                          <div 
                            className={`absolute -left-[31px] top-0 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                              isComplete 
                                ? 'bg-stone-900 border-stone-900 text-white' 
                                : 'bg-white border-stone-300 text-stone-300'
                            }`}
                          >
                            {isComplete ? (
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            ) : (
                              <span className="w-1.5 h-1.5 rounded-full bg-stone-300" />
                            )}
                          </div>

                          {/* Step Text */}
                          <div>
                            <span className={`text-xs font-semibold ${isCurrent ? 'text-stone-950 font-bold' : isComplete ? 'text-stone-800' : 'text-stone-400'}`}>
                              {step.label}
                            </span>
                            {isCurrent && (
                              <span className="ml-2 font-mono text-[10px] uppercase px-1.5 py-0.5 bg-stone-100 text-stone-700 rounded border border-stone-300">
                                Current State
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Package Items & Address Summary */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-stone-200">
                <div className="p-3 bg-stone-50 rounded border border-stone-200">
                  <span className="text-[11px] uppercase tracking-wider text-stone-400 block mb-1 font-semibold">
                    Delivery Address
                  </span>
                  <p className="text-stone-800">{foundOrder.shippingAddress}</p>
                  <p className="text-stone-800">{foundOrder.city}, {foundOrder.postalCode}</p>
                  <p className="text-stone-600 mt-1">{foundOrder.phone}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded border border-stone-200">
                  <span className="text-[11px] uppercase tracking-wider text-stone-400 block mb-1 font-semibold">
                    Package Contents
                  </span>
                  <div className="space-y-1">
                    {foundOrder.items.map((item, i) => (
                      <div key={i} className="flex justify-between">
                        <span className="text-stone-800">{item.product.name} (x{item.quantity})</span>
                        <span className="font-mono tabular-nums text-stone-900 font-medium">
                          ৳{(item.quantity * item.product.price).toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
