import React from 'react';
import { ShoppingBag, Search, ShieldCheck, User, MessageCircle, FileText, Heart } from 'lucide-react';
import { UserProfile } from '../types';
import { WHATSAPP_SUPPORT_NUMBER, BUSINESS_LICENSE_INFO } from '../services/storage';
import { NAuraLogo } from './NAuraLogo';

interface HeaderProps {
  currentView: 'store' | 'admin';
  onNavigate: (view: 'store' | 'admin') => void;
  onOpenCart: () => void;
  onOpenTrackOrder: () => void;
  onOpenSearch: () => void;
  cartCount: number;
  currentUser?: UserProfile | null;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenLicense: () => void;
  wishlistCount?: number;
  onOpenWishlist?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onOpenCart,
  onOpenTrackOrder,
  onOpenSearch,
  cartCount,
  currentUser,
  onOpenAuth,
  onOpenProfile,
  onOpenLicense,
  wishlistCount = 0,
  onOpenWishlist,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FBFBF9]/95 backdrop-blur-md border-b border-stone-200">
      {/* Prominent Trust & Support Banner */}
      <div className="bg-stone-950 text-stone-200 text-xs py-1.5 px-4 text-center tracking-wide font-medium flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
        {/* Government License Prominent Viewer */}
        <button
          onClick={onOpenLicense}
          className="hover:text-emerald-400 text-emerald-300 font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Govt. Verified Trade License: {BUSINESS_LICENSE_INFO.licenseNumber} (View Certificate)</span>
        </button>

        <span aria-hidden="true" className="text-stone-600 hidden sm:inline">·</span>

        {/* WhatsApp Support Mention */}
        <a
          href={`https://wa.me/8801516557161?text=Hello%20Aura%20Support!`}
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-emerald-300 flex items-center gap-1 text-stone-300 transition-colors"
        >
          <MessageCircle className="w-3 h-3 text-[#25D366]" />
          <span>WhatsApp Support: <strong className="font-mono text-white">{WHATSAPP_SUPPORT_NUMBER}</strong></span>
        </a>

        <span aria-hidden="true" className="text-stone-600 hidden md:inline">·</span>

        <span className="text-stone-400 hidden md:inline">
          bKash Security Advance: ৳100 Required on Orders
        </span>
      </div>

      {/* Top Bar: Zone 1 (Brand) — Zone 2 (4-6 text nav) — Zone 3 (Primary actions) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Logo & Wordmark */}
        <button
          onClick={() => onNavigate('store')}
          className="transition-opacity hover:opacity-90 focus-visible:outline-none cursor-pointer"
          aria-label="N AURA Homepage"
        >
          <NAuraLogo size="md" variant="dark" subtitle="DHAKA · EST. 2024" />
        </button>

        {/* Zone 2: 4-6 Clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs tracking-wider uppercase font-medium text-stone-600">
          <button
            onClick={() => onNavigate('store')}
            className={`transition-colors hover:text-stone-950 cursor-pointer ${
              currentView === 'store' ? 'text-stone-950 border-b border-stone-950 pb-0.5' : ''
            }`}
          >
            Storefront
          </button>

          <a
            href="#catalog-section"
            className="transition-colors hover:text-stone-950 cursor-pointer"
          >
            Curated Catalog
          </a>

          <button
            onClick={onOpenLicense}
            className="transition-colors hover:text-stone-950 cursor-pointer flex items-center gap-1"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
            <span>Business License</span>
          </button>

          <button
            onClick={onOpenTrackOrder}
            className="transition-colors hover:text-stone-950 cursor-pointer"
          >
            Track Order
          </button>

          <button
            onClick={() => onNavigate('admin')}
            className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
              currentView === 'admin'
                ? 'text-stone-950 font-semibold'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            <span>Merchant Hub</span>
          </button>
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2.5">
          {/* Customer Authentication / Profile Button */}
          {currentUser ? (
            <button
              onClick={onOpenProfile}
              aria-label="Open customer profile and order history"
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-stone-800 hover:text-stone-950 hover:bg-stone-100 rounded-md transition-colors cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-[10px] font-serif font-bold">
                {currentUser.name[0]}
              </div>
              <div className="hidden sm:block text-left leading-tight">
                <span className="block font-semibold max-w-[90px] truncate text-stone-900">
                  {currentUser.name.split(' ')[0]}
                </span>
                <span className="block text-[10px] text-stone-400 font-mono">
                  {currentUser.phone}
                </span>
              </div>
            </button>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-stone-700 hover:text-stone-950 hover:bg-stone-100 rounded-md transition-colors cursor-pointer"
            >
              <User className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign In / Register</span>
            </button>
          )}

          <button
            onClick={onOpenSearch}
            aria-label="Search catalog"
            className="p-2 text-stone-600 hover:text-stone-950 transition-colors cursor-pointer rounded-md hover:bg-stone-100"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Wishlist / Saved Items Button */}
          <button
            onClick={onOpenWishlist}
            aria-label="View Saved Items"
            title="Saved Items / Wishlist"
            className="relative p-2 text-stone-600 hover:text-stone-950 transition-colors cursor-pointer rounded-md hover:bg-stone-100"
          >
            <Heart className={`w-4 h-4 ${wishlistCount > 0 ? 'text-rose-600 fill-rose-500' : ''}`} />
            {wishlistCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-rose-600 text-white text-[9px] font-mono font-bold flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          <button
            onClick={onOpenCart}
            aria-label="View shopping cart"
            className="relative flex items-center gap-2 px-3.5 py-2 text-xs uppercase tracking-wider font-semibold text-white bg-stone-950 hover:bg-stone-800 rounded-md transition-colors cursor-pointer whitespace-nowrap"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline">Bag</span>
            <span className="font-mono tabular-nums bg-stone-800 text-stone-200 px-1.5 py-0.5 rounded text-[11px] font-medium">
              {cartCount}
            </span>
          </button>

          {/* Mobile Admin toggle */}
          <button
            onClick={() => onNavigate(currentView === 'store' ? 'admin' : 'store')}
            className="md:hidden p-2 text-stone-600 hover:text-stone-950 rounded-md hover:bg-stone-100 cursor-pointer"
            title="Toggle Store / Admin"
          >
            <ShieldCheck className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
