import React, { useState } from 'react';
import { CartItem } from '../types';
import { X, Trash2, ArrowRight, ShoppingBag, Tag, Check } from 'lucide-react';
import { INITIAL_COUPONS } from '../services/storage';
import { globalToast } from './toast';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onProceedToCheckout: (discountPct: number, couponCode: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; percentage: number } | null>(null);
  const [couponError, setCouponError] = useState('');

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = appliedCoupon ? Math.round((subtotal * appliedCoupon.percentage) / 100) : 0;
  const isFreeShipping = subtotal >= 3000 || items.length === 0;
  const shippingFee = isFreeShipping ? 0 : 80;
  const grandTotal = Math.max(0, subtotal - discountAmount + shippingFee);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    const found = INITIAL_COUPONS.find(
      (c) => c.code.toLowerCase() === couponCode.trim().toLowerCase()
    );

    if (!found) {
      setCouponError('Invalid coupon code. Try WELCOME10');
      globalToast.error('Invalid Coupon', 'Code not recognized. Try WELCOME10 for 10% off.');
      return;
    }

    if (subtotal < found.minSpend) {
      const msg = `Minimum spend of ৳${found.minSpend} required for this coupon.`;
      setCouponError(msg);
      globalToast.warning('Coupon Minimum Spend', msg);
      return;
    }

    setAppliedCoupon({ code: found.code, percentage: found.percentage });
    setCouponCode('');
    globalToast.success('Coupon Applied', `Code ${found.code} applied (${found.percentage}% discount)!`);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-950/50 backdrop-blur-xs flex justify-end">
      <div 
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between border-l border-stone-200 animate-in slide-in-from-right duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-stone-900" />
            <h2 className="text-base font-serif font-semibold text-stone-950">
              Shopping Bag ({items.reduce((acc, i) => acc + i.quantity, 0)})
            </h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close cart"
            className="p-1.5 text-stone-400 hover:text-stone-900 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Meter & ৳100 advance deposit reminder */}
        <div className="bg-stone-50 px-6 py-2.5 border-b border-stone-200 text-xs space-y-1">
          {subtotal >= 3000 ? (
            <div className="flex items-center gap-1.5 text-emerald-800 font-medium">
              <Check className="w-3.5 h-3.5" />
              <span>Complimentary courier delivery unlocked</span>
            </div>
          ) : (
            <div className="text-stone-600">
              Add <span className="font-mono tabular-nums font-semibold text-stone-950">৳{(3000 - subtotal).toLocaleString()}</span> more for complimentary delivery.
            </div>
          )}
          <p className="text-[11px] text-stone-500">
            Initial security deposit: <strong>৳100</strong> via bKash (01516557161) required on every order.
          </p>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-6 divide-y divide-stone-100">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6">
              <div className="w-12 h-12 rounded-full border border-stone-200 flex items-center justify-center mb-3 text-stone-400">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-medium text-stone-900 mb-1">Your bag is empty</h3>
              <p className="text-xs text-stone-500 max-w-xs mb-6">
                Discover our catalog of precision audio instruments, timepieces, and artisan lifestyle essentials.
              </p>
              <button
                onClick={onClose}
                className="px-5 py-2.5 bg-stone-900 text-white text-xs uppercase tracking-wider font-semibold rounded-md hover:bg-stone-800 transition-colors cursor-pointer"
              >
                Browse Curations
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div key={item.product.id} className="py-4 flex gap-4 first:pt-0 last:pb-0">
                {/* Thumbnail */}
                <div className="w-20 h-20 bg-stone-100 rounded border border-stone-200 shrink-0 overflow-hidden">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <span className="text-[11px] uppercase tracking-wider text-stone-400">
                        {item.product.category}
                      </span>
                      <h4 className="text-sm font-semibold text-stone-900 line-clamp-1">
                        {item.product.name}
                      </h4>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.product.id)}
                      className="text-stone-400 hover:text-rose-600 transition-colors p-1 cursor-pointer"
                      title="Remove"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    {/* Stepper */}
                    <div className="flex items-center border border-stone-200 rounded bg-stone-50 text-xs">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                        className="px-2 py-1 text-stone-600 hover:text-stone-900 cursor-pointer"
                      >
                        -
                      </button>
                      <span className="px-2 font-mono tabular-nums font-medium text-stone-900">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        disabled={item.quantity >= item.product.stock}
                        className="px-2 py-1 text-stone-600 hover:text-stone-900 disabled:opacity-30 cursor-pointer"
                      >
                        +
                      </button>
                    </div>

                    {/* Price */}
                    <span className="text-sm font-semibold font-mono tabular-nums text-stone-950">
                      ৳{(item.product.price * item.quantity).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer & Checkout Action */}
        {items.length > 0 && (
          <div className="p-6 border-t border-stone-200 bg-stone-50/70 space-y-4">
            {/* Coupon Code Input */}
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Coupon code (e.g. WELCOME10)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 bg-white border border-stone-200 rounded text-xs text-stone-800 placeholder:text-stone-400 focus:outline-none focus:border-stone-900 uppercase"
                />
              </div>
              <button
                type="submit"
                className="px-3.5 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-medium rounded transition-colors cursor-pointer"
              >
                Apply
              </button>
            </form>

            {couponError && <p className="text-[11px] text-rose-600">{couponError}</p>}

            {appliedCoupon && (
              <div className="flex items-center justify-between text-xs bg-emerald-50 text-emerald-800 px-3 py-1.5 rounded border border-emerald-200">
                <span>Coupon {appliedCoupon.code} applied ({appliedCoupon.percentage}% off)</span>
                <button
                  type="button"
                  onClick={() => {
                    setAppliedCoupon(null);
                    globalToast.info('Coupon Removed', 'Discount coupon has been removed.');
                  }}
                  className="text-emerald-900 underline font-medium cursor-pointer"
                >
                  Remove
                </button>
              </div>
            )}

            {/* Calculations Breakdown */}
            <div className="space-y-1.5 text-xs text-stone-600 pt-2 border-t border-stone-200">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums font-medium text-stone-900">${subtotal.toFixed(2)}</span>
              </div>
              {appliedCoupon && (
                <div className="flex justify-between text-emerald-700">
                  <span>Discount ({appliedCoupon.percentage}%)</span>
                  <span className="font-mono tabular-nums font-medium">-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Insured Courier Delivery</span>
                <span className="font-mono tabular-nums font-medium text-stone-900">
                  {isFreeShipping ? 'Complimentary' : `$${shippingFee.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between text-sm font-semibold text-stone-950 pt-2 border-t border-stone-200">
                <span>Estimated Total</span>
                <span className="font-mono tabular-nums text-base">${grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => onProceedToCheckout(appliedCoupon ? appliedCoupon.percentage : 0, appliedCoupon ? appliedCoupon.code : '')}
              className="w-full py-3.5 px-4 bg-stone-950 hover:bg-stone-800 text-white text-xs uppercase tracking-wider font-semibold rounded-md transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
