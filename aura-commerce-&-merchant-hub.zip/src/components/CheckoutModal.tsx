import React, { useState, useEffect } from 'react';
import { CartItem, PaymentMethod, Order, UserProfile, SavedAddress } from '../types';
import { StorageService, BKASH_PAYMENT_NUMBER, WHATSAPP_SUPPORT_NUMBER, SECURITY_DEPOSIT_AMOUNT } from '../services/storage';
import { globalToast } from './toast';
import { 
  X, 
  ShieldCheck, 
  Truck, 
  Smartphone, 
  CreditCard, 
  CheckCircle2, 
  Bookmark, 
  AlertCircle, 
  Info,
  Copy,
  Check
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  discountPct: number;
  couponCode: string;
  onOrderSuccess: (order: Order) => void;
  currentUser?: UserProfile | null;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  discountPct,
  couponCode,
  onOrderSuccess,
  currentUser,
}) => {
  // Customer details
  const [customerName, setCustomerName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [city, setCity] = useState('Dhaka');
  const [postalCode, setPostalCode] = useState('1205');
  const [notes, setNotes] = useState('');
  const [saveAddressToProfile, setSaveAddressToProfile] = useState(false);

  // Payment Selection
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');

  // bKash Transaction ID (Required for ৳100 security deposit on COD, or full online payment)
  const [bkashTxId, setBkashTxId] = useState('');
  const [isTxVerified, setIsTxVerified] = useState(false);
  const [copiedNumber, setCopiedNumber] = useState(false);

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Auto-fill logged-in user profile & saved addresses
  useEffect(() => {
    if (currentUser) {
      setCustomerName(currentUser.name || '');
      setEmail(currentUser.email || '');
      setPhone(currentUser.phone || '');

      const defaultAddr = currentUser.addresses?.find((a) => a.isDefault) || currentUser.addresses?.[0];
      if (defaultAddr) {
        setShippingAddress(defaultAddr.streetAddress);
        setCity(defaultAddr.city);
        setPostalCode(defaultAddr.postalCode);
      }
    }
  }, [currentUser, isOpen]);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = Math.round((subtotal * discountPct) / 100);
  const isFreeShipping = subtotal >= 3000;
  const shippingFee = isFreeShipping ? 0 : 80; // Standard Dhaka courier fee
  const total = Math.max(0, subtotal - discountAmount + shippingFee);

  // Security deposit calculation
  const securityDeposit = SECURITY_DEPOSIT_AMOUNT; // 100 Taka
  const remainingDueOnDelivery = paymentMethod === 'cod' ? Math.max(0, total - securityDeposit) : 0;
  const amountToPayNowViaBkash = paymentMethod === 'cod' ? securityDeposit : total;

  const handleCopyBkash = () => {
    navigator.clipboard.writeText(BKASH_PAYMENT_NUMBER);
    setCopiedNumber(true);
    globalToast.info('Number Copied', `Official bKash wallet ${BKASH_PAYMENT_NUMBER} copied to clipboard.`);
    setTimeout(() => setCopiedNumber(false), 2500);
  };

  const handleSimulateAutoVerifyTx = () => {
    const randomTrx = 'BK9X' + Math.floor(10000000 + Math.random() * 90000000).toString();
    setBkashTxId(randomTrx);
    setIsTxVerified(true);
    globalToast.success('Transaction Verified', `bKash TrxID ${randomTrx} verified for ৳${amountToPayNowViaBkash}`);
  };

  const handleSelectSavedAddress = (addr: SavedAddress) => {
    setCustomerName(addr.recipientName);
    setPhone(addr.phone);
    setShippingAddress(addr.streetAddress);
    setCity(addr.city);
    setPostalCode(addr.postalCode);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!customerName.trim() || !phone.trim() || !shippingAddress.trim() || !city.trim()) {
      setErrorMsg('Please complete all required delivery details.');
      return;
    }

    if (!bkashTxId.trim() || bkashTxId.trim().length < 6) {
      setErrorMsg('Mandatory Initial Security Payment: Please send ৳100 to bKash number 01516557161 and enter the Transaction ID.');
      return;
    }

    setIsProcessing(true);

    // Automatic verification step
    setTimeout(() => {
      try {
        if (currentUser && saveAddressToProfile) {
          StorageService.addAddress({
            label: `${city.trim()} Address`,
            recipientName: customerName.trim(),
            phone: phone.trim(),
            streetAddress: shippingAddress.trim(),
            city: city.trim(),
            postalCode: postalCode.trim(),
            isDefault: false,
          });
        }

        const order = StorageService.createOrder({
          userId: currentUser?.id,
          customerName: customerName.trim(),
          email: email.trim() || currentUser?.email || 'customer@gmail.com',
          phone: phone.trim(),
          shippingAddress: shippingAddress.trim(),
          city: city.trim(),
          postalCode: postalCode.trim(),
          notes: notes.trim(),
          items,
          subtotal,
          shippingFee,
          discount: discountAmount,
          total,
          securityDepositTxId: bkashTxId.trim().toUpperCase(),
          paymentMethod: paymentMethod === 'cod' ? 'cod' : 'mfs_bkash',
          paymentStatus: paymentMethod === 'cod' ? 'verified' : 'paid',
          transactionId: bkashTxId.trim().toUpperCase(),
        });

        setIsProcessing(false);
        onOrderSuccess(order);
      } catch (err) {
        setIsProcessing(false);
        setErrorMsg('Failed to process order dispatch. Please verify bKash Transaction ID.');
      }
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div 
        className="relative w-full max-w-3xl bg-white border border-stone-200 rounded-lg shadow-2xl overflow-hidden my-auto text-xs"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-stone-200 flex items-center justify-between bg-stone-50/60">
          <div>
            <span className="text-[11px] uppercase tracking-wider font-semibold text-stone-500 font-mono">
              Direct Consignment Checkout
            </span>
            <h2 className="text-xl font-serif font-semibold text-stone-950">
              Complete Purchase & Secure Dispatch
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-900 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-7 space-y-6 max-h-[80vh] overflow-y-auto">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* User Quick Address Selector */}
          {currentUser && (currentUser.addresses || []).length > 0 && (
            <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200">
              <span className="font-semibold text-stone-900 block mb-2 flex items-center gap-1.5">
                <Bookmark className="w-3.5 h-3.5 text-stone-700" />
                <span>Fill From Your Saved Addresses:</span>
              </span>
              <div className="flex flex-wrap gap-2">
                {currentUser.addresses.map((addr) => (
                  <button
                    key={addr.id}
                    type="button"
                    onClick={() => handleSelectSavedAddress(addr)}
                    className="px-3 py-1.5 bg-white border border-stone-300 hover:border-stone-900 rounded text-stone-800 font-medium transition-colors cursor-pointer flex items-center gap-1 text-[11px]"
                  >
                    <span>{addr.label}</span>
                    <span className="text-stone-400">({addr.city})</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Section 1: Customer Contact & Delivery Address */}
          <div>
            <h3 className="text-xs uppercase tracking-wider font-semibold text-stone-900 mb-3 flex items-center gap-2">
              <Truck className="w-4 h-4 text-stone-700" />
              <span>1. Customer & Shipping Destination</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-stone-700 font-medium mb-1">
                  Recipient Name <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sabbir Hasan Munna"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">
                  Contact Phone Number <span className="text-rose-600">*</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="01516557161"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">
                  Gmail Address (Order Receipt) <span className="text-rose-600">*</span>
                </label>
                <input
                  type="email"
                  required
                  placeholder="yourname@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">
                  City / District <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dhaka or Chittagong"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-stone-700 font-medium mb-1">
                  Street Address & Thana <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="House number, road number, area, landmark"
                  value={shippingAddress}
                  onChange={(e) => setShippingAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Postal Code</label>
                <input
                  type="text"
                  placeholder="e.g. 1205"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Special Delivery Note</label>
                <input
                  type="text"
                  placeholder="e.g. Call before delivery"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900"
                />
              </div>

              {currentUser && (
                <div className="sm:col-span-2 flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="saveAddressCheckbox"
                    checked={saveAddressToProfile}
                    onChange={(e) => setSaveAddressToProfile(e.target.checked)}
                    className="rounded border-stone-300 text-stone-900 cursor-pointer"
                  />
                  <label htmlFor="saveAddressCheckbox" className="text-stone-700 cursor-pointer text-xs">
                    Save this delivery destination to my profile
                  </label>
                </div>
              )}
            </div>
          </div>

          {/* Section 2: Payment Method Choice */}
          <div className="pt-4 border-t border-stone-200">
            <h3 className="text-xs uppercase tracking-wider font-semibold text-stone-900 mb-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-stone-700" />
              <span>2. Delivery Settlement Preference</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
              {/* Option 1: Cash on Delivery with ৳100 advance */}
              <button
                type="button"
                onClick={() => setPaymentMethod('cod')}
                className={`p-3.5 rounded-lg border text-left transition-all cursor-pointer ${
                  paymentMethod === 'cod'
                    ? 'border-stone-950 bg-stone-50 ring-1 ring-stone-950'
                    : 'border-stone-200 hover:border-stone-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-stone-900">Cash on Delivery (COD)</span>
                  <Truck className="w-4 h-4 text-stone-700" />
                </div>
                <p className="text-[11px] text-stone-500 leading-snug">
                  Pay <strong>৳100</strong> initial security deposit now via bKash; pay remaining <strong>৳{remainingDueOnDelivery}</strong> cash at doorstep.
                </p>
              </button>

              {/* Option 2: Full Online Payment via bKash */}
              <button
                type="button"
                onClick={() => setPaymentMethod('mfs_bkash')}
                className={`p-3.5 rounded-lg border text-left transition-all cursor-pointer ${
                  paymentMethod === 'mfs_bkash'
                    ? 'border-pink-800 bg-pink-50/40 ring-1 ring-pink-800'
                    : 'border-stone-200 hover:border-stone-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-pink-900">Full Online Payment (bKash)</span>
                  <Smartphone className="w-4 h-4 text-pink-700" />
                </div>
                <p className="text-[11px] text-stone-500 leading-snug">
                  Pay full order total <strong>৳{total}</strong> directly to our bKash number ({BKASH_PAYMENT_NUMBER}) with instant auto-verification.
                </p>
              </button>
            </div>

            {/* MANDATORY ৳100 SECURITY PAYMENT & BKASH INSTRUCTIONS */}
            <div className="p-4 bg-pink-50/60 rounded-lg border border-pink-200 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-pink-950 text-xs">
                    <ShieldCheck className="w-4 h-4 text-pink-700" />
                    <span>
                      {paymentMethod === 'cod'
                        ? 'Initial Security Payment: ৳100 Required via bKash'
                        : 'Full Order Payment: ৳' + total + ' via bKash'}
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    {paymentMethod === 'cod' ? (
                      <>
                        An initial security payment of <strong>100 Taka (৳100)</strong> is mandatory for every Cash on Delivery order to protect against uncollected parcels. The remaining <strong>৳{remainingDueOnDelivery}</strong> will be collected in cash upon arrival.
                      </>
                    ) : (
                      <>
                        Please send the full order payment of <strong>৳{total}</strong> to our verified bKash wallet.
                      </>
                    )}
                  </p>
                </div>

                <div className="shrink-0 text-right">
                  <span className="text-[10px] uppercase font-mono text-stone-400 block">Payable Now</span>
                  <span className="font-mono text-base font-bold text-pink-950">
                    ৳{amountToPayNowViaBkash}
                  </span>
                </div>
              </div>

              {/* bKash Instructions Box */}
              <div className="p-3 bg-white rounded border border-pink-200/80 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-stone-600 font-medium">bKash Number:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-bold text-stone-950">
                      {BKASH_PAYMENT_NUMBER}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyBkash}
                      className="px-2 py-0.5 bg-stone-100 hover:bg-stone-200 rounded text-[11px] text-stone-700 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedNumber ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedNumber ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>

                <div className="text-[11px] text-stone-500 pt-1 border-t border-stone-100 flex justify-between">
                  <span>Method: <strong>Send Money</strong> or <strong>Payment</strong></span>
                  <span>Reference: <strong>{customerName.split(' ')[0] || 'AURA'}</strong></span>
                </div>
              </div>

              {/* bKash Transaction ID Input */}
              <div>
                <label className="block text-stone-800 font-semibold mb-1">
                  Enter bKash Transaction ID (TrxID) <span className="text-rose-600">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    placeholder="e.g. BK9X7710294A"
                    value={bkashTxId}
                    onChange={(e) => {
                      setBkashTxId(e.target.value.toUpperCase());
                      setIsTxVerified(e.target.value.trim().length >= 8);
                    }}
                    className="flex-1 px-3 py-2 bg-white border border-stone-300 rounded font-mono font-semibold text-stone-900 focus:outline-none focus:border-stone-950 uppercase"
                  />

                  <button
                    type="button"
                    onClick={handleSimulateAutoVerifyTx}
                    className="px-3 py-2 bg-pink-100 hover:bg-pink-200 text-pink-900 rounded font-medium cursor-pointer text-[11px]"
                  >
                    Simulate Auto-Verify TrxID
                  </button>
                </div>

                {isTxVerified && (
                  <p className="text-[11px] text-emerald-700 font-medium mt-1.5 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>
                      bKash Transaction Verified: ৳{amountToPayNowViaBkash} payment confirmed on system.
                    </span>
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Breakdown & Totals */}
          <div className="pt-4 border-t border-stone-200 bg-stone-50 p-4 rounded-lg space-y-2">
            <div className="flex justify-between text-stone-600">
              <span>Items Total ({items.reduce((acc, i) => acc + i.quantity, 0)} items)</span>
              <span className="font-mono tabular-nums font-semibold">৳{subtotal.toLocaleString()}</span>
            </div>

            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-700">
                <span>Discount Applied ({couponCode})</span>
                <span className="font-mono tabular-nums font-semibold">-৳{discountAmount.toLocaleString()}</span>
              </div>
            )}

            <div className="flex justify-between text-stone-600">
              <span>Insured Courier Delivery</span>
              <span className="font-mono tabular-nums font-semibold">
                {isFreeShipping ? 'Complimentary' : `৳${shippingFee}`}
              </span>
            </div>

            <div className="flex justify-between text-stone-950 font-bold pt-2 border-t border-stone-200 text-sm">
              <span>Grand Total</span>
              <span className="font-mono tabular-nums text-base">৳{total.toLocaleString()}</span>
            </div>

            {paymentMethod === 'cod' && (
              <div className="pt-2 border-t border-stone-200/80 space-y-1 text-[11px]">
                <div className="flex justify-between text-pink-800 font-semibold">
                  <span>Advance Security Deposit Paid (bKash)</span>
                  <span className="font-mono">-৳100</span>
                </div>
                <div className="flex justify-between text-stone-900 font-bold bg-amber-50 p-2 rounded border border-amber-200">
                  <span>Cash to Collect at Doorstep Delivery</span>
                  <span className="font-mono text-sm">৳{remainingDueOnDelivery.toLocaleString()}</span>
                </div>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isProcessing}
            className={`w-full py-3.5 px-6 rounded-md text-xs uppercase tracking-wider font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm ${
              isProcessing
                ? 'bg-stone-700 text-white cursor-wait'
                : 'bg-stone-950 hover:bg-stone-800 text-white'
            }`}
          >
            {isProcessing ? (
              <span>Verifying bKash Transaction & Dispatching...</span>
            ) : (
              <span>
                {paymentMethod === 'cod'
                  ? `Verify ৳100 Deposit & Dispatch (৳${remainingDueOnDelivery} on Delivery)`
                  : `Confirm bKash Order Payment (৳${total.toLocaleString()})`}
              </span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
