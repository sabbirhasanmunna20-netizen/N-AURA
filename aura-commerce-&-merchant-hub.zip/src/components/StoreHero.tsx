import React from 'react';
import heroImg from '../assets/images/hero_modern_lifestyle_1790452703883.jpg';
import { ArrowDown, Check, ShieldCheck, Truck, FileText, MessageCircle, ExternalLink } from 'lucide-react';
import { BUSINESS_LICENSE_INFO, WHATSAPP_SUPPORT_NUMBER, BKASH_PAYMENT_NUMBER } from '../services/storage';

interface StoreHeroProps {
  onExploreClick: () => void;
  onOpenLicense?: () => void;
}

export const StoreHero: React.FC<StoreHeroProps> = ({ onExploreClick, onOpenLicense }) => {
  return (
    <section className="relative border-b border-stone-200 overflow-hidden bg-[#FBFBF9]">
      {/* Prominent Business Accreditation Bar immediately visible upon site visit */}
      <div className="bg-emerald-950 text-emerald-100 border-b border-emerald-900/60 py-2.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 text-center md:text-left">
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-800 text-emerald-200 font-mono text-[11px] font-semibold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
              VERIFIED MERCHANT
            </span>
            <span className="font-medium text-white">
              Official Registered Trade License: <strong>{BUSINESS_LICENSE_INFO.licenseNumber}</strong>
            </span>
            <span className="hidden sm:inline text-emerald-400">·</span>
            <span className="text-emerald-300 hidden sm:inline">{BUSINESS_LICENSE_INFO.entityName}</span>
          </div>

          <div className="flex items-center gap-3">
            {onOpenLicense && (
              <button
                onClick={onOpenLicense}
                className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-200 hover:text-white underline underline-offset-2 transition-colors cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>View Official License Document</span>
              </button>
            )}

            <span className="text-emerald-700">|</span>

            <a
              href={`https://wa.me/8801516557161?text=Hello%20Aura%20Support!`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#25D366] hover:bg-[#20bd5a] text-stone-950 rounded text-[11px] font-bold transition-colors cursor-pointer shadow-xs"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-current" />
              <span>WhatsApp: {WHATSAPP_SUPPORT_NUMBER}</span>
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-18">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Left Column: Editorial Typography & Intent */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="text-xs uppercase tracking-widest text-stone-500 font-medium mb-3">
              Spring / Autumn Curations
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-medium tracking-tight text-stone-950 leading-[1.12] mb-6 [text-wrap:balance]">
              Objects of quiet distinction, designed to endure.
            </h1>

            <p className="text-stone-600 text-base sm:text-lg leading-relaxed mb-6 max-w-xl">
              An architectural collection of daily instruments, audio flagships, and artisanal living goods. Hand-inspected, serialized, and backed by verified Dhaka fulfillment.
            </p>

            {/* Essential Merchant Notice: ৳100 Security Advance & bKash Support */}
            <div className="mb-8 p-3.5 bg-stone-100 border border-stone-200/90 rounded-lg text-xs space-y-1.5 max-w-xl">
              <div className="flex items-center justify-between font-semibold text-stone-900">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>Order Assurance & Courier Protocol:</span>
                </span>
                <span className="font-mono text-emerald-800">bKash: {BKASH_PAYMENT_NUMBER}</span>
              </div>
              <p className="text-[11px] text-stone-600 leading-relaxed">
                An initial security payment of <strong>100 Taka (৳100)</strong> is required for every order to prevent uncollected dispatches. The system automatically verifies your bKash Transaction ID instantly upon checkout.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={onExploreClick}
                className="px-6 py-3.5 bg-stone-950 hover:bg-stone-800 text-white text-xs uppercase tracking-wider font-semibold rounded-md transition-all cursor-pointer flex items-center gap-2 group shadow-sm"
              >
                <span>Browse The Catalog</span>
                <ArrowDown className="w-3.5 h-3.5 group-hover:translate-y-0.5 transition-transform" />
              </button>

              {onOpenLicense && (
                <button
                  onClick={onOpenLicense}
                  className="px-6 py-3.5 bg-white hover:bg-stone-100 text-stone-800 border border-stone-300 text-xs uppercase tracking-wider font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-2"
                >
                  <FileText className="w-3.5 h-3.5 text-emerald-700" />
                  <span>View Business License</span>
                </button>
              )}
            </div>

            {/* Adjacent Proof / Trust Markers */}
            <div className="mt-10 pt-6 border-t border-stone-200/80 grid grid-cols-3 gap-4 text-xs text-stone-600">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-stone-800 shrink-0" />
                <span className="leading-snug">Inspected Dispatch</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-stone-800 shrink-0" />
                <span className="leading-snug">Cash on Delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-stone-800 shrink-0" />
                <span className="leading-snug">৳100 bKash Advance</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Asset */}
          <div className="lg:col-span-6">
            <div className="relative aspect-[16/10] sm:aspect-[16/9] lg:aspect-[4/3] rounded-lg overflow-hidden border border-stone-200 shadow-md bg-stone-100">
              <img
                src={heroImg}
                alt="N AURA Studio Curated Living Showcase"
                className="w-full h-full object-cover object-center transform hover:scale-[1.01] transition-transform duration-700 ease-out"
                loading="eager"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  const target = e.currentTarget;
                  target.style.display = 'none';
                  if (target.parentElement) {
                    target.parentElement.innerHTML = `
                      <div class="w-full h-full flex flex-col items-center justify-center bg-stone-100 text-stone-600 p-8 text-center">
                        <span class="font-serif text-2xl mb-2 text-stone-900">N AURA ARCHIVE</span>
                        <span class="text-xs uppercase tracking-wider">Objects of enduring distinction</span>
                      </div>
                    `;
                  }
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/20 via-transparent to-transparent pointer-events-none" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
