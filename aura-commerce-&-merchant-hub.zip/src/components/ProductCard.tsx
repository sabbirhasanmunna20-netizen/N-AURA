import React from 'react';
import { Product } from '../types';
import { ShoppingBag, Eye, Star, Heart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  isWishlisted?: boolean;
  onToggleWishlist?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onSelectProduct,
  isWishlisted = false,
  onToggleWishlist,
}) => {
  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= 5;

  return (
    <article className="group flex flex-col bg-white border border-stone-200/90 rounded-lg overflow-hidden hover:border-stone-400 hover:shadow-sm transition-all duration-300 relative">
      {/* Wishlist Heart Button */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onToggleWishlist?.(product);
        }}
        aria-label={isWishlisted ? `Remove ${product.name} from Saved Items` : `Save ${product.name} to Saved Items`}
        title={isWishlisted ? 'Saved in your Saved Items' : 'Save item to Wishlist'}
        className={`absolute top-3 right-3 z-10 p-2 rounded-full transition-all duration-200 cursor-pointer shadow-xs ${
          isWishlisted
            ? 'bg-white text-rose-600 border border-rose-200 shadow-sm scale-105'
            : 'bg-white/85 backdrop-blur-xs text-stone-500 hover:text-rose-600 hover:bg-white border border-stone-200/80 hover:scale-105'
        }`}
      >
        <Heart className={`w-4 h-4 transition-colors ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
      </button>

      {/* Product Image Area */}
      <div 
        onClick={() => onSelectProduct(product)}
        className="relative aspect-[4/3] bg-stone-100 overflow-hidden cursor-pointer"
      >
        <img
          src={product.images[0]}
          alt={product.name}
          referrerPolicy="no-referrer"
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
          onError={(e) => {
            const target = e.currentTarget;
            target.style.display = 'none';
            const parent = target.parentElement;
            if (parent) {
              const fallback = parent.querySelector('.card-img-fallback');
              if (fallback) (fallback as HTMLElement).style.display = 'flex';
            }
          }}
        />

        {/* Resilient Zero-Broken-Image Fallback */}
        <div 
          className="card-img-fallback hidden absolute inset-0 flex-col items-center justify-center bg-stone-100 text-stone-500 p-4 text-center"
        >
          <div className="w-10 h-10 rounded-full border border-stone-300 flex items-center justify-center mb-2 font-serif text-stone-700 text-sm">
            {product.category[0]}
          </div>
          <span className="text-xs uppercase tracking-wider font-medium text-stone-700">{product.name}</span>
        </div>

        {/* Subtle Text Tag (Non-pill, clean unboxed typographic indicator) */}
        {product.tag && (
          <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-[11px] font-medium tracking-wider uppercase text-stone-800 px-2.5 py-1 rounded-sm border border-stone-200/60 shadow-xs">
            {product.tag}
          </div>
        )}

        {/* Quick View Button on Image hover */}
        <div className="absolute inset-0 bg-stone-950/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="px-3.5 py-1.5 bg-white text-stone-900 text-xs font-semibold uppercase tracking-wider rounded shadow-sm flex items-center gap-1.5">
            <Eye className="w-3.5 h-3.5" />
            <span>Inspect</span>
          </span>
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Metadata: Category & Stock info with typographic separator */}
          <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-stone-500 mb-1.5">
            <span>{product.category}</span>
            <span aria-hidden="true" className="text-stone-300">·</span>
            {isOutOfStock ? (
              <span className="text-rose-700 font-medium">Sold Out</span>
            ) : isLowStock ? (
              <span className="text-amber-700 font-medium">Only {product.stock} Left</span>
            ) : (
              <span className="text-stone-500">In Stock ({product.stock})</span>
            )}
          </div>

          {/* Product Name */}
          <h3 
            onClick={() => onSelectProduct(product)}
            className="text-base font-semibold text-stone-900 group-hover:text-stone-700 transition-colors line-clamp-1 cursor-pointer"
          >
            {product.name}
          </h3>

          <p className="mt-1.5 text-xs text-stone-600 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Pricing & Interactive Action */}
        <div className="mt-5 pt-4 border-t border-stone-100 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-semibold font-mono tabular-nums text-stone-950">
              ৳{product.price.toLocaleString()}
            </span>
            {product.originalPrice && (
              <span className="text-xs font-mono tabular-nums text-stone-400 line-through">
                ৳{product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-1 text-xs text-stone-500">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              <span className="font-mono tabular-nums font-medium text-stone-700">{product.rating}</span>
            </div>

            <button
              onClick={() => onAddToCart(product)}
              disabled={isOutOfStock}
              aria-label={`Add ${product.name} to cart`}
              className={`px-3 py-1.5 rounded-md text-xs font-medium uppercase tracking-wider transition-colors flex items-center gap-1.5 cursor-pointer ${
                isOutOfStock
                  ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                  : 'bg-stone-900 text-white hover:bg-stone-800 active:scale-95'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </div>
        </div>
      </div>
    </article>
  );
};
