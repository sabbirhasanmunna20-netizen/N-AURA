import React from 'react';
import { BUSINESS_LICENSE_INFO } from '../services/storage';
import { NAuraLogo } from './NAuraLogo';
import { X, ShieldCheck, Award, FileCheck, CheckCircle2, Printer, ExternalLink, QrCode } from 'lucide-react';

interface BusinessLicenseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BusinessLicenseModal: React.FC<BusinessLicenseModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const license = BUSINESS_LICENSE_INFO;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div 
        className="relative w-full max-w-2xl bg-white border-2 border-stone-300 rounded-lg shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Certificate Top Border Ribbon */}
        <div className="h-2.5 bg-gradient-to-r from-emerald-800 via-stone-900 to-amber-700" />

        {/* Certificate Header */}
        <div className="p-6 sm:p-8 text-center bg-stone-50 border-b border-stone-200 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-stone-900 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-full border-2 border-stone-800 flex items-center justify-center bg-white shadow-xs">
              <Award className="w-6 h-6 text-emerald-800" />
            </div>
            <NAuraLogo size="sm" variant="dark" subtitle="AUTHORIZED COMMERCIAL ENTERPRISE" />
          </div>

          <span className="text-[11px] uppercase tracking-widest font-mono font-semibold text-stone-500 block">
            Government of the People's Republic of Bangladesh
          </span>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-stone-950 mt-1">
            OFFICIAL DIGITAL COMMERCE E-TRADE LICENSE
          </h2>
          <p className="text-xs text-stone-600 mt-1">
            {license.issuingAuthority}
          </p>

          <div className="inline-flex items-center gap-1.5 mt-3 px-3 py-1 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded text-xs font-semibold">
            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
            <span>Government Verified & In Good Standing</span>
          </div>
        </div>

        {/* Certificate Body Details */}
        <div className="p-6 sm:p-8 space-y-6 text-xs max-h-[70vh] overflow-y-auto">
          {/* License Number Headline */}
          <div className="p-4 bg-stone-100/70 border border-stone-300 rounded-lg flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-stone-500 font-medium block">
                Trade Registration Certificate No.
              </span>
              <span className="font-mono text-base font-bold text-stone-950">
                {license.licenseNumber}
              </span>
            </div>
            <div className="text-right">
              <span className="text-[11px] uppercase tracking-wider text-stone-500 font-medium block">
                Validity Status
              </span>
              <span className="font-semibold text-emerald-800 font-mono">
                {license.validUntil}
              </span>
            </div>
          </div>

          {/* Grid of Verified Business Credentials */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 bg-stone-50 rounded border border-stone-200 space-y-1">
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider font-medium">
                Registered Legal Entity
              </span>
              <p className="font-semibold text-stone-950 text-sm">{license.entityName}</p>
            </div>

            <div className="p-3.5 bg-stone-50 rounded border border-stone-200 space-y-1">
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider font-medium">
                Authorized Proprietor / Merchant
              </span>
              <p className="font-semibold text-stone-950 text-sm">{license.proprietor}</p>
            </div>

            <div className="p-3.5 bg-stone-50 rounded border border-stone-200 space-y-1">
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider font-medium">
                Taxpayer Identification Number (TIN)
              </span>
              <p className="font-mono font-semibold text-stone-900">{license.tinNumber}</p>
            </div>

            <div className="p-3.5 bg-stone-50 rounded border border-stone-200 space-y-1">
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider font-medium">
                Business Identification Number (BIN / VAT)
              </span>
              <p className="font-mono font-semibold text-stone-900">{license.binNumber}</p>
            </div>

            <div className="sm:col-span-2 p-3.5 bg-stone-50 rounded border border-stone-200 space-y-1">
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider font-medium">
                Authorized Nature of Trade & Business
              </span>
              <p className="font-medium text-stone-800">{license.businessType}</p>
            </div>

            <div className="sm:col-span-2 p-3.5 bg-stone-50 rounded border border-stone-200 space-y-1">
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider font-medium">
                Registered Physical Establishment Address
              </span>
              <p className="font-medium text-stone-800">{license.registeredAddress}</p>
            </div>
          </div>

          {/* Official Seals and Customer Protection Clause */}
          <div className="p-4 bg-emerald-50/60 rounded-lg border border-emerald-200 text-stone-700 space-y-2">
            <h4 className="font-semibold text-emerald-950 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Consumer Protection & Verified Commerce Seal</span>
            </h4>
            <p className="text-[11px] leading-relaxed text-stone-600">
              This digital enterprise operates under full statutory compliance with Bangladeshi e-commerce guidelines. All online payments through our verified bKash wallet (<strong>{license.bkashNumber}</strong>) and ৳100 advance order confirmations are legally receipted. Direct telephone & WhatsApp grievance support is available at <strong>{license.whatsappSupport}</strong>.
            </p>
          </div>
        </div>

        {/* Certificate Footer Actions */}
        <div className="p-5 border-t border-stone-200 bg-stone-50 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-stone-500 font-mono text-[11px]">
            <span>Issuance: {license.issueDate}</span>
            <span aria-hidden="true">·</span>
            <span>DSCC Portal Verified</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 border border-stone-300 rounded font-medium text-stone-700 hover:bg-stone-100 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Certificate</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-stone-950 text-white rounded font-semibold hover:bg-stone-800 transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
