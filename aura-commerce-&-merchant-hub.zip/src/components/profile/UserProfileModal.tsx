import React, { useState, useEffect } from 'react';
import { UserProfile, Order, SavedAddress, SavedPaymentMethod, CartItem, Product, OrderStatus } from '../../types';
import { StorageService } from '../../services/storage';
import { globalToast } from '../toast';
import { 
  X, 
  User, 
  MapPin, 
  CreditCard, 
  Package, 
  LogOut, 
  Plus, 
  Trash2, 
  Check, 
  Truck, 
  Smartphone, 
  RotateCcw,
  CheckCircle2,
  Calendar,
  Eye,
  Clock,
  CheckCircle,
  Box,
  XCircle,
  AlertCircle,
  Heart,
  ShoppingBag,
  Star
} from 'lucide-react';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onUserUpdated: (user: UserProfile) => void;
  onLogout: () => void;
  onTrackOrder: (orderId: string) => void;
  onInspectOrder: (order: Order) => void;
  onReorder: (items: CartItem[]) => void;
  onAddToCart?: (product: Product) => void;
  onInspectProduct?: (product: Product) => void;
  initialTab?: 'orders' | 'wishlist' | 'addresses' | 'payments' | 'account';
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onUserUpdated,
  onLogout,
  onTrackOrder,
  onInspectOrder,
  onReorder,
  onAddToCart,
  onInspectProduct,
  initialTab = 'orders',
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'wishlist' | 'addresses' | 'payments' | 'account'>(initialTab);
  const [addedItemMap, setAddedItemMap] = useState<Record<string, boolean>>({});
  const [wishlistMessage, setWishlistMessage] = useState<string>('');

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Address form state
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [addrLabel, setAddrLabel] = useState('Primary Residence');
  const [addrRecipient, setAddrRecipient] = useState(user.name);
  const [addrPhone, setAddrPhone] = useState(user.phone);
  const [addrStreet, setAddrStreet] = useState('');
  const [addrCity, setAddrCity] = useState('');
  const [addrPostal, setAddrPostal] = useState('');
  const [addrIsDefault, setAddrIsDefault] = useState(false);

  // Payment form state
  const [isAddingPayment, setIsAddingPayment] = useState(false);
  const [pmType, setPmType] = useState<SavedPaymentMethod['type']>('cod');
  const [pmLabel, setPmLabel] = useState('Standard Cash on Delivery');
  const [pmDetails, setPmDetails] = useState('Pay in cash upon doorstep delivery');

  // Profile details form
  const [profileName, setProfileName] = useState(user.name);
  const [profilePhone, setProfilePhone] = useState(user.phone);
  const [saveSuccess, setSaveSuccess] = useState('');

  // Password management state
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Visual status badge helper with color-coded styling
  const renderOrderStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'placed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide bg-blue-50 text-blue-800 border border-blue-200/90 shadow-2xs">
            <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>Pending Placement</span>
          </span>
        );
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide bg-amber-50 text-amber-800 border border-amber-200/90 shadow-2xs">
            <CheckCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span>Order Confirmed</span>
          </span>
        );
      case 'processing':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide bg-purple-50 text-purple-800 border border-purple-200/90 shadow-2xs">
            <Box className="w-3.5 h-3.5 text-purple-600 shrink-0 animate-pulse" />
            <span>Processing in Atelier</span>
          </span>
        );
      case 'shipped':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide bg-indigo-50 text-indigo-800 border border-indigo-200/90 shadow-2xs">
            <Truck className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            <span>Out for Delivery</span>
          </span>
        );
      case 'delivered':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide bg-emerald-50 text-emerald-800 border border-emerald-300 shadow-2xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Delivered & Received</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide bg-rose-50 text-rose-800 border border-rose-200/90 shadow-2xs">
            <XCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
            <span>Cancelled</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide bg-stone-100 text-stone-800 border border-stone-200">
            <Package className="w-3.5 h-3.5 text-stone-600 shrink-0" />
            <span className="capitalize">{status}</span>
          </span>
        );
    }
  };

  if (!isOpen) return null;

  const userOrders = StorageService.getUserOrders(user);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = StorageService.updateProfile({
      name: profileName.trim(),
      phone: profilePhone.trim(),
    });
    if (updated) {
      onUserUpdated(updated);
      setSaveSuccess('Profile information saved successfully.');
      setTimeout(() => setSaveSuccess(''), 3000);
    }
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (!newPassword || newPassword.length < 6) {
      setPasswordError('Password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('Passwords do not match. Please re-enter.');
      return;
    }

    const ok = StorageService.setPassword(user.id, newPassword);
    if (ok) {
      setPasswordSuccess('Your account password has been updated.');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPasswordSuccess(''), 4000);
    } else {
      setPasswordError('Failed to update password.');
    }
  };

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addrStreet.trim() || !addrCity.trim() || !addrPostal.trim()) return;

    StorageService.addAddress({
      label: addrLabel.trim() || 'Delivery Address',
      recipientName: addrRecipient.trim() || user.name,
      phone: addrPhone.trim() || user.phone,
      streetAddress: addrStreet.trim(),
      city: addrCity.trim(),
      postalCode: addrPostal.trim(),
      isDefault: addrIsDefault,
    });

    const refreshed = StorageService.getCurrentUser();
    if (refreshed) onUserUpdated(refreshed);

    setIsAddingAddress(false);
    setAddrStreet('');
    setAddrCity('');
    setAddrPostal('');
    globalToast.success('Address Saved', 'New delivery address has been saved to your profile.');
  };

  const handleDeleteAddress = (id: string) => {
    StorageService.deleteAddress(id);
    const refreshed = StorageService.getCurrentUser();
    if (refreshed) onUserUpdated(refreshed);
    globalToast.info('Address Removed', 'Delivery address removed from profile.');
  };

  const handleSetDefaultAddress = (id: string) => {
    StorageService.setDefaultAddress(id);
    const refreshed = StorageService.getCurrentUser();
    if (refreshed) onUserUpdated(refreshed);
    globalToast.success('Default Address', 'Default shipping address updated.');
  };

  const handleAddPayment = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.addPaymentMethod({
      type: pmType,
      label: pmLabel.trim() || 'Payment Method',
      details: pmDetails.trim(),
      isDefault: false,
    });

    const refreshed = StorageService.getCurrentUser();
    if (refreshed) onUserUpdated(refreshed);
    setIsAddingPayment(false);
    globalToast.success('Payment Method Saved', 'New payment option saved to your profile.');
  };

  const handleDeletePayment = (id: string) => {
    StorageService.deletePaymentMethod(id);
    const refreshed = StorageService.getCurrentUser();
    if (refreshed) onUserUpdated(refreshed);
    globalToast.info('Payment Method Removed', 'Payment method removed from profile.');
  };

  // Wishlist / Saved Items logic
  const wishlistIds = user.wishlist || [];
  const allProducts = StorageService.getProducts();
  const savedProducts = allProducts.filter((p) => wishlistIds.includes(p.id));

  const handleAddToCartWishlist = (product: Product) => {
    if (product.stock <= 0) return;
    onAddToCart?.(product);
    setAddedItemMap((prev) => ({ ...prev, [product.id]: true }));
    setWishlistMessage(`"${product.name}" added to your shopping bag.`);
    setTimeout(() => {
      setAddedItemMap((prev) => ({ ...prev, [product.id]: false }));
    }, 2000);
    setTimeout(() => {
      setWishlistMessage('');
    }, 3500);
  };

  const handleMoveToCart = (product: Product) => {
    if (product.stock <= 0) return;
    onAddToCart?.(product);
    StorageService.removeFromWishlist(product.id, user.id);
    const refreshed = StorageService.getCurrentUser();
    if (refreshed) onUserUpdated(refreshed);
    setWishlistMessage(`"${product.name}" moved to your bag.`);
    setTimeout(() => setWishlistMessage(''), 3500);
  };

  const handleRemoveFromWishlist = (productId: string, productName: string) => {
    StorageService.removeFromWishlist(productId, user.id);
    const refreshed = StorageService.getCurrentUser();
    if (refreshed) onUserUpdated(refreshed);
    globalToast.info('Removed from Saved Items', `"${productName}" removed from your wishlist.`);
    setWishlistMessage(`"${productName}" removed from Saved Items.`);
    setTimeout(() => setWishlistMessage(''), 3500);
  };

  const handleAddAllToCart = () => {
    const inStock = savedProducts.filter((p) => p.stock > 0);
    if (inStock.length === 0) return;
    inStock.forEach((product) => {
      onAddToCart?.(product);
    });
    globalToast.success('Added to Bag', `Added ${inStock.length} saved ${inStock.length === 1 ? 'item' : 'items'} to your shopping bag.`);
    setWishlistMessage(`Added ${inStock.length} saved ${inStock.length === 1 ? 'item' : 'items'} to your shopping bag.`);
    setTimeout(() => setWishlistMessage(''), 3500);
  };

  const handleClearWishlist = () => {
    if (window.confirm('Are you sure you want to remove all items from your Saved Items list?')) {
      StorageService.clearWishlist(user.id);
      const refreshed = StorageService.getCurrentUser();
      if (refreshed) onUserUpdated(refreshed);
      globalToast.info('Saved Items Cleared', 'All items removed from your Saved Items.');
      setWishlistMessage('All items removed from Saved Items.');
      setTimeout(() => setWishlistMessage(''), 3500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/60 backdrop-blur-xs">
      <div 
        className="relative w-full max-w-4xl bg-white border border-stone-200 rounded-lg shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="p-6 border-b border-stone-200 flex flex-wrap items-center justify-between gap-4 bg-stone-50/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-stone-900 text-stone-100 flex items-center justify-center font-serif text-lg font-medium">
              {user.name[0]}
            </div>
            <div>
              <h2 className="text-base font-serif font-semibold text-stone-950">
                {user.name}
              </h2>
              <p className="text-xs text-stone-500 font-mono">
                {user.email} {user.phone && `· ${user.phone}`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              className="px-3 py-1.5 border border-stone-300 hover:border-rose-300 text-stone-600 hover:text-rose-700 rounded text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-stone-900 rounded cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs (Zero-pill compliant segmented buttons) */}
        <div className="px-6 pt-4 border-b border-stone-200 flex flex-wrap gap-2 text-xs font-medium">
          <button
            onClick={() => setActiveTab('orders')}
            className={`pb-3 px-2 flex items-center gap-1.5 transition-colors cursor-pointer border-b-2 ${
              activeTab === 'orders'
                ? 'border-stone-950 text-stone-950 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-900'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Order History ({userOrders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('wishlist')}
            className={`pb-3 px-2 flex items-center gap-1.5 transition-colors cursor-pointer border-b-2 ${
              activeTab === 'wishlist'
                ? 'border-stone-950 text-stone-950 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-900'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${wishlistIds.length > 0 ? 'text-rose-500 fill-rose-500' : ''}`} />
            <span>Saved Items ({wishlistIds.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('addresses')}
            className={`pb-3 px-2 flex items-center gap-1.5 transition-colors cursor-pointer border-b-2 ${
              activeTab === 'addresses'
                ? 'border-stone-950 text-stone-950 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-900'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Saved Addresses ({(user.addresses || []).length})</span>
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`pb-3 px-2 flex items-center gap-1.5 transition-colors cursor-pointer border-b-2 ${
              activeTab === 'payments'
                ? 'border-stone-950 text-stone-950 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-900'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Payment Methods ({(user.paymentMethods || []).length})</span>
          </button>

          <button
            onClick={() => setActiveTab('account')}
            className={`pb-3 px-2 flex items-center gap-1.5 transition-colors cursor-pointer border-b-2 ${
              activeTab === 'account'
                ? 'border-stone-950 text-stone-950 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile Information</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {saveSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{saveSuccess}</span>
            </div>
          )}

          {/* TAB 1: ORDER HISTORY */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-1">
                <div>
                  <h3 className="text-sm font-serif font-semibold text-stone-950">
                    Consignment & Purchase Records
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    Real-time fulfillment statuses and itemized receipts for your orders.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-stone-100 text-stone-700 border border-stone-200">
                    {userOrders.length} {userOrders.length === 1 ? 'consignment' : 'consignments'}
                  </span>
                </div>
              </div>

              {/* Status Badge Key / Legend */}
              {userOrders.length > 0 && (
                <div className="p-3 bg-stone-50/80 rounded-lg border border-stone-200/90 flex flex-wrap items-center gap-2 text-[10px] text-stone-600">
                  <span className="font-semibold text-stone-700 uppercase tracking-wider mr-1">Status Guide:</span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                    <Clock className="w-3 h-3 text-blue-600" />
                    Pending
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                    <CheckCircle className="w-3 h-3 text-amber-600" />
                    Confirmed
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-purple-50 text-purple-800 border border-purple-200">
                    <Box className="w-3 h-3 text-purple-600" />
                    Processing
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200">
                    <Truck className="w-3 h-3 text-indigo-600" />
                    Shipped
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-300">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Delivered
                  </span>
                </div>
              )}

              {userOrders.length === 0 ? (
                <div className="p-12 text-center bg-stone-50 rounded-lg border border-stone-200 text-stone-500">
                  <Package className="w-8 h-8 mx-auto mb-2 text-stone-400" />
                  <p className="font-serif text-base text-stone-800 mb-1">No prior orders placed</p>
                  <p className="text-stone-500 max-w-sm mx-auto">
                    When you complete purchases, your consignments, dispatch receipts, and live fulfillment tracking will appear here.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {userOrders.map((order) => (
                    <div 
                      key={order.id} 
                      className="border border-stone-200 rounded-lg p-5 bg-white space-y-4 hover:border-stone-300 transition-colors shadow-xs"
                    >
                      {/* Order top bar with visual status badges */}
                      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-stone-100">
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono tabular-nums font-bold text-stone-950 text-sm">
                            {order.id}
                          </span>
                          <span className="text-stone-300">·</span>
                          <span className="text-stone-500 text-[11px] flex items-center gap-1 font-mono">
                            <Calendar className="w-3 h-3 text-stone-400" />
                            {new Date(order.createdAt).toLocaleDateString()}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          {/* Visual Status Badge */}
                          {renderOrderStatusBadge(order.orderStatus)}

                          {/* Payment / Advance Badge */}
                          <span className={`inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2 py-1 rounded-md border ${
                            order.paymentStatus === 'paid' 
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                              : 'bg-amber-50 text-amber-800 border-amber-200'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${order.paymentStatus === 'paid' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                            {order.paymentStatus}
                          </span>
                        </div>
                      </div>

                      {/* Items */}
                      <div className="space-y-2">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex justify-between items-center">
                            <div className="flex items-center gap-3">
                              <img
                                src={item.product.images[0]}
                                alt=""
                                className="w-9 h-9 object-cover rounded border border-stone-200"
                              />
                              <div>
                                <span className="font-medium text-stone-900">{item.product.name}</span>
                                <span className="text-stone-500 block text-[11px] font-mono">
                                  Qty: {item.quantity} · ৳{(item.product.price * item.quantity).toLocaleString()}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Footer Actions */}
                      <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3 text-stone-600">
                        <div>
                          <span className="text-stone-400">Total: </span>
                          <strong className="font-mono tabular-nums text-stone-950 text-sm">
                            ৳{order.total.toLocaleString()}
                          </strong>
                          <span className="text-[11px] text-stone-500 ml-2">
                            ({order.paymentMethod === 'cod' ? 'Cash on Delivery (Advance ৳100)' : 'Paid Online'})
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onInspectOrder(order)}
                            className="px-3 py-1.5 border border-stone-200 hover:border-stone-400 rounded text-stone-700 hover:text-stone-950 transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>View Receipt</span>
                          </button>

                          <button
                            onClick={() => {
                              onClose();
                              onTrackOrder(order.id);
                            }}
                            className="px-3 py-1.5 border border-stone-200 hover:border-stone-400 rounded text-stone-700 hover:text-stone-950 transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Truck className="w-3.5 h-3.5" />
                            <span>Track Package</span>
                          </button>

                          <button
                            onClick={() => {
                              onReorder(order.items);
                              onClose();
                            }}
                            className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Re-order</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB: SAVED ITEMS / WISHLIST */}
          {activeTab === 'wishlist' && (
            <div className="space-y-4">
              {wishlistMessage && (
                <div className="p-3 bg-stone-900 text-stone-100 rounded-md flex items-center justify-between shadow-sm animate-fade-in">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-medium text-[11px]">{wishlistMessage}</span>
                  </div>
                  <button 
                    onClick={() => setWishlistMessage('')}
                    className="text-stone-400 hover:text-white p-0.5 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-1">
                <div>
                  <h3 className="text-sm font-serif font-semibold text-stone-950 flex items-center gap-2">
                    <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
                    <span>Saved Items & Personal Wishlist</span>
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    Products curated to your profile. Review them anytime and add to your bag for seamless order checkout.
                  </p>
                </div>

                {savedProducts.length > 0 && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleAddAllToCart}
                      className="px-3 py-1.5 bg-stone-950 hover:bg-stone-800 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Add All In-Stock to Bag</span>
                    </button>
                    <button
                      onClick={handleClearWishlist}
                      className="px-2.5 py-1.5 border border-stone-200 hover:border-rose-300 text-stone-500 hover:text-rose-700 rounded text-xs font-medium transition-colors cursor-pointer"
                      title="Clear all saved items"
                    >
                      Clear All
                    </button>
                  </div>
                )}
              </div>

              {savedProducts.length === 0 ? (
                <div className="p-12 text-center bg-stone-50/80 rounded-lg border border-stone-200/90 space-y-3">
                  <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 border border-rose-200 flex items-center justify-center mx-auto">
                    <Heart className="w-6 h-6" />
                  </div>
                  <h4 className="font-serif text-base font-semibold text-stone-900">
                    Your Saved Items list is empty
                  </h4>
                  <p className="text-stone-500 text-[11px] max-w-sm mx-auto leading-relaxed">
                    While exploring curations, click the heart icon on any product to save it to your profile. You can review them anytime and add them to your shopping bag.
                  </p>
                  <button
                    onClick={() => {
                      onClose();
                      const catalogEl = document.getElementById('catalog-section');
                      if (catalogEl) {
                        catalogEl.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 bg-stone-900 text-white text-xs uppercase tracking-wider font-semibold rounded hover:bg-stone-800 transition-colors cursor-pointer"
                  >
                    <span>Explore Curations</span>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {savedProducts.map((product) => {
                    const isOutOfStock = product.stock <= 0;
                    const isLowStock = product.stock > 0 && product.stock <= 5;
                    const isAdded = !!addedItemMap[product.id];

                    return (
                      <div
                        key={product.id}
                        className="p-4 bg-white border border-stone-200 rounded-lg hover:border-stone-300 hover:shadow-xs transition-all flex flex-col justify-between gap-3 group"
                      >
                        <div className="flex gap-3">
                          {/* Product Thumbnail */}
                          <div 
                            onClick={() => {
                              onClose();
                              onInspectProduct?.(product);
                            }}
                            className="w-20 h-20 bg-stone-100 rounded-md overflow-hidden shrink-0 cursor-pointer relative border border-stone-200/80"
                          >
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              onError={(e) => {
                                (e.currentTarget as HTMLElement).style.display = 'none';
                              }}
                            />
                            {product.tag && (
                              <span className="absolute bottom-1 left-1 text-[8px] uppercase tracking-wider font-semibold bg-white/95 px-1 py-0.2 rounded text-stone-800">
                                {product.tag}
                              </span>
                            )}
                          </div>

                          {/* Details */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-stone-500 mb-1">
                              <span>{product.category}</span>
                              <span>·</span>
                              {isOutOfStock ? (
                                <span className="text-rose-600 font-semibold">Sold Out</span>
                              ) : isLowStock ? (
                                <span className="text-amber-700 font-medium">Only {product.stock} left</span>
                              ) : (
                                <span className="text-emerald-700 font-medium">In Stock</span>
                              )}
                            </div>

                            <h4 
                              onClick={() => {
                                onClose();
                                onInspectProduct?.(product);
                              }}
                              className="text-xs font-semibold text-stone-900 hover:text-stone-700 transition-colors line-clamp-1 cursor-pointer"
                            >
                              {product.name}
                            </h4>

                            <p className="text-[11px] text-stone-500 line-clamp-1 mt-0.5">
                              {product.description}
                            </p>

                            <div className="mt-2 flex items-baseline gap-2">
                              <span className="text-sm font-semibold font-mono tabular-nums text-stone-950">
                                ৳{product.price.toLocaleString()}
                              </span>
                              {product.originalPrice && (
                                <span className="text-[11px] font-mono tabular-nums text-stone-400 line-through">
                                  ৳{product.originalPrice.toLocaleString()}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleAddToCartWishlist(product)}
                              disabled={isOutOfStock}
                              className={`px-3 py-1.5 rounded text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer ${
                                isAdded
                                  ? 'bg-emerald-700 text-white'
                                  : isOutOfStock
                                  ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                                  : 'bg-stone-950 hover:bg-stone-800 text-white active:scale-95'
                              }`}
                            >
                              {isAdded ? (
                                <>
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Added ✓</span>
                                </>
                              ) : (
                                <>
                                  <ShoppingBag className="w-3.5 h-3.5" />
                                  <span>Add to Bag</span>
                                </>
                              )}
                            </button>

                            <button
                              onClick={() => handleMoveToCart(product)}
                              disabled={isOutOfStock}
                              title="Add to bag and remove from Saved Items"
                              className="px-2.5 py-1.5 border border-stone-300 hover:border-stone-950 text-stone-700 hover:text-stone-950 rounded text-xs font-medium transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                            >
                              Move to Bag
                            </button>
                          </div>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                onClose();
                                onInspectProduct?.(product);
                              }}
                              className="p-1.5 text-stone-400 hover:text-stone-700 rounded transition-colors cursor-pointer"
                              title="Inspect Product Specifications"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleRemoveFromWishlist(product.id, product.name)}
                              className="p-1.5 text-stone-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                              title="Remove from Saved Items"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SAVED ADDRESSES */}
          {activeTab === 'addresses' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-sm font-serif font-semibold text-stone-950">
                    Saved Delivery Addresses
                  </h3>
                  <p className="text-stone-500 text-[11px]">
                    Manage destinations for expedited doorstep fulfillment.
                  </p>
                </div>
                {!isAddingAddress && (
                  <button
                    onClick={() => setIsAddingAddress(true)}
                    className="px-3 py-1.5 bg-stone-950 hover:bg-stone-800 text-white rounded text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Address</span>
                  </button>
                )}
              </div>

              {isAddingAddress && (
                <form onSubmit={handleAddAddress} className="p-4 bg-stone-50 rounded-lg border border-stone-300 space-y-3">
                  <h4 className="font-semibold text-stone-900 text-xs uppercase tracking-wider">
                    New Destination
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-stone-700 font-medium mb-1">Address Label</label>
                      <input
                        type="text"
                        placeholder="e.g. Primary Studio or Home"
                        value={addrLabel}
                        onChange={(e) => setAddrLabel(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-700 font-medium mb-1">Recipient Name</label>
                      <input
                        type="text"
                        required
                        value={addrRecipient}
                        onChange={(e) => setAddrRecipient(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-700 font-medium mb-1">Contact Phone</label>
                      <input
                        type="tel"
                        required
                        value={addrPhone}
                        onChange={(e) => setAddrPhone(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-700 font-medium mb-1">City / Region</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Oslo or San Francisco"
                        value={addrCity}
                        onChange={(e) => setAddrCity(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-stone-700 font-medium mb-1">Street Address</label>
                      <input
                        type="text"
                        required
                        placeholder="Street, suite, floor"
                        value={addrStreet}
                        onChange={(e) => setAddrStreet(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-700 font-medium mb-1">Postal / ZIP Code</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 0271"
                        value={addrPostal}
                        onChange={(e) => setAddrPostal(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      />
                    </div>
                    <div className="flex items-center gap-2 pt-5">
                      <input
                        type="checkbox"
                        id="addrDefault"
                        checked={addrIsDefault}
                        onChange={(e) => setAddrIsDefault(e.target.checked)}
                        className="rounded border-stone-300 text-stone-900 cursor-pointer"
                      />
                      <label htmlFor="addrDefault" className="text-stone-700 cursor-pointer">
                        Set as primary default address
                      </label>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingAddress(false)}
                      className="px-3.5 py-1.5 border border-stone-300 rounded text-stone-700 hover:bg-stone-100 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-stone-950 text-white rounded font-semibold hover:bg-stone-800 cursor-pointer"
                    >
                      Save Destination
                    </button>
                  </div>
                </form>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {(user.addresses || []).map((addr) => (
                  <div 
                    key={addr.id}
                    className={`p-4 rounded-lg border text-xs relative flex flex-col justify-between ${
                      addr.isDefault ? 'border-stone-950 bg-stone-50/50 ring-1 ring-stone-950' : 'border-stone-200 bg-white'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-semibold text-stone-950">{addr.label}</span>
                        {addr.isDefault && (
                          <span className="text-[10px] font-mono uppercase bg-stone-900 text-white px-2 py-0.5 rounded font-medium">
                            Default
                          </span>
                        )}
                      </div>
                      <p className="font-medium text-stone-800">{addr.recipientName} · {addr.phone}</p>
                      <p className="text-stone-600 mt-1">{addr.streetAddress}</p>
                      <p className="text-stone-600">{addr.city}, {addr.postalCode}</p>
                    </div>

                    <div className="flex items-center justify-between pt-3 mt-3 border-t border-stone-100">
                      {!addr.isDefault ? (
                        <button
                          onClick={() => handleSetDefaultAddress(addr.id)}
                          className="text-[11px] text-stone-600 hover:text-stone-950 underline cursor-pointer"
                        >
                          Make Primary
                        </button>
                      ) : <span />}

                      <button
                        onClick={() => handleDeleteAddress(addr.id)}
                        className="text-stone-400 hover:text-rose-600 p-1 cursor-pointer"
                        title="Delete Address"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: SAVED PAYMENT PREFERENCES */}
          {activeTab === 'payments' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-sm font-serif font-semibold text-stone-950">
                    Saved Payment Preferences
                  </h3>
                  <p className="text-stone-500 text-[11px]">
                    Configure default Cash on Delivery or digital gateway preferences.
                  </p>
                </div>
                {!isAddingPayment && (
                  <button
                    onClick={() => setIsAddingPayment(true)}
                    className="px-3 py-1.5 bg-stone-950 hover:bg-stone-800 text-white rounded text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Preference</span>
                  </button>
                )}
              </div>

              {isAddingPayment && (
                <form onSubmit={handleAddPayment} className="p-4 bg-stone-50 rounded-lg border border-stone-300 space-y-3">
                  <h4 className="font-semibold text-stone-900 text-xs uppercase tracking-wider">
                    Add Payment Instrument
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-stone-700 font-medium mb-1">Instrument Type</label>
                      <select
                        value={pmType}
                        onChange={(e) => {
                          const t = e.target.value as SavedPaymentMethod['type'];
                          setPmType(t);
                          if (t === 'cod') {
                            setPmLabel('Cash on Delivery (Standard)');
                            setPmDetails('Pay exact cash at delivery doorstep');
                          } else if (t.startsWith('mfs')) {
                            setPmLabel('bKash Personal MFS');
                            setPmDetails('Personal mobile wallet');
                          } else {
                            setPmLabel('Visa Signature Card');
                            setPmDetails('•••• •••• •••• 4242 (Exp 12/28)');
                          }
                        }}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      >
                        <option value="cod">Cash on Delivery</option>
                        <option value="mfs_bkash">bKash MFS</option>
                        <option value="mfs_nagad">Nagad MFS</option>
                        <option value="card_stripe">Credit / Debit Card</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-stone-700 font-medium mb-1">Custom Label</label>
                      <input
                        type="text"
                        required
                        value={pmLabel}
                        onChange={(e) => setPmLabel(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-stone-700 font-medium mb-1">Details / Notes</label>
                      <input
                        type="text"
                        value={pmDetails}
                        onChange={(e) => setPmDetails(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded text-stone-900"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingPayment(false)}
                      className="px-3.5 py-1.5 border border-stone-300 rounded text-stone-700 hover:bg-stone-100 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-stone-950 text-white rounded font-semibold hover:bg-stone-800 cursor-pointer"
                    >
                      Save Preference
                    </button>
                  </div>
                </form>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {(user.paymentMethods || []).map((pm) => (
                  <div
                    key={pm.id}
                    className="p-4 rounded-lg border border-stone-200 bg-white flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded bg-stone-100 flex items-center justify-center text-stone-700">
                        {pm.type === 'cod' ? (
                          <Truck className="w-4 h-4" />
                        ) : pm.type.startsWith('mfs') ? (
                          <Smartphone className="w-4 h-4 text-pink-700" />
                        ) : (
                          <CreditCard className="w-4 h-4 text-blue-700" />
                        )}
                      </div>
                      <div>
                        <div className="font-semibold text-stone-900">{pm.label}</div>
                        <div className="text-[11px] text-stone-500">{pm.details}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeletePayment(pm.id)}
                      className="text-stone-400 hover:text-rose-600 p-1 cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: PROFILE & SECURITY INFO */}
          {activeTab === 'account' && (
            <div className="max-w-lg space-y-6">
              {saveSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded text-emerald-800 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{saveSuccess}</span>
                </div>
              )}

              <div>
                <h3 className="text-sm font-serif font-semibold text-stone-950">
                  Customer Profile & Contact Information
                </h3>
                <p className="text-stone-500 text-[11px]">
                  Unique customer identifier authenticated via Phone Number and Gmail.
                </p>
              </div>

              {/* Unique Credentials Status Card */}
              <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-[11px] text-stone-500 font-medium">Registered Mobile Phone</span>
                    <p className="font-mono font-bold text-stone-900">{user.phone}</p>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Phone Verified</span>
                  </span>
                </div>

                <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-[11px] text-stone-500 font-medium">Registered Gmail Address</span>
                    <p className="font-mono font-bold text-stone-900">{user.email}</p>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Gmail Verified</span>
                  </span>
                </div>
              </div>

              {/* Edit Details Form */}
              <form onSubmit={handleSaveProfile} className="space-y-3.5 pt-2 border-t border-stone-200">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Full Legal Name</label>
                  <input
                    type="text"
                    required
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Update Primary Phone</label>
                  <input
                    type="tel"
                    value={profilePhone}
                    onChange={(e) => setProfilePhone(e.target.value)}
                    placeholder="01516557161"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white"
                  />
                </div>

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-stone-950 hover:bg-stone-800 text-white rounded font-semibold text-xs transition-colors cursor-pointer"
                >
                  Save Profile Changes
                </button>
              </form>

              {/* Password Setting Section */}
              <div className="pt-6 border-t border-stone-200 space-y-3">
                <div>
                  <h4 className="text-sm font-serif font-semibold text-stone-950">
                    Set Your Own Password
                  </h4>
                  <p className="text-stone-500 text-[11px]">
                    Create or update your account password for swift login alongside verification codes.
                  </p>
                </div>

                {passwordError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded text-rose-700 text-xs">
                    {passwordError}
                  </div>
                )}

                {passwordSuccess && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded text-emerald-800 text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{passwordSuccess}</span>
                  </div>
                )}

                <form onSubmit={handleUpdatePassword} className="space-y-3">
                  <div>
                    <label className="block text-stone-700 font-medium mb-1">New Password</label>
                    <input
                      type="password"
                      required
                      placeholder="Minimum 6 characters"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-700 font-medium mb-1">Confirm New Password</label>
                    <input
                      type="password"
                      required
                      placeholder="Re-enter password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded font-semibold text-xs transition-colors cursor-pointer"
                  >
                    Update Account Password
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
