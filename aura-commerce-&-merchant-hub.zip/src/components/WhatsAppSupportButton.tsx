import React, { useState } from 'react';
import { WHATSAPP_SUPPORT_NUMBER } from '../services/storage';
import { MessageCircle, Phone, X, ExternalLink, ShieldCheck, Clock } from 'lucide-react';

interface WhatsAppSupportButtonProps {
  onOpenLicense?: () => void;
}

export const WhatsAppSupportButton: React.FC<WhatsAppSupportButtonProps> = ({ onOpenLicense }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [customerMessage, setCustomerMessage] = useState('');

  const rawNumber = WHATSAPP_SUPPORT_NUMBER; // 01516557161
  const internationalNumber = '8801516557161';

  const handleStartChat = (presetText?: string) => {
    const textToSend = encodeURIComponent(
      presetText || customerMessage.trim() || 'Hello Aura Support! I have an inquiry regarding an order / product on your store.'
    );
    window.open(`https://wa.me/${internationalNumber}?text=${textToSend}`, '_blank');
  };

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
        {/* Floating Bubble */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Contact Customer Support on WhatsApp"
          className="group flex items-center gap-2.5 px-4 py-3 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer focus:outline-none"
        >
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
          </span>

          <MessageCircle className="w-5 h-5 fill-white text-[#25D366]" />

          <div className="text-left hidden sm:block">
            <span className="text-[10px] uppercase tracking-wider font-semibold block leading-none opacity-90">
              Live Support
            </span>
            <span className="text-xs font-bold font-mono tracking-wide">
              {rawNumber}
            </span>
          </div>
        </button>
      </div>

      {/* WhatsApp Support Slide-out / Modal Drawer */}
      {isOpen && (
        <div 
          className="fixed bottom-22 right-4 sm:right-6 z-50 w-full max-w-sm bg-white rounded-xl shadow-2xl border border-stone-200 overflow-hidden text-xs animate-in slide-in-from-bottom-3 duration-200"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="bg-[#075E54] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-emerald-300" />
              </div>
              <div>
                <h4 className="font-semibold text-sm">Aura Merchant Support</h4>
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-200">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>Direct WhatsApp: {rawNumber}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white p-1 rounded cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick FAQ / Topics */}
          <div className="p-4 bg-stone-50 space-y-3">
            <div className="p-2.5 bg-white rounded border border-stone-200 text-stone-700 space-y-1">
              <span className="font-semibold text-stone-900 block flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-stone-500" />
                <span>Instant Merchant Assistance:</span>
              </span>
              <p className="text-[11px] text-stone-600 leading-relaxed">
                Connect directly with our Dhaka fulfillment team for bKash payment verification, ৳100 advance deposit queries, or order tracking issues.
              </p>
            </div>

            {/* Quick Action Buttons */}
            <div className="space-y-1.5">
              <button
                onClick={() => handleStartChat('Hello! I would like to verify my bKash payment / ৳100 security advance for my order.')}
                className="w-full text-left p-2 rounded bg-white hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 transition-colors cursor-pointer text-stone-800 font-medium"
              >
                💬 Verify my bKash Payment / ৳100 Advance
              </button>

              <button
                onClick={() => handleStartChat('Hello! I need an update on my consignment delivery status.')}
                className="w-full text-left p-2 rounded bg-white hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 transition-colors cursor-pointer text-stone-800 font-medium"
              >
                🚚 Track My Parcel Delivery
              </button>

              <button
                onClick={() => handleStartChat('Hello! I have a question about a product before placing an order.')}
                className="w-full text-left p-2 rounded bg-white hover:bg-emerald-50 border border-stone-200 hover:border-emerald-300 transition-colors cursor-pointer text-stone-800 font-medium"
              >
                📦 Inquire About Products & Specifications
              </button>
            </div>

            {/* Custom Input */}
            <div className="pt-2">
              <textarea
                rows={2}
                placeholder="Type your message to send on WhatsApp..."
                value={customerMessage}
                onChange={(e) => setCustomerMessage(e.target.value)}
                className="w-full p-2 bg-white border border-stone-300 rounded text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-[#25D366]"
              />

              <button
                onClick={() => handleStartChat()}
                className="w-full mt-2 py-2.5 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <MessageCircle className="w-4 h-4 fill-white text-[#25D366]" />
                <span>Open Chat in WhatsApp ({rawNumber})</span>
              </button>
            </div>
          </div>

          {/* Footer note */}
          <div className="p-3 bg-stone-100 border-t border-stone-200 flex justify-between items-center text-[10px] text-stone-500">
            <span>Direct Call / WhatsApp: {rawNumber}</span>
            {onOpenLicense && (
              <button
                onClick={() => {
                  setIsOpen(false);
                  onOpenLicense();
                }}
                className="text-stone-700 underline font-medium cursor-pointer"
              >
                View Trade License
              </button>
            )}
          </div>
        </div>
      )}
    </>
  );
};
