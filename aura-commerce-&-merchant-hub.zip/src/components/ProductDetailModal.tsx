import React, { useState, useEffect } from 'react';
import { Product, ProductReview, UserProfile } from '../types';
import { StorageService } from '../services/storage';
import { 
  X, 
  ShoppingBag, 
  Check, 
  ShieldCheck, 
  RotateCcw, 
  Star, 
  MessageSquare, 
  CheckCircle2, 
  Send,
  AlertCircle,
  Heart
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  currentUser?: UserProfile | null;
  isWishlisted?: boolean;
  onToggleWishlist?: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  currentUser,
  isWishlisted = false,
  onToggleWishlist,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [addedAnimation, setAddedAnimation] = useState(false);

  // Reviews state
  const [reviews, setReviews] = useState<ProductReview[]>([]);
  const [isWritingReview, setIsWritingReview] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [authorName, setAuthorName] = useState(currentUser?.name || '');
  const [authorEmail, setAuthorEmail] = useState(currentUser?.email || '');
  const [reviewSuccess, setReviewSuccess] = useState('');
  const [reviewError, setReviewError] = useState('');

  useEffect(() => {
    if (product) {
      setReviews(StorageService.getReviews(product.id));
      setSelectedImageIdx(0);
      setQuantity(1);
      setIsWritingReview(false);
      setReviewSuccess('');
      setReviewError('');
      if (currentUser) {
        setAuthorName(currentUser.name);
        setAuthorEmail(currentUser.email);
      }
    }
  }, [product, currentUser]);

  if (!product) return null;

  const isOutOfStock = product.stock <= 0;

  // Calculation of average rating and distribution
  const totalReviewsCount = reviews.length;
  const averageRating = totalReviewsCount > 0
    ? Math.round((reviews.reduce((acc, r) => acc + r.rating, 0) / totalReviewsCount) * 10) / 10
    : product.rating;

  const ratingCounts = [5, 4, 3, 2, 1].map((stars) => {
    const count = reviews.filter((r) => r.rating === stars).length;
    const percentage = totalReviewsCount > 0 ? Math.round((count / totalReviewsCount) * 100) : 0;
    return { stars, count, percentage };
  });

  const handleAdd = () => {
    if (isOutOfStock) return;
    onAddToCart(product, quantity);
    setAddedAnimation(true);
    setTimeout(() => {
      setAddedAnimation(false);
    }, 1500);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setReviewError('');

    if (!authorName.trim()) {
      setReviewError('Please enter your name.');
      return;
    }
    if (!reviewTitle.trim()) {
      setReviewError('Please provide a brief headline for your review.');
      return;
    }
    if (!reviewComment.trim()) {
      setReviewError('Please write your detailed feedback.');
      return;
    }

    const isVerified = StorageService.hasUserPurchased(product.id, {
      userId: currentUser?.id,
      email: authorEmail.trim() || currentUser?.email,
    });

    const newRev = StorageService.addReview({
      productId: product.id,
      userId: currentUser?.id,
      authorName: authorName.trim(),
      authorEmail: authorEmail.trim(),
      rating: reviewRating,
      title: reviewTitle.trim(),
      comment: reviewComment.trim(),
      isVerifiedPurchase: isVerified,
    });

    setReviews(StorageService.getReviews(product.id));
    setIsWritingReview(false);
    setReviewTitle('');
    setReviewComment('');
    setReviewSuccess(
      isVerified
        ? 'Thank you! Your verified purchase review has been published.'
        : 'Thank you! Your review has been published.'
    );
    setTimeout(() => setReviewSuccess(''), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/60 backdrop-blur-xs">
      <div 
        className="relative w-full max-w-4xl bg-white border border-stone-200 rounded-lg shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close product preview"
          className="absolute top-4 right-4 z-10 p-2 text-stone-400 hover:text-stone-900 rounded-full hover:bg-stone-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="overflow-y-auto p-6 sm:p-8 space-y-10">
          {/* Section 1: Visual Gallery & Purchase Module */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
            {/* Left Column: Visual Gallery */}
            <div className="md:col-span-6 flex flex-col gap-4">
              <div className="aspect-[4/3] rounded-lg overflow-hidden border border-stone-200 bg-stone-100">
                <img
                  src={product.images[selectedImageIdx] || product.images[0]}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center"
                />
              </div>

              {/* Gallery Thumbnails */}
              {product.images.length > 1 && (
                <div className="flex items-center gap-3">
                  {product.images.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedImageIdx(i)}
                      className={`relative w-16 h-16 rounded border overflow-hidden cursor-pointer transition-all ${
                        selectedImageIdx === i ? 'border-stone-900 ring-1 ring-stone-900' : 'border-stone-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Merchant Guarantees */}
              <div className="mt-2 pt-4 border-t border-stone-100 space-y-2 text-xs text-stone-600">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-stone-800 shrink-0" />
                  <span>Individually inspected and serialized prior to packaging</span>
                </div>
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-stone-800 shrink-0" />
                  <span>14-day archival satisfaction exchange policy</span>
                </div>
              </div>
            </div>

            {/* Right Column: Contiguous Purchase Module */}
            <div className="md:col-span-6 flex flex-col justify-between">
              <div>
                {/* Category & Stock Metadata (Zero-pill) */}
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-stone-500 mb-2">
                  <span>{product.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">SKU: {product.id}</span>
                  <span aria-hidden="true">·</span>
                  {isOutOfStock ? (
                    <span className="text-rose-700 font-medium">Sold Out</span>
                  ) : (
                    <span className="text-stone-700 font-medium">In Stock ({product.stock} units)</span>
                  )}
                </div>

                {/* Title */}
                <h2 className="text-2xl sm:text-3xl font-serif font-medium text-stone-950 mb-2 leading-tight">
                  {product.name}
                </h2>

                {/* Review Anchor Rating */}
                <div className="flex items-center gap-2 mb-4 text-xs text-stone-600">
                  <div className="flex items-center gap-0.5 text-amber-500">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < Math.floor(averageRating) ? 'fill-amber-400 text-amber-400' : 'text-stone-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="font-mono tabular-nums font-semibold text-stone-800">{averageRating.toFixed(1)}</span>
                  <a href="#reviews-section" className="text-stone-500 hover:text-stone-900 underline ml-1">
                    ({totalReviewsCount} {totalReviewsCount === 1 ? 'review' : 'reviews'})
                  </a>
                </div>

                {/* Price */}
                <div className="flex items-baseline gap-3 mb-5 pb-4 border-b border-stone-200">
                  <span className="text-2xl font-bold font-mono tabular-nums text-stone-950">
                    ৳{product.price.toLocaleString()}
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm font-mono tabular-nums text-stone-400 line-through">
                      ৳{product.originalPrice.toLocaleString()}
                    </span>
                  )}
                </div>

                {/* Description */}
                <p className="text-stone-700 text-sm leading-relaxed mb-6">
                  {product.description}
                </p>

                {/* Technical Specifications */}
                {product.specs && Object.keys(product.specs).length > 0 && (
                  <div className="mb-6">
                    <h4 className="text-xs uppercase tracking-wider font-semibold text-stone-900 mb-2.5">
                      Specifications
                    </h4>
                    <div className="bg-stone-50 rounded-md border border-stone-200/70 p-3 space-y-1.5 text-xs">
                      {Object.entries(product.specs).map(([label, val]) => (
                        <div key={label} className="flex justify-between items-baseline py-1 border-b border-stone-200/50 last:border-0">
                          <span className="text-stone-500">{label}</span>
                          <span className="font-medium text-stone-800 font-mono tabular-nums text-right">{val}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Purchase CTA and Quantity Stepper */}
              <div className="pt-4 border-t border-stone-200">
                <div className="flex items-center gap-4 mb-3">
                  <div className="flex items-center border border-stone-300 rounded-md bg-stone-50 overflow-hidden">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      disabled={isOutOfStock || quantity <= 1}
                      aria-label="Decrease quantity"
                      className="px-3 py-2 text-stone-600 hover:text-stone-950 disabled:opacity-30 cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-4 py-2 font-mono tabular-nums text-sm font-semibold text-stone-900">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                      disabled={isOutOfStock || quantity >= product.stock}
                      aria-label="Increase quantity"
                      className="px-3 py-2 text-stone-600 hover:text-stone-950 disabled:opacity-30 cursor-pointer"
                    >
                      +
                    </button>
                  </div>

                  <button
                    onClick={handleAdd}
                    disabled={isOutOfStock}
                    className={`flex-1 py-3 px-6 rounded-md text-xs uppercase tracking-wider font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      addedAnimation
                        ? 'bg-emerald-700 text-white'
                        : isOutOfStock
                        ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                        : 'bg-stone-950 hover:bg-stone-800 text-white shadow-sm'
                    }`}
                  >
                    {addedAnimation ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Added to Bag</span>
                      </>
                    ) : isOutOfStock ? (
                      <span>Currently Unavailable</span>
                    ) : (
                      <>
                        <ShoppingBag className="w-4 h-4" />
                        <span>Add to Bag — ৳{(product.price * quantity).toLocaleString()}</span>
                      </>
                    )}
                  </button>

                  {/* Save to Wishlist Toggle */}
                  <button
                    type="button"
                    onClick={() => onToggleWishlist?.(product)}
                    aria-label={isWishlisted ? "Remove from Saved Items" : "Save to Saved Items"}
                    title={isWishlisted ? "Saved in your Profile" : "Save to Wishlist"}
                    className={`px-3.5 py-3 rounded-md border text-xs font-semibold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0 ${
                      isWishlisted
                        ? 'border-rose-300 bg-rose-50 text-rose-700 hover:bg-rose-100 shadow-2xs'
                        : 'border-stone-300 bg-white text-stone-700 hover:border-stone-900 hover:text-stone-950'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
                    <span className="hidden sm:inline">{isWishlisted ? 'Saved' : 'Save'}</span>
                  </button>
                </div>

                <p className="text-[11px] text-stone-500 text-center">
                  Doorstep Cash on Delivery (৳100 advance deposit via bKash: 01516557161) or Instant Online Payment.
                </p>
              </div>
            </div>
          </div>

          {/* Section 2: Customer Reviews & Ratings Engine */}
          <div id="reviews-section" className="pt-8 border-t border-stone-200 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-stone-500">
                  Verified Feedback
                </span>
                <h3 className="text-xl font-serif font-medium text-stone-950 mt-0.5">
                  Customer Reviews & Ratings
                </h3>
              </div>

              {!isWritingReview && (
                <button
                  onClick={() => setIsWritingReview(true)}
                  className="px-4 py-2 bg-stone-950 hover:bg-stone-800 text-white text-xs font-semibold uppercase tracking-wider rounded transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Write a Review</span>
                </button>
              )}
            </div>

            {reviewSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{reviewSuccess}</span>
              </div>
            )}

            {/* Ratings Overview Breakdown Card */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-5 bg-stone-50 rounded-lg border border-stone-200 text-xs">
              {/* Average Score */}
              <div className="md:col-span-4 flex flex-col justify-center items-center sm:items-start border-b md:border-b-0 md:border-r border-stone-200 pb-4 md:pb-0 md:pr-4">
                <span className="text-4xl font-serif font-bold font-mono tabular-nums text-stone-950">
                  {averageRating.toFixed(1)}
                </span>
                <div className="flex items-center gap-1 my-1.5 text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(averageRating) ? 'fill-amber-400 text-amber-400' : 'text-stone-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-stone-500 text-xs">
                  Based on {totalReviewsCount} customer {totalReviewsCount === 1 ? 'evaluation' : 'evaluations'}
                </span>
              </div>

              {/* Star Percentage Bars */}
              <div className="md:col-span-8 space-y-1.5 justify-center flex flex-col">
                {ratingCounts.map(({ stars, count, percentage }) => (
                  <div key={stars} className="flex items-center gap-3">
                    <span className="w-12 text-stone-600 font-mono flex items-center gap-1 shrink-0">
                      <span>{stars}</span>
                      <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                    </span>
                    <div className="flex-1 h-2 bg-stone-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-stone-900 rounded-full transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="w-12 text-right font-mono text-stone-400 shrink-0">
                      {count} ({percentage}%)
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Write Review Form */}
            {isWritingReview && (
              <form onSubmit={handleReviewSubmit} className="p-5 bg-white border border-stone-300 rounded-lg space-y-4 text-xs shadow-sm">
                <div className="flex justify-between items-center pb-2 border-b border-stone-100">
                  <h4 className="font-serif font-semibold text-base text-stone-950">
                    Share Your Experience
                  </h4>
                  <button
                    type="button"
                    onClick={() => setIsWritingReview(false)}
                    className="text-stone-400 hover:text-stone-700 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                {reviewError && (
                  <div className="p-2.5 bg-rose-50 border border-rose-200 rounded text-rose-700 flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{reviewError}</span>
                  </div>
                )}

                {/* Star rating selector */}
                <div>
                  <label className="block text-stone-700 font-medium mb-1">
                    Overall Rating <span className="text-rose-600">*</span>
                  </label>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => {
                      const isFilled = (hoverRating || reviewRating) >= star;
                      return (
                        <button
                          key={star}
                          type="button"
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setReviewRating(star)}
                          className="p-1 cursor-pointer focus:outline-none transition-transform hover:scale-110"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              isFilled ? 'fill-amber-400 text-amber-500' : 'text-stone-300'
                            }`}
                          />
                        </button>
                      );
                    })}
                    <span className="ml-2 font-mono font-semibold text-stone-800">
                      {hoverRating || reviewRating} / 5
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-700 font-medium mb-1">
                      Your Name <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Marcus Lindqvist"
                      value={authorName}
                      onChange={(e) => setAuthorName(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-700 font-medium mb-1">
                      Email Address (Optional for verification)
                    </label>
                    <input
                      type="email"
                      placeholder="Used to verify order history"
                      value={authorEmail}
                      onChange={(e) => setAuthorEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">
                    Review Headline <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Uncompromised acoustic purity & silence"
                    value={reviewTitle}
                    onChange={(e) => setReviewTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">
                    Detailed Written Feedback <span className="text-rose-600">*</span>
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Describe craftsmanship, physical feel, acoustic fidelity, durability, or ergonomics..."
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsWritingReview(false)}
                    className="px-3.5 py-2 border border-stone-300 rounded font-medium text-stone-700 hover:bg-stone-50 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-stone-950 hover:bg-stone-800 text-white rounded font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Publish Review</span>
                  </button>
                </div>
              </form>
            )}

            {/* List of Customer Reviews */}
            <div className="space-y-4">
              {reviews.length === 0 ? (
                <div className="p-8 text-center bg-stone-50 rounded border border-stone-200 text-stone-500 text-xs">
                  Be the first to leave a verified review for this curation.
                </div>
              ) : (
                reviews.map((rev) => (
                  <div key={rev.id} className="p-5 bg-white border border-stone-200 rounded-lg space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-0.5 text-amber-500">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3.5 h-3.5 ${
                                i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-stone-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="font-semibold text-stone-900 text-xs">{rev.title}</span>
                      </div>

                      <span className="text-[11px] font-mono text-stone-400">
                        {new Date(rev.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <p className="text-stone-700 text-xs leading-relaxed">
                      {rev.comment}
                    </p>

                    <div className="flex items-center gap-2 pt-1 text-[11px] text-stone-500">
                      <span className="font-medium text-stone-800">{rev.authorName}</span>
                      {rev.isVerifiedPurchase && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-emerald-700 font-medium flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Verified Buyer</span>
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
