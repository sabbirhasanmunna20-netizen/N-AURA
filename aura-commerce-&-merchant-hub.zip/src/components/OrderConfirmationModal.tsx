import React from 'react';
import { Order } from '../types';
import { NAuraLogo } from './NAuraLogo';
import { CheckCircle2, Printer, ArrowRight, Package, Truck, Calendar, ShieldCheck, Smartphone } from 'lucide-react';

interface OrderConfirmationModalProps {
  order: Order | null;
  onClose: () => void;
  onTrackOrder: (orderId: string) => void;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  order,
  onClose,
  onTrackOrder,
}) => {
  if (!order) return null;

  const paymentLabel = 
    order.paymentMethod === 'cod' ? 'Cash on Delivery (Advance ৳100 Paid)' :
    order.paymentMethod === 'mfs_bkash' ? 'bKash Mobile Financial Services' :
    order.paymentMethod === 'mfs_nagad' ? 'Nagad Mobile Financial Services' : 'Online Credit/Debit Card';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div 
        className="relative w-full max-w-2xl bg-white border border-stone-200 rounded-lg shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header confirmation ribbon */}
        <div className="bg-emerald-950 text-white p-6 sm:p-8 text-center">
          <div className="flex justify-center mb-3">
            <NAuraLogo size="sm" variant="light" subtitle="OFFICIAL RECEIPT" />
          </div>

          <div className="w-12 h-12 bg-emerald-900 rounded-full flex items-center justify-center mx-auto mb-2 border border-emerald-700">
            <CheckCircle2 className="w-7 h-7 text-emerald-300" />
          </div>

          <span className="text-xs uppercase tracking-widest text-emerald-300 font-semibold">
            Consignment Successfully Booked
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-medium mt-1">
            Thank you, {order.customerName.split(' ')[0]}
          </h2>
          <p className="text-xs text-emerald-200 mt-2 max-w-md mx-auto">
            Order <strong className="font-mono text-white">{order.id}</strong> has been logged to the N AURA fulfillment desk and is scheduled for dispatch.
          </p>
        </div>

        {/* Receipt Content */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[65vh] overflow-y-auto text-xs">
          {/* Key metadata grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-stone-50 rounded-lg border border-stone-200">
            <div>
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider">Order ID</span>
              <span className="font-mono tabular-nums font-semibold text-stone-950 text-sm">{order.id}</span>
            </div>
            <div>
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider">Booking Date</span>
              <span className="font-medium text-stone-800">
                {new Date(order.createdAt).toLocaleDateString()}
              </span>
            </div>
            <div>
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider">Net Amount</span>
              <span className="font-mono tabular-nums font-semibold text-stone-950 text-sm">
                ৳{order.total.toLocaleString()}
              </span>
            </div>
            <div>
              <span className="text-stone-400 block text-[11px] uppercase tracking-wider">Method</span>
              <span className="font-medium text-stone-800 capitalize">
                {order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'bKash Paid'}
              </span>
            </div>
          </div>

          {/* Delivery Destination */}
          <div>
            <h4 className="text-xs uppercase tracking-wider font-semibold text-stone-900 mb-2 flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-stone-700" />
              <span>Shipping Destination</span>
            </h4>
            <div className="p-3.5 bg-stone-50 rounded border border-stone-200 text-stone-700 leading-relaxed">
              <p className="font-bold text-stone-950">{order.customerName} · {order.phone}</p>
              <p>{order.shippingAddress}, {order.city} {order.postalCode}</p>
              {order.notes && <p className="text-stone-500 mt-1 italic">Special Note: {order.notes}</p>}
            </div>
          </div>

          {/* ৳100 Advance Security Deposit Clause */}
          <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200 space-y-1.5">
            <div className="flex items-center justify-between font-semibold text-emerald-950">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Mandatory Initial Security Payment: ৳100</span>
              </span>
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-emerald-200 text-emerald-900 font-bold">
                Auto-Verified
              </span>
            </div>
            <p className="text-[11px] text-stone-600 leading-relaxed">
              Your ৳100 bKash security advance has been confirmed on the merchant ledger (TrxID: <strong>{order.securityDepositTxId || 'VERIFIED'}</strong>).
              {order.paymentMethod === 'cod' && (
                <> Remaining balance of <strong className="text-amber-900 font-mono">৳{order.remainingDueOnDelivery.toLocaleString()}</strong> will be collected by courier upon arrival.</>
              )}
            </p>
          </div>

          {/* Itemized Manifest */}
          <div>
            <h4 className="text-xs uppercase tracking-wider font-semibold text-stone-900 mb-2 flex items-center gap-1.5">
              <Package className="w-3.5 h-3.5 text-stone-700" />
              <span>Consignment Items ({order.items.length})</span>
            </h4>
            <div className="divide-y divide-stone-100 border border-stone-200 rounded-lg overflow-hidden">
              {order.items.map((item, idx) => (
                <div key={idx} className="p-3 bg-white flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.product.images[0]}
                      alt=""
                      className="w-10 h-10 object-cover rounded border border-stone-200"
                    />
                    <div>
                      <p className="font-semibold text-stone-900">{item.product.name}</p>
                      <p className="text-stone-400 text-[11px] font-mono">
                        Qty: {item.quantity} × ৳{item.product.price.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <span className="font-mono tabular-nums font-bold text-stone-950">
                    ৳{(item.quantity * item.product.price).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-5 sm:p-6 border-t border-stone-200 bg-stone-50 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={handlePrint}
            className="px-4 py-2 border border-stone-300 rounded text-xs font-medium text-stone-700 hover:bg-stone-100 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Official Receipt</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onTrackOrder(order.id)}
              className="px-4 py-2 border border-stone-900 text-stone-900 hover:bg-stone-100 rounded text-xs font-medium transition-colors cursor-pointer"
            >
              Track Consignment
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2 bg-stone-950 text-white hover:bg-stone-800 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>Continue Shopping</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
