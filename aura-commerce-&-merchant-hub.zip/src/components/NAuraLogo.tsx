import React from 'react';

interface NAuraLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'dark' | 'light' | 'gold';
  showWordmark?: boolean;
  subtitle?: string;
}

export const NAuraLogo: React.FC<NAuraLogoProps> = ({
  className = '',
  size = 'md',
  variant = 'dark',
  showWordmark = true,
  subtitle,
}) => {
  // Dimensions based on size
  const iconSize = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  }[size];

  const textSize = {
    sm: 'text-lg tracking-wider',
    md: 'text-2xl tracking-widest',
    lg: 'text-3xl tracking-widest',
    xl: 'text-4xl tracking-[0.2em]',
  }[size];

  // Theme palettes
  const isDark = variant === 'dark';
  const isGold = variant === 'gold';

  const ringStroke = isGold
    ? '#D4AF37'
    : isDark
    ? '#1c1917'
    : '#f5f5f4';

  const nFill = isGold
    ? '#F59E0B'
    : isDark
    ? '#1c1917'
    : '#ffffff';

  const auraAccent = isGold
    ? '#10B981'
    : isDark
    ? '#059669'
    : '#34D399';

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Precision Geometric SVG Emblem: Interlocking Sculpted "N" enveloped by an ethereal circular "AURA" orbit */}
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${iconSize} shrink-0 transition-transform duration-300 hover:rotate-6`}
        aria-hidden="true"
      >
        <defs>
          <linearGradient id={`auraGrad_${variant}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={auraAccent} stopOpacity="0.9" />
            <stop offset="50%" stopColor={isGold ? '#D97706' : ringStroke} stopOpacity="0.8" />
            <stop offset="100%" stopColor={auraAccent} stopOpacity="0.3" />
          </linearGradient>

          <filter id={`auraGlow_${variant}`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Outer Radiant Orbit (The "AURA" Halo) */}
        <circle
          cx="50"
          cy="50"
          r="44"
          stroke={`url(#auraGrad_${variant})`}
          strokeWidth="2.5"
          strokeDasharray="6 4"
          className="opacity-75"
        />

        {/* Inner Solid Meridian Ring */}
        <circle
          cx="50"
          cy="50"
          r="38"
          stroke={ringStroke}
          strokeWidth="1.5"
          strokeOpacity="0.4"
        />

        {/* Orbiting Celestial Radiant Orbs */}
        <circle cx="50" cy="6" r="3" fill={auraAccent} filter={`url(#auraGlow_${variant})`} />
        <circle cx="94" cy="50" r="2.5" fill={auraAccent} />
        <circle cx="6" cy="50" r="2" fill={ringStroke} />
        <circle cx="50" cy="94" r="2.5" fill={auraAccent} />

        {/* Architectural Monogram "N" */}
        {/* Left Vertical Pillar */}
        <path
          d="M32 26V74"
          stroke={nFill}
          strokeWidth="6"
          strokeLinecap="round"
        />
        {/* Dynamic Diagonal Slash */}
        <path
          d="M32 28L68 72"
          stroke={nFill}
          strokeWidth="6.5"
          strokeLinecap="round"
        />
        {/* Right Vertical Pillar */}
        <path
          d="M68 26V74"
          stroke={nFill}
          strokeWidth="6"
          strokeLinecap="round"
        />

        {/* Subtle Luxury Center Prism Light Reflection */}
        <path
          d="M48 46L54 50L50 56L44 52Z"
          fill={auraAccent}
          fillOpacity="0.85"
        />
      </svg>

      {/* Typographic Wordmark */}
      {showWordmark && (
        <div className="flex flex-col text-left leading-tight">
          <div className="flex items-center gap-1.5">
            <span
              className={`font-serif font-bold ${textSize} ${
                isDark ? 'text-stone-950' : 'text-white'
              }`}
            >
              N <span className="font-light tracking-[0.25em]">AURA</span>
            </span>
          </div>

          {subtitle && (
            <span
              className={`text-[9px] uppercase tracking-[0.25em] font-mono font-medium mt-0.5 ${
                isDark ? 'text-stone-500' : 'text-stone-400'
              }`}
            >
              {subtitle}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
