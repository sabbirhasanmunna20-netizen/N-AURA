import React, { useState, useEffect, useRef } from 'react';
import { Toast } from './types';
import { 
  ShoppingBag, 
  CheckCircle2, 
  Heart, 
  Info, 
  AlertTriangle, 
  AlertCircle, 
  X, 
  ArrowRight,
  Package
} from 'lucide-react';

interface ToastItemProps {
  toast: Toast;
  onDismiss: (id: string) => void;
}

export const ToastItem: React.FC<ToastItemProps> = ({ toast, onDismiss }) => {
  const duration = toast.duration ?? 4500;
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(100);
  const remainingTimeRef = useRef(duration);
  const startTimeRef = useRef<number>(Date.now());
  const timerRef = useRef<number | null>(null);

  // Auto-dismiss countdown with pause-on-hover
  useEffect(() => {
    if (duration <= 0) return;

    if (isPaused) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    startTimeRef.current = Date.now();
    const interval = 25; // 25ms tick for smooth progress bar

    timerRef.current = window.setInterval(() => {
      const elapsed = Date.now() - startTimeRef.current;
      const currentRemaining = Math.max(0, remainingTimeRef.current - elapsed);
      setProgress((currentRemaining / duration) * 100);

      if (currentRemaining <= 0) {
        if (timerRef.current) clearInterval(timerRef.current);
        onDismiss(toast.id);
      }
    }, interval);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      const elapsed = Date.now() - startTimeRef.current;
      remainingTimeRef.current = Math.max(0, remainingTimeRef.current - elapsed);
    };
  }, [isPaused, duration, toast.id, onDismiss]);

  const handleMouseEnter = () => setIsPaused(true);
  const handleMouseLeave = () => setIsPaused(false);

  // Render icon based on toast type
  const renderIcon = () => {
    switch (toast.type) {
      case 'cart':
        return (
          <div className="w-8 h-8 rounded-full bg-emerald-50 border border-emerald-200/80 flex items-center justify-center shrink-0 text-emerald-700">
            <ShoppingBag className="w-4 h-4" />
          </div>
        );
      case 'order':
        return (
          <div className="w-8 h-8 rounded-full bg-stone-900 border border-stone-800 flex items-center justify-center shrink-0 text-amber-300">
            <Package className="w-4 h-4" />
          </div>
        );
      case 'wishlist':
        return (
          <div className="w-8 h-8 rounded-full bg-rose-50 border border-rose-200 flex items-center justify-center shrink-0 text-rose-600">
            <Heart className="w-4 h-4 fill-rose-500" />
          </div>
        );
      case 'success':
        return (
          <div className="w-8 h-8 rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0 text-emerald-600">
            <CheckCircle2 className="w-4 h-4" />
          </div>
        );
      case 'warning':
        return (
          <div className="w-8 h-8 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center shrink-0 text-amber-600">
            <AlertTriangle className="w-4 h-4" />
          </div>
        );
      case 'error':
        return (
          <div className="w-8 h-8 rounded-full bg-rose-50 border border-rose-200 flex items-center justify-center shrink-0 text-rose-600">
            <AlertCircle className="w-4 h-4" />
          </div>
        );
      case 'info':
      default:
        return (
          <div className="w-8 h-8 rounded-full bg-stone-100 border border-stone-200 flex items-center justify-center shrink-0 text-stone-700">
            <Info className="w-4 h-4" />
          </div>
        );
    }
  };

  // Color bar styling based on type
  const getProgressColor = () => {
    switch (toast.type) {
      case 'cart':
        return 'bg-emerald-600';
      case 'order':
        return 'bg-amber-600';
      case 'wishlist':
        return 'bg-rose-500';
      case 'success':
        return 'bg-emerald-600';
      case 'warning':
        return 'bg-amber-500';
      case 'error':
        return 'bg-rose-600';
      default:
        return 'bg-stone-800';
    }
  };

  return (
    <div
      role={toast.type === 'error' ? 'alert' : 'status'}
      aria-live="polite"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className="pointer-events-auto relative group overflow-hidden w-full sm:w-96 bg-white/95 backdrop-blur-md rounded-xl shadow-xl border border-stone-200/90 text-stone-900 transition-all duration-300 hover:shadow-2xl hover:border-stone-300"
    >
      <div className="p-3.5 sm:p-4 flex items-start gap-3">
        {/* Type Icon */}
        {renderIcon()}

        {/* Optional Thumbnail Image */}
        {toast.thumbnail && (
          <div className="w-11 h-11 rounded-lg border border-stone-200 overflow-hidden shrink-0 bg-stone-100">
            <img
              src={toast.thumbnail}
              alt=""
              className="w-full h-full object-cover object-center"
              loading="lazy"
            />
          </div>
        )}

        {/* Content */}
        <div className="flex-1 min-w-0 pr-1">
          <div className="flex items-center gap-2">
            <h4 className="text-xs font-semibold text-stone-950 uppercase tracking-wider font-mono">
              {toast.title}
            </h4>
            {toast.quantity && toast.quantity > 1 && (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-stone-100 text-stone-600 font-medium">
                ×{toast.quantity}
              </span>
            )}
          </div>

          {toast.message && (
            <p className="mt-0.5 text-xs text-stone-600 leading-snug line-clamp-2">
              {toast.message}
            </p>
          )}

          {toast.price !== undefined && (
            <span className="inline-block mt-1 font-mono text-[11px] font-bold text-stone-900">
              ৳{toast.price.toLocaleString()}
            </span>
          )}

          {/* Action button if provided */}
          {toast.action && (
            <div className="mt-2.5">
              <button
                type="button"
                onClick={() => {
                  toast.action?.onClick();
                  onDismiss(toast.id);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-[11px] font-medium tracking-wide bg-stone-900 text-white hover:bg-stone-800 transition-colors shadow-2xs cursor-pointer group/btn"
              >
                <span>{toast.action.label}</span>
                <ArrowRight className="w-3 h-3 transition-transform group-hover/btn:translate-x-0.5" />
              </button>
            </div>
          )}
        </div>

        {/* Dismiss Button */}
        {toast.dismissible !== false && (
          <button
            type="button"
            onClick={() => onDismiss(toast.id)}
            aria-label="Close notification"
            className="p-1 -mr-1 -mt-1 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Progress Bar (countdown indicator) */}
      {duration > 0 && (
        <div className="h-0.5 w-full bg-stone-100 overflow-hidden">
          <div
            className={`h-full ${getProgressColor()} transition-all ease-linear`}
            style={{ width: `${progress}%` }}
          />
        </div>
      )}
    </div>
  );
};
