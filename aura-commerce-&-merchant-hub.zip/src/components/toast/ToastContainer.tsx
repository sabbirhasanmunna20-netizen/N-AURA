import React from 'react';
import { Toast } from './types';
import { ToastItem } from './ToastItem';

interface ToastContainerProps {
  toasts: Toast[];
  onDismiss: (id: string) => void;
  onClearAll?: () => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({
  toasts,
  onDismiss,
  onClearAll,
}) => {
  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      aria-atomic="false"
      className="fixed top-20 right-4 sm:top-20 sm:right-6 z-50 flex flex-col gap-2.5 max-w-[calc(100vw-2rem)] sm:max-w-md pointer-events-none"
    >
      {/* Optional clear-all indicator when multiple notifications stack */}
      {toasts.length > 2 && onClearAll && (
        <div className="flex justify-end pointer-events-auto">
          <button
            type="button"
            onClick={onClearAll}
            className="text-[11px] font-mono text-stone-500 hover:text-stone-900 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-md border border-stone-200 shadow-xs transition-colors cursor-pointer"
          >
            Clear all ({toasts.length})
          </button>
        </div>
      )}

      {/* Render stacked toasts */}
      <div className="flex flex-col gap-2.5">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="transition-all duration-300 ease-out transform translate-y-0 opacity-100 animate-in fade-in slide-in-from-top-3 sm:slide-in-from-right-3"
          >
            <ToastItem toast={toast} onDismiss={onDismiss} />
          </div>
        ))}
      </div>
    </div>
  );
};
