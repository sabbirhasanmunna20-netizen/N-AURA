import React from 'react';
import { Product, Order } from '../../types';

export type ToastType = 'success' | 'cart' | 'order' | 'wishlist' | 'info' | 'warning' | 'error';

export interface ToastAction {
  label: string;
  onClick: () => void;
}

export interface Toast {
  id: string;
  type: ToastType;
  title: string;
  message?: string;
  thumbnail?: string;
  quantity?: number;
  price?: number;
  duration?: number; // ms, default 4000
  action?: ToastAction;
  dismissible?: boolean;
  createdAt: number;
}

export type ToastOptions = Omit<Partial<Toast>, 'id' | 'createdAt'>;

export interface ToastContextType {
  toasts: Toast[];
  showToast: (toast: Omit<Toast, 'id' | 'createdAt'>) => string;
  dismissToast: (id: string) => void;
  clearAllToasts: () => void;
  toast: {
    success: (title: string, message?: string, options?: ToastOptions) => string;
    info: (title: string, message?: string, options?: ToastOptions) => string;
    warning: (title: string, message?: string, options?: ToastOptions) => string;
    error: (title: string, message?: string, options?: ToastOptions) => string;
    cart: (product: Product, quantity?: number, options?: { onOpenCart?: () => void }) => string;
    order: (order: Order, options?: { onTrackOrder?: () => void }) => string;
    wishlist: (product: Product, isSaved: boolean, options?: { onOpenWishlist?: () => void }) => string;
  };
}
