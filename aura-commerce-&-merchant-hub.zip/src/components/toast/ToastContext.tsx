import React, { createContext, useContext, useState, useCallback, useMemo, useEffect } from 'react';
import { Toast, ToastContextType, ToastOptions } from './types';
import { ToastContainer } from './ToastContainer';
import { Product, Order } from '../../types';

const ToastContext = createContext<ToastContextType | null>(null);

// Custom event name for external/global dispatch
const TOAST_EVENT_NAME = 'aura_toast_dispatch';

interface GlobalToastDetail {
  action: 'show' | 'dismiss' | 'clear';
  payload?: any;
}

/**
 * Global toast dispatcher for use anywhere, including outside React component render trees
 */
export const globalToast = {
  show: (toast: Omit<Toast, 'id' | 'createdAt'>): void => {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent<GlobalToastDetail>(TOAST_EVENT_NAME, {
          detail: { action: 'show', payload: toast },
        })
      );
    }
  },
  cart: (product: Product, quantity = 1, options?: { onOpenCart?: () => void }): void => {
    globalToast.show({
      type: 'cart',
      title: 'Added to cart',
      message: product.name,
      thumbnail: product.images?.[0],
      quantity,
      price: product.price * quantity,
      duration: 4000,
      action: options?.onOpenCart
        ? { label: 'View Bag', onClick: options.onOpenCart }
        : undefined,
    });
  },
  order: (order: Order, options?: { onTrackOrder?: () => void }): void => {
    globalToast.show({
      type: 'order',
      title: 'Order confirmed',
      message: `Order #${order.id} for ৳${order.total.toLocaleString()} — dispatching to ${order.city}`,
      duration: 6000,
      action: options?.onTrackOrder
        ? { label: 'Track Order', onClick: options.onTrackOrder }
        : undefined,
    });
  },
  wishlist: (product: Product, isSaved: boolean, options?: { onOpenWishlist?: () => void }): void => {
    globalToast.show({
      type: 'wishlist',
      title: isSaved ? 'Saved to Wishlist' : 'Removed from Saved Items',
      message: product.name,
      thumbnail: product.images?.[0],
      duration: 3500,
      action: isSaved && options?.onOpenWishlist
        ? { label: 'Saved Items', onClick: options.onOpenWishlist }
        : undefined,
    });
  },
  success: (title: string, message?: string, options?: ToastOptions): void => {
    globalToast.show({
      type: 'success',
      title,
      message,
      duration: 4000,
      ...options,
    });
  },
  info: (title: string, message?: string, options?: ToastOptions): void => {
    globalToast.show({
      type: 'info',
      title,
      message,
      duration: 3500,
      ...options,
    });
  },
  warning: (title: string, message?: string, options?: ToastOptions): void => {
    globalToast.show({
      type: 'warning',
      title,
      message,
      duration: 5000,
      ...options,
    });
  },
  error: (title: string, message?: string, options?: ToastOptions): void => {
    globalToast.show({
      type: 'error',
      title,
      message,
      duration: 6000,
      ...options,
    });
  },
};

interface ToastProviderProps {
  children: React.ReactNode;
}

export const ToastProvider: React.FC<ToastProviderProps> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const clearAllToasts = useCallback(() => {
    setToasts([]);
  }, []);

  const showToast = useCallback((toastData: Omit<Toast, 'id' | 'createdAt'>): string => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const newToast: Toast = {
      ...toastData,
      id,
      createdAt: Date.now(),
    };

    setToasts((prev) => {
      // Keep maximum of 4 active toasts so screen doesn't get flooded
      const trimmed = prev.slice(-3);
      return [...trimmed, newToast];
    });

    return id;
  }, []);

  // Listen for global custom events
  useEffect(() => {
    const handleGlobalEvent = (event: Event) => {
      const customEvent = event as CustomEvent<GlobalToastDetail>;
      if (!customEvent.detail) return;

      const { action, payload } = customEvent.detail;
      if (action === 'show' && payload) {
        showToast(payload);
      } else if (action === 'dismiss' && typeof payload === 'string') {
        dismissToast(payload);
      } else if (action === 'clear') {
        clearAllToasts();
      }
    };

    window.addEventListener(TOAST_EVENT_NAME, handleGlobalEvent);
    return () => window.removeEventListener(TOAST_EVENT_NAME, handleGlobalEvent);
  }, [showToast, dismissToast, clearAllToasts]);

  // Context toast helpers
  const toastHelpers = useMemo(() => ({
    success: (title: string, message?: string, options?: ToastOptions) =>
      showToast({ type: 'success', title, message, duration: 4000, ...options }),
    info: (title: string, message?: string, options?: ToastOptions) =>
      showToast({ type: 'info', title, message, duration: 3500, ...options }),
    warning: (title: string, message?: string, options?: ToastOptions) =>
      showToast({ type: 'warning', title, message, duration: 5000, ...options }),
    error: (title: string, message?: string, options?: ToastOptions) =>
      showToast({ type: 'error', title, message, duration: 6000, ...options }),
    cart: (product: Product, quantity = 1, options?: { onOpenCart?: () => void }) =>
      showToast({
        type: 'cart',
        title: 'Added to cart',
        message: product.name,
        thumbnail: product.images?.[0],
        quantity,
        price: product.price * quantity,
        duration: 4000,
        action: options?.onOpenCart
          ? { label: 'View Bag', onClick: options.onOpenCart }
          : undefined,
      }),
    order: (order: Order, options?: { onTrackOrder?: () => void }) =>
      showToast({
        type: 'order',
        title: 'Order confirmed',
        message: `Order #${order.id} for ৳${order.total.toLocaleString()} — dispatching to ${order.city}`,
        duration: 6000,
        action: options?.onTrackOrder
          ? { label: 'Track Order', onClick: options.onTrackOrder }
          : undefined,
      }),
    wishlist: (product: Product, isSaved: boolean, options?: { onOpenWishlist?: () => void }) =>
      showToast({
        type: 'wishlist',
        title: isSaved ? 'Saved to Wishlist' : 'Removed from Saved Items',
        message: product.name,
        thumbnail: product.images?.[0],
        duration: 3500,
        action: isSaved && options?.onOpenWishlist
          ? { label: 'Saved Items', onClick: options.onOpenWishlist }
          : undefined,
      }),
  }), [showToast]);

  const value: ToastContextType = useMemo(
    () => ({
      toasts,
      showToast,
      dismissToast,
      clearAllToasts,
      toast: toastHelpers,
    }),
    [toasts, showToast, dismissToast, clearAllToasts, toastHelpers]
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      <ToastContainer
        toasts={toasts}
        onDismiss={dismissToast}
        onClearAll={clearAllToasts}
      />
    </ToastContext.Provider>
  );
};

export const useToast = (): ToastContextType => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};
