import React, { useState } from 'react';
import { Product, Order } from '../../types';
import { ProductManagement } from './ProductManagement';
import { OrderManagement } from './OrderManagement';
import { TroubleshootingPanel } from './TroubleshootingPanel';
import { StorageService } from '../../services/storage';
import { NAuraLogo } from '../NAuraLogo';
import { ShieldCheck, Package, ShoppingBag, Wrench, Lock, ArrowLeft, Store } from 'lucide-react';

interface AdminDashboardProps {
  products: Product[];
  orders: Order[];
  onRefreshAll: () => void;
  onReturnToStore: () => void;
  onLockSession: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  products,
  orders,
  onRefreshAll,
  onReturnToStore,
  onLockSession,
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'troubleshoot'>('products');

  const pendingOrdersCount = orders.filter((o) => o.orderStatus === 'placed' || o.orderStatus === 'confirmed').length;
  const lowStockCount = products.filter((p) => p.stock <= 5).length;

  return (
    <div className="min-h-screen bg-[#F7F7F5] text-stone-900 pb-16">
      {/* Structurally Isolated Management Frame Banner */}
      <div className="bg-stone-950 text-stone-300 border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <NAuraLogo size="sm" variant="light" subtitle="MERCHANT CONTROL FRAME" />
            <div className="hidden sm:block pl-3 border-l border-stone-800">
              <span className="text-[10px] uppercase font-mono tracking-widest px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-semibold">
                Admin Isolation Mode Active
              </span>
              <p className="text-[11px] text-stone-400 mt-0.5">
                Customer orders, catalog management & live diagnostics
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onReturnToStore}
              className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded text-xs font-medium border border-stone-700 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Store className="w-3.5 h-3.5" />
              <span>Back to Storefront</span>
            </button>

            <button
              onClick={onLockSession}
              className="px-3 py-1.5 bg-stone-900 hover:bg-rose-950 text-stone-300 hover:text-rose-200 rounded text-xs font-medium border border-stone-700 hover:border-rose-900 flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Lock Admin Session"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Lock Session</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Admin Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* Navigation Tabs (Functional segmented controls) */}
        <div className="flex flex-wrap items-center gap-2 mb-8 border-b border-stone-200 pb-3">
          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold rounded-md transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'products'
                ? 'bg-stone-950 text-white shadow-xs'
                : 'bg-white text-stone-600 hover:text-stone-950 border border-stone-200'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Product Catalog CRUD ({products.length})</span>
            {lowStockCount > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                activeTab === 'products' ? 'bg-amber-500 text-stone-950' : 'bg-amber-100 text-amber-900'
              }`}>
                {lowStockCount} Low
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold rounded-md transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-stone-950 text-white shadow-xs'
                : 'bg-white text-stone-600 hover:text-stone-950 border border-stone-200'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Orders & Dispatches ({orders.length})</span>
            {pendingOrdersCount > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                activeTab === 'orders' ? 'bg-emerald-400 text-stone-950' : 'bg-emerald-100 text-emerald-900'
              }`}>
                {pendingOrdersCount} Active
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('troubleshoot')}
            className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold rounded-md transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'troubleshoot'
                ? 'bg-stone-950 text-white shadow-xs'
                : 'bg-white text-stone-600 hover:text-stone-950 border border-stone-200'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>Real-Time Troubleshooting & Integrity</span>
          </button>
        </div>

        {/* Tab View Render */}
        {activeTab === 'products' && (
          <ProductManagement products={products} onRefresh={onRefreshAll} />
        )}

        {activeTab === 'orders' && (
          <OrderManagement orders={orders} onRefresh={onRefreshAll} />
        )}

        {activeTab === 'troubleshoot' && (
          <TroubleshootingPanel onRefreshAll={onRefreshAll} />
        )}
      </main>
    </div>
  );
};
