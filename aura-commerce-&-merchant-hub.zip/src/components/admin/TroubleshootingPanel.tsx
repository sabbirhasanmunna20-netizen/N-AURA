import React, { useState } from 'react';
import { StorageService } from '../../services/storage';
import { AuditLog, SystemHealth } from '../../types';
import { 
  Wrench, 
  Activity, 
  Download, 
  Upload, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  Database, 
  HardDrive, 
  Cpu,
  RefreshCw,
  Sliders
} from 'lucide-react';

interface TroubleshootingPanelProps {
  onRefreshAll: () => void;
}

export const TroubleshootingPanel: React.FC<TroubleshootingPanelProps> = ({ onRefreshAll }) => {
  const [health, setHealth] = useState<SystemHealth>(() => StorageService.getSystemHealth());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => StorageService.getAuditLogs());
  const [diagnosticResult, setDiagnosticResult] = useState<{ resolvedIssues: string[]; errorsFound: number } | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [importJson, setImportJson] = useState('');
  const [showImportModal, setShowImportModal] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState('');

  const refreshHealth = () => {
    setHealth(StorageService.getSystemHealth());
    setAuditLogs(StorageService.getAuditLogs());
  };

  const handleRunDiagnostics = () => {
    setIsScanning(true);
    setDiagnosticResult(null);

    setTimeout(() => {
      const res = StorageService.runDiagnostics();
      setDiagnosticResult(res);
      setIsScanning(false);
      refreshHealth();
      onRefreshAll();
    }, 600);
  };

  const handleRecalculateInventory = () => {
    const res = StorageService.recalculateInventory();
    setFeedbackMsg(`Inventory invariant check completed. ${res.repairedSkus} SKU values audited.`);
    setTimeout(() => setFeedbackMsg(''), 4000);
    refreshHealth();
    onRefreshAll();
  };

  const handleExportState = () => {
    const jsonStr = StorageService.exportState();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `aura_store_backup_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    setFeedbackMsg('Store state backup downloaded successfully.');
    setTimeout(() => setFeedbackMsg(''), 4000);
  };

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!importJson.trim()) return;
    const ok = StorageService.importState(importJson.trim());
    if (ok) {
      setShowImportModal(false);
      setImportJson('');
      setFeedbackMsg('Store successfully restored from JSON backup.');
      setTimeout(() => setFeedbackMsg(''), 4000);
      refreshHealth();
      onRefreshAll();
    } else {
      alert('Invalid backup JSON format. Please verify file integrity.');
    }
  };

  const handleFactoryReset = () => {
    if (confirm('Are you sure you want to reset all inventory and sample orders back to initial factory state?')) {
      StorageService.resetToFactorySeed();
      refreshHealth();
      onRefreshAll();
      setFeedbackMsg('Store reset to clean factory demonstrator state.');
      setTimeout(() => setFeedbackMsg(''), 4000);
    }
  };

  return (
    <div className="space-y-6 text-xs">
      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Real-time Health Diagnostics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white p-4 rounded-lg border border-stone-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-md bg-stone-100 flex items-center justify-center text-stone-700">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-wider text-stone-400 block font-medium">
              Data Storage
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-bold font-mono tabular-nums text-stone-900">
                {health.storageUsageKB}
              </span>
              <span className="text-stone-500 font-medium">KB Used</span>
            </div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-4 rounded-lg border border-stone-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-md bg-stone-100 flex items-center justify-center text-stone-700">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-wider text-stone-400 block font-medium">
              Active Inventory
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-bold font-mono tabular-nums text-stone-900">
                {health.productCount}
              </span>
              <span className="text-stone-500 font-medium">Products</span>
            </div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-4 rounded-lg border border-stone-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-md bg-stone-100 flex items-center justify-center text-stone-700">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-wider text-stone-400 block font-medium">
              Processed Orders
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-bold font-mono tabular-nums text-stone-900">
                {health.orderCount}
              </span>
              <span className="text-stone-500 font-medium">Records</span>
            </div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-4 rounded-lg border border-stone-200 flex items-center gap-3">
          <div className={`w-10 h-10 rounded-md flex items-center justify-center ${
            health.status === 'optimal' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
          }`}>
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-wider text-stone-400 block font-medium">
              System Invariants
            </span>
            <span className={`text-sm font-semibold capitalize ${
              health.status === 'optimal' ? 'text-emerald-700' : 'text-amber-700'
            }`}>
              {health.status} Status
            </span>
          </div>
        </div>
      </div>

      {/* Troubleshooting Action Hub */}
      <div className="bg-white p-6 rounded-lg border border-stone-200 space-y-4">
        <div>
          <h3 className="text-base font-serif font-semibold text-stone-950 flex items-center gap-2">
            <Wrench className="w-4 h-4 text-stone-700" />
            <span>Storefront Direct Management & Troubleshooting Console</span>
          </h3>
          <p className="text-stone-500 mt-1">
            Execute immediate diagnostic checks, repair anomalous store states, reconcile inventories, and manage persistence backups.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {/* Action 1: Integrity Scan */}
          <button
            onClick={handleRunDiagnostics}
            disabled={isScanning}
            className="p-4 rounded-lg border border-stone-200 hover:border-stone-900 bg-stone-50 hover:bg-white text-left transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-2 font-semibold text-stone-900 mb-1">
                <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
                <span>Run Integrity Scanner</span>
              </div>
              <p className="text-[11px] text-stone-500">
                Audits products, detects corrupted JSON or NaN values, and repairs schema invariants.
              </p>
            </div>
            <span className="text-[10px] font-semibold text-stone-900 uppercase mt-3 underline">
              {isScanning ? 'Scanning...' : 'Execute Scan'}
            </span>
          </button>

          {/* Action 2: Inventory Recalculation */}
          <button
            onClick={handleRecalculateInventory}
            className="p-4 rounded-lg border border-stone-200 hover:border-stone-900 bg-stone-50 hover:bg-white text-left transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-2 font-semibold text-stone-900 mb-1">
                <Sliders className="w-4 h-4" />
                <span>Recalculate Inventory</span>
              </div>
              <p className="text-[11px] text-stone-500">
                Reconciles stock balances against pending dispatches and removes negative quantities.
              </p>
            </div>
            <span className="text-[10px] font-semibold text-stone-900 uppercase mt-3 underline">
              Recalculate
            </span>
          </button>

          {/* Action 3: Export Backup */}
          <button
            onClick={handleExportState}
            className="p-4 rounded-lg border border-stone-200 hover:border-stone-900 bg-stone-50 hover:bg-white text-left transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-2 font-semibold text-stone-900 mb-1">
                <Download className="w-4 h-4" />
                <span>Export Store Backup</span>
              </div>
              <p className="text-[11px] text-stone-500">
                Downloads permanent snapshot of all products, customer orders, and audit records as JSON.
              </p>
            </div>
            <span className="text-[10px] font-semibold text-stone-900 uppercase mt-3 underline">
              Download JSON
            </span>
          </button>

          {/* Action 4: Restore Backup */}
          <button
            onClick={() => setShowImportModal(true)}
            className="p-4 rounded-lg border border-stone-200 hover:border-stone-900 bg-stone-50 hover:bg-white text-left transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-2 font-semibold text-stone-900 mb-1">
                <Upload className="w-4 h-4" />
                <span>Restore From Backup</span>
              </div>
              <p className="text-[11px] text-stone-500">
                Imports external store snapshot to restore corrupted or missing configurations.
              </p>
            </div>
            <span className="text-[10px] font-semibold text-stone-900 uppercase mt-3 underline">
              Open Restore
            </span>
          </button>
        </div>

        {/* Diagnostic Output if run */}
        {diagnosticResult && (
          <div className="mt-4 p-4 bg-stone-50 rounded-lg border border-stone-200 space-y-2">
            <div className="flex items-center justify-between font-semibold text-stone-900">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Integrity Scan Complete ({diagnosticResult.errorsFound} issues caught)</span>
              </span>
              <span className="text-[11px] text-stone-400 font-mono">
                {new Date().toLocaleTimeString()}
              </span>
            </div>
            <ul className="list-disc list-inside text-stone-700 space-y-1">
              {diagnosticResult.resolvedIssues.map((issue, idx) => (
                <li key={idx}>{issue}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Factory Reset warning section */}
        <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h4 className="font-semibold text-stone-900">Factory Data Reseed</h4>
            <p className="text-stone-500 text-[11px]">
              Reset all inventory and order dispatches back to initial demonstration state.
            </p>
          </div>
          <button
            onClick={handleFactoryReset}
            className="px-3.5 py-2 border border-rose-300 text-rose-700 hover:bg-rose-50 rounded font-medium transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Factory Reset Demonstration Seed</span>
          </button>
        </div>
      </div>

      {/* Live Activity & Audit Log */}
      <div className="bg-white rounded-lg border border-stone-200 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-serif font-semibold text-stone-950">
              Permanent Audit & Operation Trail
            </h3>
            <p className="text-stone-500 mt-0.5">
              Append-only event log capturing checkout dispatches, inventory mutations, and diagnostic operations.
            </p>
          </div>
          <button
            onClick={refreshHealth}
            className="px-2.5 py-1.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded text-stone-600 flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Refresh</span>
          </button>
        </div>

        <div className="divide-y divide-stone-100 max-h-80 overflow-y-auto border border-stone-200 rounded">
          {auditLogs.map((log) => (
            <div key={log.id} className="p-3 flex items-start justify-between gap-3 hover:bg-stone-50/50">
              <div>
                <p className="font-medium text-stone-900">{log.message}</p>
                <div className="flex items-center gap-2 text-[11px] text-stone-400 mt-0.5">
                  <span className="font-mono">{log.author}</span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize font-mono">{log.type.replace('_', ' ')}</span>
                </div>
              </div>
              <span className="font-mono text-stone-400 text-[11px] shrink-0">
                {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-lg p-6 border border-stone-200 shadow-2xl space-y-4">
            <h4 className="text-base font-serif font-semibold text-stone-950">
              Restore Store State Archive
            </h4>
            <p className="text-stone-600">
              Paste the complete JSON backup snapshot generated by this platform to restore all inventory and orders.
            </p>
            <form onSubmit={handleImportSubmit} className="space-y-3">
              <textarea
                rows={8}
                required
                placeholder='{"products": [...], "orders": [...]}'
                value={importJson}
                onChange={(e) => setImportJson(e.target.value)}
                className="w-full p-3 font-mono text-[11px] bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white focus:outline-none"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowImportModal(false)}
                  className="px-3.5 py-2 border border-stone-300 rounded font-medium text-stone-700 hover:bg-stone-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-stone-950 hover:bg-stone-800 text-white rounded font-medium cursor-pointer"
                >
                  Import and Re-seed
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
