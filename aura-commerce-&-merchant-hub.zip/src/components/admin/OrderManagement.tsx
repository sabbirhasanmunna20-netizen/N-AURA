import React, { useState } from 'react';
import { Order, OrderStatus, PaymentStatus } from '../../types';
import { StorageService, WHATSAPP_SUPPORT_NUMBER, BKASH_PAYMENT_NUMBER, BUSINESS_LICENSE_INFO } from '../../services/storage';
import { NAuraLogo } from '../NAuraLogo';
import { 
  Search, 
  Eye, 
  CheckCircle2, 
  Truck, 
  Smartphone, 
  CreditCard, 
  Filter, 
  X, 
  Printer, 
  MessageCircle, 
  Clock, 
  ShieldCheck, 
  AlertCircle,
  Package,
  Calendar,
  MapPin,
  User,
  Phone,
  Mail,
  FileText,
  DollarSign
} from 'lucide-react';

interface OrderManagementProps {
  orders: Order[];
  onRefresh: () => void;
}

export const OrderManagement: React.FC<OrderManagementProps> = ({ orders, onRefresh }) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isInvoicePrintMode, setIsInvoicePrintMode] = useState(false);

  // Status Change handler
  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    StorageService.updateOrderStatus(orderId, newStatus);
    onRefresh();
    if (selectedOrder && selectedOrder.id === orderId) {
      setSelectedOrder({ ...selectedOrder, orderStatus: newStatus });
    }
  };

  // Payment Verification handler
  const handlePaymentVerify = (orderId: string) => {
    StorageService.updatePaymentStatus(orderId, 'paid');
    onRefresh();
    if (selectedOrder && selectedOrder.id === orderId) {
      setSelectedOrder({ ...selectedOrder, paymentStatus: 'paid' });
    }
  };

  // Metrics
  const totalRevenue = orders.reduce((sum, o) => sum + (o.orderStatus !== 'cancelled' ? o.total : 0), 0);
  const pendingOrdersCount = orders.filter((o) => o.orderStatus === 'placed' || o.orderStatus === 'confirmed' || o.orderStatus === 'processing').length;
  const verifiedDepositsCount = orders.filter((o) => o.securityDepositPaid || o.paymentStatus === 'paid' || o.paymentStatus === 'verified').length;
  const deliveredCount = orders.filter((o) => o.orderStatus === 'delivered').length;

  // Filtered Orders
  const filteredOrders = orders.filter((o) => {
    const q = search.toLowerCase().trim();
    const matchesSearch =
      !q ||
      o.id.toLowerCase().includes(q) ||
      o.customerName.toLowerCase().includes(q) ||
      o.phone.includes(q) ||
      o.email.toLowerCase().includes(q) ||
      o.city.toLowerCase().includes(q) ||
      (o.securityDepositTxId && o.securityDepositTxId.toLowerCase().includes(q)) ||
      (o.transactionId && o.transactionId.toLowerCase().includes(q));

    const matchesStatus = statusFilter === 'all' || o.orderStatus === statusFilter;
    const matchesPayment =
      paymentFilter === 'all' ||
      (paymentFilter === 'paid' && (o.paymentStatus === 'paid' || o.paymentStatus === 'verified')) ||
      (paymentFilter === 'pending' && o.paymentStatus === 'pending') ||
      (paymentFilter === 'cod' && o.paymentMethod === 'cod') ||
      (paymentFilter === 'bkash' && o.paymentMethod === 'mfs_bkash');

    return matchesSearch && matchesStatus && matchesPayment;
  });

  const handleOpenWhatsAppToCustomer = (order: Order) => {
    const cleanPhone = order.phone.replace(/[^0-9]/g, '');
    const intPhone = cleanPhone.startsWith('88') ? cleanPhone : `88${cleanPhone}`;
    const text = encodeURIComponent(
      `Hello ${order.customerName}! Greetings from N AURA. Regarding your Order #${order.id} (Total: ৳${order.total.toLocaleString()}): We have received your ৳100 advance payment and your consignment is currently ${order.orderStatus.toUpperCase()}. Please let us know if you need any assistance!`
    );
    window.open(`https://wa.me/${intPhone}?text=${text}`, '_blank');
  };

  const handlePrintManifest = (order: Order) => {
    setSelectedOrder(order);
    setIsInvoicePrintMode(true);
    setTimeout(() => {
      window.print();
    }, 300);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Metrics Bar */}
      <div className="bg-white p-6 rounded-lg border border-stone-200 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-serif font-bold text-stone-950">
                Customer Orders & Consignment Hub
              </h3>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 font-semibold border border-emerald-300">
                Live Ledger
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-1">
              View all customer orders, inspect itemized dispatches, track ৳100 bKash security advances, and manage fulfillment.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onRefresh}
              className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded text-xs font-semibold transition-colors cursor-pointer"
            >
              ↻ Refresh Orders
            </button>
          </div>
        </div>

        {/* KPI Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200/90">
            <span className="text-[11px] text-stone-500 font-medium block">Total Customer Orders</span>
            <span className="font-mono text-xl font-bold text-stone-950">{orders.length}</span>
            <span className="text-[10px] text-stone-400 block mt-0.5">Across all channels</span>
          </div>

          <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200/90">
            <span className="text-[11px] text-stone-500 font-medium block">Active / In-Fulfillment</span>
            <span className="font-mono text-xl font-bold text-amber-700">{pendingOrdersCount}</span>
            <span className="text-[10px] text-amber-600 block mt-0.5">Need processing or shipping</span>
          </div>

          <div className="p-3.5 bg-emerald-50/70 rounded-lg border border-emerald-200">
            <span className="text-[11px] text-emerald-800 font-medium block">৳100 Security Advances</span>
            <span className="font-mono text-xl font-bold text-emerald-950">{verifiedDepositsCount} Verified</span>
            <span className="text-[10px] text-emerald-700 block mt-0.5">bKash TrxID auto-verified</span>
          </div>

          <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200/90">
            <span className="text-[11px] text-stone-500 font-medium block">Gross Revenue Generated</span>
            <span className="font-mono text-xl font-bold text-stone-950">৳{totalRevenue.toLocaleString()}</span>
            <span className="text-[10px] text-emerald-600 block mt-0.5">{deliveredCount} delivered successfully</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-lg border border-stone-200 space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Field */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Order ID (e.g. AUR-1024), customer name, phone, Gmail, city, or bKash TrxID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded text-xs text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Fulfillment Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-stone-50 border border-stone-200 rounded text-xs text-stone-800 focus:bg-white focus:outline-none focus:border-stone-900 cursor-pointer"
          >
            <option value="all">All Fulfillment Statuses</option>
            <option value="placed">Placed (New Orders)</option>
            <option value="confirmed">Confirmed</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
          </select>

          {/* Payment Method / Security Advance Filter */}
          <select
            value={paymentFilter}
            onChange={(e) => setPaymentFilter(e.target.value)}
            className="px-3 py-2 bg-stone-50 border border-stone-200 rounded text-xs text-stone-800 focus:bg-white focus:outline-none focus:border-stone-900 cursor-pointer"
          >
            <option value="all">All Payment Classifications</option>
            <option value="cod">Cash on Delivery (Advance ৳100)</option>
            <option value="bkash">Full Online bKash</option>
            <option value="paid">Payment Verified / Paid</option>
            <option value="pending">Payment Pending</option>
          </select>
        </div>

        {/* Quick Filter Status Badges */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 text-xs">
          <span className="text-[11px] text-stone-400 mr-1 font-medium">Quick Filter:</span>
          {(['all', 'placed', 'confirmed', 'processing', 'shipped', 'delivered'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                statusFilter === st
                  ? 'bg-stone-950 text-white font-semibold'
                  : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
              }`}
            >
              {st === 'all' ? 'All Orders' : st.charAt(0).toUpperCase() + st.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3 px-4">Order ID & Timestamp</th>
                <th className="py-3 px-4">Customer Profile</th>
                <th className="py-3 px-4">Items Ordered</th>
                <th className="py-3 px-4">Advance & Settlement</th>
                <th className="py-3 px-4 text-right">Order Total</th>
                <th className="py-3 px-4">Fulfillment Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 text-stone-700">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-stone-400">
                    <Package className="w-8 h-8 mx-auto mb-2 text-stone-300" />
                    <p className="font-medium text-stone-600">No customer orders matching selected criteria.</p>
                    <p className="text-[11px] text-stone-400 mt-1">Try modifying your search or clearing filters.</p>
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => {
                  const isCod = order.paymentMethod === 'cod';
                  const dateStr = new Date(order.createdAt).toLocaleDateString();
                  const timeStr = new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

                  return (
                    <tr key={order.id} className="hover:bg-stone-50/80 transition-colors">
                      {/* Column 1: Order ID */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="font-mono tabular-nums font-bold text-stone-950 text-sm">{order.id}</div>
                        <div className="text-[11px] text-stone-400 flex items-center gap-1 mt-0.5">
                          <Calendar className="w-3 h-3" />
                          <span>{dateStr} · {timeStr}</span>
                        </div>
                      </td>

                      {/* Column 2: Customer */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="font-semibold text-stone-900 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-stone-400" />
                          <span>{order.customerName}</span>
                        </div>
                        <div className="text-[11px] text-stone-600 font-mono mt-0.5 flex items-center gap-1">
                          <Phone className="w-3 h-3 text-stone-400" />
                          <span>{order.phone}</span>
                        </div>
                        <div className="text-[11px] text-stone-500 font-mono truncate max-w-[180px] flex items-center gap-1">
                          <Mail className="w-3 h-3 text-stone-400" />
                          <span>{order.email}</span>
                        </div>
                        <div className="text-[11px] text-stone-400 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-stone-400" />
                          <span>{order.city}</span>
                        </div>
                      </td>

                      {/* Column 3: Items Ordered */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="text-[11px] font-semibold text-stone-900 mb-1">
                          {order.items.reduce((acc, i) => acc + i.quantity, 0)} items ({order.items.length} {order.items.length === 1 ? 'SKU' : 'SKUs'})
                        </div>
                        <div className="flex items-center gap-1.5">
                          {order.items.slice(0, 3).map((item, idx) => (
                            <img
                              key={idx}
                              src={item.product.images[0]}
                              alt={item.product.name}
                              title={`${item.product.name} (Qty: ${item.quantity})`}
                              className="w-7 h-7 object-cover rounded border border-stone-200"
                            />
                          ))}
                          {order.items.length > 3 && (
                            <span className="w-7 h-7 rounded bg-stone-100 border border-stone-200 flex items-center justify-center text-[10px] text-stone-600 font-mono">
                              +{order.items.length - 3}
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-stone-400 truncate max-w-[160px] mt-1">
                          {order.items[0]?.product.name}
                        </p>
                      </td>

                      {/* Column 4: Payment & ৳100 Advance */}
                      <td className="py-3.5 px-4 align-top space-y-1">
                        <div className="flex items-center gap-1.5 font-medium text-stone-900">
                          {isCod ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-stone-800">
                              <Truck className="w-3.5 h-3.5 text-stone-600" />
                              Cash on Delivery
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-pink-900">
                              <Smartphone className="w-3.5 h-3.5 text-pink-700" />
                              bKash Full Online
                            </span>
                          )}
                        </div>

                        {/* Mandatory ৳100 Security Advance badge */}
                        <div className="flex flex-wrap items-center gap-1">
                          <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 font-semibold border border-emerald-300">
                            <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                            ৳100 Advance Verified
                          </span>
                        </div>

                        {order.securityDepositTxId && (
                          <div className="text-[10px] font-mono text-stone-500">
                            TrxID: <strong className="text-stone-900">{order.securityDepositTxId}</strong>
                          </div>
                        )}

                        {isCod && (
                          <div className="text-[10px] text-amber-800 font-semibold">
                            ৳{order.remainingDueOnDelivery.toLocaleString()} due at delivery
                          </div>
                        )}
                      </td>

                      {/* Column 5: Total */}
                      <td className="py-3.5 px-4 align-top text-right">
                        <div className="font-mono text-sm font-bold text-stone-950">
                          ৳{order.total.toLocaleString()}
                        </div>
                        <span className="text-[10px] font-mono text-stone-400">
                          {order.discount > 0 ? `(Disc: -৳${order.discount})` : 'Net Amount'}
                        </span>
                      </td>

                      {/* Column 6: Fulfillment Status Dropdown */}
                      <td className="py-3.5 px-4 align-top">
                        <select
                          value={order.orderStatus}
                          onChange={(e) => handleStatusChange(order.id, e.target.value as OrderStatus)}
                          className={`px-2.5 py-1 rounded text-[11px] font-semibold uppercase tracking-wider border focus:outline-none cursor-pointer ${
                            order.orderStatus === 'placed'
                              ? 'bg-blue-50 text-blue-900 border-blue-200'
                              : order.orderStatus === 'confirmed'
                              ? 'bg-amber-50 text-amber-900 border-amber-200'
                              : order.orderStatus === 'processing'
                              ? 'bg-purple-50 text-purple-900 border-purple-200'
                              : order.orderStatus === 'shipped'
                              ? 'bg-indigo-50 text-indigo-900 border-indigo-200'
                              : order.orderStatus === 'delivered'
                              ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                              : 'bg-rose-50 text-rose-900 border-rose-200'
                          }`}
                        >
                          <option value="placed">Placed (New)</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="processing">Processing</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </td>

                      {/* Column 7: Actions */}
                      <td className="py-3.5 px-4 align-top text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setSelectedOrder(order)}
                            title="Inspect complete order details"
                            className="p-1.5 text-stone-600 hover:text-stone-950 hover:bg-stone-100 rounded transition-colors cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => handleOpenWhatsAppToCustomer(order)}
                            title="Message customer directly on WhatsApp"
                            className="p-1.5 text-[#25D366] hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                          >
                            <MessageCircle className="w-4 h-4 fill-[#25D366]" />
                          </button>

                          <button
                            onClick={() => handlePrintManifest(order)}
                            title="Print official dispatch invoice"
                            className="p-1.5 text-stone-600 hover:text-stone-950 hover:bg-stone-100 rounded transition-colors cursor-pointer"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Inspect Customer Order Drawer / Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-end bg-stone-950/60 backdrop-blur-xs">
          <div 
            className="w-full max-w-xl bg-white h-full shadow-2xl flex flex-col justify-between border-l border-stone-200 text-xs animate-in slide-in-from-right duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-6 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-3">
                <NAuraLogo size="sm" showWordmark={false} />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-serif font-bold text-stone-950">
                      Consignment {selectedOrder.id}
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-stone-200 text-stone-800 font-semibold uppercase">
                      {selectedOrder.orderStatus}
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-500">
                    Placed on {new Date(selectedOrder.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handlePrintManifest(selectedOrder)}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded font-medium flex items-center gap-1.5 cursor-pointer text-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Invoice</span>
                </button>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-1.5 text-stone-400 hover:text-stone-900 rounded cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Scrollable Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Customer Contact & Delivery Info */}
              <div>
                <h4 className="font-semibold text-stone-900 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-stone-700" />
                  <span>Customer & Shipping Destination</span>
                </h4>
                <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 space-y-2 text-stone-800">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-sm text-stone-950">{selectedOrder.customerName}</p>
                      <p className="font-mono text-stone-600">{selectedOrder.phone}</p>
                      <p className="font-mono text-stone-600">{selectedOrder.email}</p>
                    </div>

                    <button
                      onClick={() => handleOpenWhatsAppToCustomer(selectedOrder)}
                      className="px-3 py-1.5 bg-[#25D366] hover:bg-[#20bd5a] text-stone-950 font-bold rounded flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <MessageCircle className="w-3.5 h-3.5 fill-current" />
                      <span>WhatsApp Customer</span>
                    </button>
                  </div>

                  <div className="pt-2 border-t border-stone-200 text-xs">
                    <span className="text-[10px] text-stone-400 uppercase font-medium block">Delivery Destination</span>
                    <p className="font-medium text-stone-900">{selectedOrder.shippingAddress}</p>
                    <p className="text-stone-600">{selectedOrder.city}, Bangladesh {selectedOrder.postalCode ? `(${selectedOrder.postalCode})` : ''}</p>
                  </div>

                  {selectedOrder.notes && (
                    <div className="pt-2 border-t border-stone-200 text-[11px] text-stone-500 italic">
                      Special Delivery Instructions: "{selectedOrder.notes}"
                    </div>
                  )}
                </div>
              </div>

              {/* Payment & Security Advance Verification */}
              <div>
                <h4 className="font-semibold text-stone-900 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Payment & ৳100 Security Advance</span>
                </h4>
                <div className="p-4 bg-emerald-50/50 rounded-lg border border-emerald-200 space-y-2.5">
                  <div className="flex justify-between items-center">
                    <span className="text-stone-600 font-medium">Selected Payment Flow:</span>
                    <span className="font-semibold capitalize text-stone-950">
                      {selectedOrder.paymentMethod === 'cod' ? 'Cash on Delivery (Doorstep)' : 'bKash Online Payment'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-stone-600 font-medium">Mandatory ৳100 Advance Deposit:</span>
                    <span className="font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded text-[11px]">
                      ৳100 Verified (Auto-Verified)
                    </span>
                  </div>

                  {selectedOrder.securityDepositTxId && (
                    <div className="flex justify-between items-center pt-1 border-t border-emerald-200/80">
                      <span className="text-stone-600 font-medium">bKash Transaction ID (TrxID):</span>
                      <span className="font-mono font-bold text-stone-950 bg-white px-2 py-0.5 rounded border border-emerald-300">
                        {selectedOrder.securityDepositTxId}
                      </span>
                    </div>
                  )}

                  <div className="flex justify-between items-center">
                    <span className="text-stone-600 font-medium">Remaining Due on Delivery:</span>
                    <span className="font-mono font-bold text-amber-900 text-sm">
                      ৳{selectedOrder.remainingDueOnDelivery.toLocaleString()}
                    </span>
                  </div>

                  {selectedOrder.paymentStatus !== 'paid' && (
                    <button
                      onClick={() => handlePaymentVerify(selectedOrder.id)}
                      className="w-full mt-2 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded font-semibold text-xs transition-colors cursor-pointer shadow-xs"
                    >
                      ✓ Mark Entire Order as Paid & Reconciled
                    </button>
                  )}
                </div>
              </div>

              {/* Ordered Items Manifest */}
              <div>
                <h4 className="font-semibold text-stone-900 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5 text-stone-700" />
                  <span>Itemized Dispatch Manifest ({selectedOrder.items.length})</span>
                </h4>
                <div className="divide-y divide-stone-100 border border-stone-200 rounded-lg overflow-hidden bg-white">
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="p-3.5 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-12 h-12 rounded object-cover border border-stone-200 shrink-0"
                        />
                        <div>
                          <p className="font-semibold text-stone-950 text-xs">{item.product.name}</p>
                          <p className="text-[11px] text-stone-500 font-mono">
                            Category: {item.product.category} · Qty: {item.quantity} × ৳{item.product.price.toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <span className="font-mono tabular-nums font-bold text-stone-950 text-sm">
                        ৳{(item.quantity * item.product.price).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Calculation */}
              <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 space-y-2">
                <div className="flex justify-between text-stone-600">
                  <span>Cart Subtotal</span>
                  <span className="font-mono tabular-nums">৳{selectedOrder.subtotal.toLocaleString()}</span>
                </div>
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount Applied</span>
                    <span className="font-mono tabular-nums">-৳{selectedOrder.discount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-stone-600">
                  <span>Dhaka Delivery Fee</span>
                  <span className="font-mono tabular-nums">৳{selectedOrder.shippingFee.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-stone-950 font-bold text-sm pt-2 border-t border-stone-200">
                  <span>Grand Total</span>
                  <span className="font-mono tabular-nums text-base">৳{selectedOrder.total.toLocaleString()}</span>
                </div>
              </div>

              {/* Status Update Dropdown inside modal */}
              <div className="p-4 bg-stone-100 rounded-lg border border-stone-200 space-y-2">
                <label className="block text-stone-800 font-semibold text-xs">
                  Update Consignment Fulfillment Status:
                </label>
                <div className="flex gap-2">
                  <select
                    value={selectedOrder.orderStatus}
                    onChange={(e) => handleStatusChange(selectedOrder.id, e.target.value as OrderStatus)}
                    className="flex-1 px-3 py-2 bg-white border border-stone-300 rounded font-semibold text-xs text-stone-900 focus:outline-none"
                  >
                    <option value="placed">Placed (New Order)</option>
                    <option value="confirmed">Confirmed (Order Approved)</option>
                    <option value="processing">Processing (Packaging in Atelier)</option>
                    <option value="shipped">Shipped (Handed to Courier Partner)</option>
                    <option value="delivered">Delivered (Handed to Customer)</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Modal Bottom Close */}
            <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between">
              <span className="text-[11px] text-stone-500">
                Official Trade License: {BUSINESS_LICENSE_INFO.licenseNumber}
              </span>
              <button
                onClick={() => setSelectedOrder(null)}
                className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded font-semibold text-xs transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
