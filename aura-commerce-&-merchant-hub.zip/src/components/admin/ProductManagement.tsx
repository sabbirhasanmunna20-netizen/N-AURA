import React, { useState } from 'react';
import { Product, ProductCategory } from '../../types';
import { StorageService } from '../../services/storage';
import { Plus, Edit2, Trash2, Search, ArrowUpDown, Check, AlertTriangle, Image as ImageIcon } from 'lucide-react';

// Preset local images available for quick assignment
import headphonesImg from '../../assets/images/product_audio_headphones_1790452717360.jpg';
import watchImg from '../../assets/images/product_chrono_watch_1790452729156.jpg';
import kettleImg from '../../assets/images/product_ceramic_kettle_1790452739187.jpg';

interface ProductManagementProps {
  products: Product[];
  onRefresh: () => void;
}

const CATEGORIES: ProductCategory[] = ['Audio', 'Timepieces', 'Home & Living', 'Apparel', 'Stationery'];

export const ProductManagement: React.FC<ProductManagementProps> = ({ products, onRefresh }) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);

  // Edit / Add Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form Fields
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<ProductCategory>('Home & Living');
  const [formPrice, setFormPrice] = useState('');
  const [formOriginalPrice, setFormOriginalPrice] = useState('');
  const [formStock, setFormStock] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formTag, setFormTag] = useState('');
  const [formImage, setFormImage] = useState(headphonesImg);
  const [formCustomImageUrl, setFormCustomImageUrl] = useState('');
  const [specDimensions, setSpecDimensions] = useState('');
  const [specMaterial, setSpecMaterial] = useState('');
  const [specOrigin, setSpecOrigin] = useState('');

  // Delete confirmation
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);

  const openAddModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormCategory('Home & Living');
    setFormPrice('1500');
    setFormOriginalPrice('');
    setFormStock('20');
    setFormDescription('Artisanal craft object designed with functional longevity.');
    setFormTag('New Edition');
    setFormImage(headphonesImg);
    setFormCustomImageUrl('');
    setSpecDimensions('20cm x 15cm');
    setSpecMaterial('Natural Solid Material');
    setSpecOrigin('Craft Atelier');
    setIsModalOpen(true);
  };

  const openEditModal = (prod: Product) => {
    setEditingProduct(prod);
    setFormName(prod.name);
    setFormCategory(prod.category);
    setFormPrice(String(prod.price));
    setFormOriginalPrice(prod.originalPrice ? String(prod.originalPrice) : '');
    setFormStock(String(prod.stock));
    setFormDescription(prod.description);
    setFormTag(prod.tag || '');
    setFormImage(prod.images[0] || headphonesImg);
    setFormCustomImageUrl(prod.images[0]?.startsWith('http') ? prod.images[0] : '');
    setSpecDimensions(prod.specs?.['Dimensions'] || prod.specs?.['Case Diameter'] || '');
    setSpecMaterial(prod.specs?.['Material'] || prod.specs?.['Materials'] || '');
    setSpecOrigin(prod.specs?.['Origin'] || '');
    setIsModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const finalImage = formCustomImageUrl.trim() || formImage;

    const specs: Record<string, string> = {};
    if (specDimensions.trim()) specs['Dimensions'] = specDimensions.trim();
    if (specMaterial.trim()) specs['Material'] = specMaterial.trim();
    if (specOrigin.trim()) specs['Origin'] = specOrigin.trim();

    StorageService.saveProduct({
      id: editingProduct?.id,
      name: formName.trim(),
      category: formCategory,
      price: parseFloat(formPrice) || 50,
      originalPrice: formOriginalPrice ? parseFloat(formOriginalPrice) : undefined,
      stock: parseInt(formStock, 10) || 0,
      description: formDescription.trim(),
      tag: formTag.trim() || undefined,
      images: [finalImage],
      specs,
    });

    setIsModalOpen(false);
    onRefresh();
  };

  const handleDeleteProduct = (id: string) => {
    StorageService.deleteProduct(id);
    setDeleteCandidateId(null);
    onRefresh();
  };

  const handleStockDelta = (id: string, delta: number) => {
    StorageService.updateStock(id, delta);
    onRefresh();
  };

  // Filtering
  const filteredProducts = products.filter((p) => {
    const matchesSearch = 
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.id.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase());
    const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesLow = !showLowStockOnly || p.stock <= 5;
    return matchesSearch && matchesCat && matchesLow;
  });

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-lg border border-stone-200">
        <div>
          <h3 className="text-base font-serif font-semibold text-stone-950">
            Inventory & Catalog Registry
          </h3>
          <p className="text-xs text-stone-500">
            Real-time stock ledger with atomic create, read, update and delete capabilities.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2.5 bg-stone-950 hover:bg-stone-800 text-white text-xs uppercase tracking-wider font-semibold rounded-md transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white p-4 rounded-lg border border-stone-200 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by name, SKU ID, or category..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded text-xs text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 bg-stone-50 border border-stone-200 rounded text-xs text-stone-800 focus:bg-white focus:outline-none focus:border-stone-900 cursor-pointer"
            >
              <option value="all">All Categories</option>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>

            <button
              onClick={() => setShowLowStockOnly(!showLowStockOnly)}
              className={`px-3 py-2 text-xs font-medium rounded border transition-colors cursor-pointer ${
                showLowStockOnly
                  ? 'bg-amber-100 border-amber-300 text-amber-900 font-semibold'
                  : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
              }`}
            >
              Low Stock Alert (≤ 5)
            </button>
          </div>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-lg border border-stone-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50/80 border-b border-stone-200 text-stone-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3 px-4">Item</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Price</th>
                <th className="py-3 px-4 text-center">Stock Level</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 text-stone-700">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-stone-400">
                    No matching inventory products located.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product) => {
                  const isLow = product.stock > 0 && product.stock <= 5;
                  const isOut = product.stock <= 0;

                  return (
                    <tr key={product.id} className="hover:bg-stone-50/60 transition-colors">
                      {/* Product Preview */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={product.images[0]}
                            alt=""
                            className="w-10 h-10 object-cover rounded border border-stone-200 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <div className="font-semibold text-stone-900">{product.name}</div>
                            <div className="text-[11px] font-mono text-stone-400">SKU: {product.id}</div>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4 text-stone-600">{product.category}</td>

                      {/* Price */}
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-stone-900">
                        ${product.price.toFixed(2)}
                      </td>

                      {/* Stock Stepper */}
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handleStockDelta(product.id, -1)}
                            disabled={product.stock <= 0}
                            className="w-6 h-6 rounded bg-stone-100 hover:bg-stone-200 text-stone-700 flex items-center justify-center text-xs font-bold disabled:opacity-30 cursor-pointer"
                            title="Decrease stock by 1"
                          >
                            -
                          </button>
                          <span className={`w-12 text-center font-mono tabular-nums font-semibold text-xs ${
                            isOut ? 'text-rose-600' : isLow ? 'text-amber-600' : 'text-stone-900'
                          }`}>
                            {product.stock}
                          </span>
                          <button
                            onClick={() => handleStockDelta(product.id, 1)}
                            className="w-6 h-6 rounded bg-stone-100 hover:bg-stone-200 text-stone-700 flex items-center justify-center text-xs font-bold cursor-pointer"
                            title="Increase stock by 1"
                          >
                            +
                          </button>
                        </div>
                      </td>

                      {/* Stock Status */}
                      <td className="py-3 px-4">
                        {isOut ? (
                          <span className="font-medium text-rose-700 flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Out of Stock</span>
                          </span>
                        ) : isLow ? (
                          <span className="font-medium text-amber-700 flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Low Stock ({product.stock})</span>
                          </span>
                        ) : (
                          <span className="text-emerald-700 font-medium">Optimal</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => openEditModal(product)}
                            className="p-1.5 text-stone-600 hover:text-stone-950 rounded hover:bg-stone-100 transition-colors cursor-pointer"
                            title="Edit product"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteCandidateId(product.id)}
                            className="p-1.5 text-stone-400 hover:text-rose-700 rounded hover:bg-stone-100 transition-colors cursor-pointer"
                            title="Delete product"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteCandidateId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-lg p-6 border border-stone-200 shadow-2xl text-xs space-y-4">
            <h4 className="text-base font-serif font-semibold text-stone-950">
              Confirm Product Removal
            </h4>
            <p className="text-stone-600 leading-relaxed">
              Are you sure you want to remove this product from the live catalog? This action will update persistent store state and will be recorded in the audit log.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteCandidateId(null)}
                className="px-3.5 py-2 border border-stone-300 rounded font-medium text-stone-700 hover:bg-stone-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteProduct(deleteCandidateId)}
                className="px-3.5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded font-medium cursor-pointer"
              >
                Delete Product
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs overflow-y-auto">
          <div 
            className="w-full max-w-2xl bg-white border border-stone-200 rounded-lg shadow-2xl overflow-hidden my-auto text-xs"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-5 border-b border-stone-200 flex justify-between items-center bg-stone-50/50">
              <h3 className="text-base font-serif font-semibold text-stone-950">
                {editingProduct ? 'Edit Catalog Product' : 'Add New Inventory Item'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-stone-400 hover:text-stone-900 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-stone-700 font-medium mb-1">
                    Product Title <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Kyoto Ceramic Pour-Over Kettle"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as ProductCategory)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Tag / Label</label>
                  <input
                    type="text"
                    placeholder="e.g. Flagship or Handcrafted"
                    value={formTag}
                    onChange={(e) => setFormTag(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">
                    Price (USD) <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="120.00"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded font-mono text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Original Price (MSRP)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Optional original price"
                    value={formOriginalPrice}
                    onChange={(e) => setFormOriginalPrice(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded font-mono text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">
                    Initial Stock Count <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="15"
                    value={formStock}
                    onChange={(e) => setFormStock(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded font-mono text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-stone-700 font-medium mb-1">Description</label>
                  <textarea
                    rows={3}
                    placeholder="Describe material provenance, performance specifications, and finish."
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>

                {/* Preset Image Chooser */}
                <div className="sm:col-span-2">
                  <label className="block text-stone-700 font-medium mb-1">Select Visual Asset</label>
                  <div className="grid grid-cols-3 gap-3 mb-2">
                    {[
                      { label: 'Audio Flagship', img: headphonesImg },
                      { label: 'Chronometer', img: watchImg },
                      { label: 'Ceramic Kettle', img: kettleImg },
                    ].map((item, i) => (
                      <div
                        key={i}
                        onClick={() => {
                          setFormImage(item.img);
                          setFormCustomImageUrl('');
                        }}
                        className={`p-2 border rounded-lg flex flex-col items-center gap-1 cursor-pointer transition-all ${
                          formImage === item.img && !formCustomImageUrl
                            ? 'border-stone-950 bg-stone-50 ring-1 ring-stone-950'
                            : 'border-stone-200 hover:border-stone-300'
                        }`}
                      >
                        <img src={item.img} alt="" className="w-14 h-14 object-cover rounded" />
                        <span className="text-[10px] font-medium text-stone-700">{item.label}</span>
                      </div>
                    ))}
                  </div>

                  <input
                    type="url"
                    placeholder="Or enter custom image URL (https://...)"
                    value={formCustomImageUrl}
                    onChange={(e) => setFormCustomImageUrl(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900 text-xs"
                  />
                </div>

                {/* Specifications */}
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Dimensions Spec</label>
                  <input
                    type="text"
                    placeholder="e.g. 40mm x 11mm or 0.9L"
                    value={specDimensions}
                    onChange={(e) => setSpecDimensions(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Material Spec</label>
                  <input
                    type="text"
                    placeholder="e.g. 304 Stainless Steel & Ceramic"
                    value={specMaterial}
                    onChange={(e) => setSpecMaterial(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded text-stone-900"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-stone-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-stone-300 rounded font-medium text-stone-700 hover:bg-stone-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-stone-950 hover:bg-stone-800 text-white rounded font-semibold cursor-pointer"
                >
                  {editingProduct ? 'Update Product' : 'Save & Publish Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
