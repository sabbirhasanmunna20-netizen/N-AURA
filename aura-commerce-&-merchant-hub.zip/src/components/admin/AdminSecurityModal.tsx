import React, { useState } from 'react';
import { StorageService } from '../../services/storage';
import { ShieldCheck, Lock, KeyRound, AlertCircle } from 'lucide-react';

interface AdminSecurityModalProps {
  isOpen: boolean;
  onAuthenticated: () => void;
  onCancel: () => void;
}

export const AdminSecurityModal: React.FC<AdminSecurityModalProps> = ({
  isOpen,
  onAuthenticated,
  onCancel,
}) => {
  const [passkey, setPasskey] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Default administrative passkey is admin123
    if (passkey.trim() === 'admin123' || passkey.trim() === 'admin') {
      StorageService.setAdminAuthenticated(true);
      onAuthenticated();
    } else {
      setError('Invalid passkey. Hint: Use default passkey "admin123"');
    }
  };

  const handleQuickDemoUnlock = () => {
    StorageService.setAdminAuthenticated(true);
    onAuthenticated();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs">
      <div 
        className="w-full max-w-md bg-white border border-stone-200 rounded-lg shadow-2xl p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-stone-900 text-stone-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <ShieldCheck className="w-6 h-6 text-stone-300" />
          </div>
          <span className="text-[11px] uppercase tracking-wider font-semibold text-stone-500">
            Internal Security Frame
          </span>
          <h2 className="text-xl font-serif font-semibold text-stone-950 mt-1">
            Merchant Authentication
          </h2>
          <p className="text-xs text-stone-600 mt-1.5 leading-relaxed">
            Administrative configurations, inventory modifications, and troubleshooting actions require authorization.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-stone-700 font-medium mb-1 flex items-center justify-between">
              <span>Security Passkey</span>
              <span className="text-[11px] text-stone-400 font-normal">Default: admin123</span>
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                autoFocus
                placeholder="Enter admin passkey"
                value={passkey}
                onChange={(e) => setPasskey(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-300 rounded text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>
          </div>

          <div className="flex flex-col gap-2 pt-2">
            <button
              type="submit"
              className="w-full py-2.5 bg-stone-950 hover:bg-stone-800 text-white rounded text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer"
            >
              Verify Passkey & Enter
            </button>

            <button
              type="button"
              onClick={handleQuickDemoUnlock}
              className="w-full py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded text-xs font-medium transition-colors cursor-pointer"
            >
              One-Click Demo Authorization
            </button>

            <button
              type="button"
              onClick={onCancel}
              className="w-full py-1.5 text-stone-500 hover:text-stone-900 text-xs font-medium transition-colors cursor-pointer"
            >
              Return to Storefront
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
